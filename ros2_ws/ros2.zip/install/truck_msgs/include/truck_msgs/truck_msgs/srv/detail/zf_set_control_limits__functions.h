// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from truck_msgs:srv/ZfSetControlLimits.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__DETAIL__ZF_SET_CONTROL_LIMITS__FUNCTIONS_H_
#define TRUCK_MSGS__SRV__DETAIL__ZF_SET_CONTROL_LIMITS__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "truck_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "truck_msgs/srv/detail/zf_set_control_limits__struct.h"

/// Initialize srv/ZfSetControlLimits message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * truck_msgs__srv__ZfSetControlLimits_Request
 * )) before or use
 * truck_msgs__srv__ZfSetControlLimits_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Request__init(truck_msgs__srv__ZfSetControlLimits_Request * msg);

/// Finalize srv/ZfSetControlLimits message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
void
truck_msgs__srv__ZfSetControlLimits_Request__fini(truck_msgs__srv__ZfSetControlLimits_Request * msg);

/// Create srv/ZfSetControlLimits message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * truck_msgs__srv__ZfSetControlLimits_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
truck_msgs__srv__ZfSetControlLimits_Request *
truck_msgs__srv__ZfSetControlLimits_Request__create();

/// Destroy srv/ZfSetControlLimits message.
/**
 * It calls
 * truck_msgs__srv__ZfSetControlLimits_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
void
truck_msgs__srv__ZfSetControlLimits_Request__destroy(truck_msgs__srv__ZfSetControlLimits_Request * msg);

/// Check for srv/ZfSetControlLimits message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Request__are_equal(const truck_msgs__srv__ZfSetControlLimits_Request * lhs, const truck_msgs__srv__ZfSetControlLimits_Request * rhs);

/// Copy a srv/ZfSetControlLimits message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Request__copy(
  const truck_msgs__srv__ZfSetControlLimits_Request * input,
  truck_msgs__srv__ZfSetControlLimits_Request * output);

/// Initialize array of srv/ZfSetControlLimits messages.
/**
 * It allocates the memory for the number of elements and calls
 * truck_msgs__srv__ZfSetControlLimits_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Request__Sequence__init(truck_msgs__srv__ZfSetControlLimits_Request__Sequence * array, size_t size);

/// Finalize array of srv/ZfSetControlLimits messages.
/**
 * It calls
 * truck_msgs__srv__ZfSetControlLimits_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
void
truck_msgs__srv__ZfSetControlLimits_Request__Sequence__fini(truck_msgs__srv__ZfSetControlLimits_Request__Sequence * array);

/// Create array of srv/ZfSetControlLimits messages.
/**
 * It allocates the memory for the array and calls
 * truck_msgs__srv__ZfSetControlLimits_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
truck_msgs__srv__ZfSetControlLimits_Request__Sequence *
truck_msgs__srv__ZfSetControlLimits_Request__Sequence__create(size_t size);

/// Destroy array of srv/ZfSetControlLimits messages.
/**
 * It calls
 * truck_msgs__srv__ZfSetControlLimits_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
void
truck_msgs__srv__ZfSetControlLimits_Request__Sequence__destroy(truck_msgs__srv__ZfSetControlLimits_Request__Sequence * array);

/// Check for srv/ZfSetControlLimits message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Request__Sequence__are_equal(const truck_msgs__srv__ZfSetControlLimits_Request__Sequence * lhs, const truck_msgs__srv__ZfSetControlLimits_Request__Sequence * rhs);

/// Copy an array of srv/ZfSetControlLimits messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Request__Sequence__copy(
  const truck_msgs__srv__ZfSetControlLimits_Request__Sequence * input,
  truck_msgs__srv__ZfSetControlLimits_Request__Sequence * output);

/// Initialize srv/ZfSetControlLimits message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * truck_msgs__srv__ZfSetControlLimits_Response
 * )) before or use
 * truck_msgs__srv__ZfSetControlLimits_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Response__init(truck_msgs__srv__ZfSetControlLimits_Response * msg);

/// Finalize srv/ZfSetControlLimits message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
void
truck_msgs__srv__ZfSetControlLimits_Response__fini(truck_msgs__srv__ZfSetControlLimits_Response * msg);

/// Create srv/ZfSetControlLimits message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * truck_msgs__srv__ZfSetControlLimits_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
truck_msgs__srv__ZfSetControlLimits_Response *
truck_msgs__srv__ZfSetControlLimits_Response__create();

/// Destroy srv/ZfSetControlLimits message.
/**
 * It calls
 * truck_msgs__srv__ZfSetControlLimits_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
void
truck_msgs__srv__ZfSetControlLimits_Response__destroy(truck_msgs__srv__ZfSetControlLimits_Response * msg);

/// Check for srv/ZfSetControlLimits message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Response__are_equal(const truck_msgs__srv__ZfSetControlLimits_Response * lhs, const truck_msgs__srv__ZfSetControlLimits_Response * rhs);

/// Copy a srv/ZfSetControlLimits message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Response__copy(
  const truck_msgs__srv__ZfSetControlLimits_Response * input,
  truck_msgs__srv__ZfSetControlLimits_Response * output);

/// Initialize array of srv/ZfSetControlLimits messages.
/**
 * It allocates the memory for the number of elements and calls
 * truck_msgs__srv__ZfSetControlLimits_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Response__Sequence__init(truck_msgs__srv__ZfSetControlLimits_Response__Sequence * array, size_t size);

/// Finalize array of srv/ZfSetControlLimits messages.
/**
 * It calls
 * truck_msgs__srv__ZfSetControlLimits_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
void
truck_msgs__srv__ZfSetControlLimits_Response__Sequence__fini(truck_msgs__srv__ZfSetControlLimits_Response__Sequence * array);

/// Create array of srv/ZfSetControlLimits messages.
/**
 * It allocates the memory for the array and calls
 * truck_msgs__srv__ZfSetControlLimits_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
truck_msgs__srv__ZfSetControlLimits_Response__Sequence *
truck_msgs__srv__ZfSetControlLimits_Response__Sequence__create(size_t size);

/// Destroy array of srv/ZfSetControlLimits messages.
/**
 * It calls
 * truck_msgs__srv__ZfSetControlLimits_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
void
truck_msgs__srv__ZfSetControlLimits_Response__Sequence__destroy(truck_msgs__srv__ZfSetControlLimits_Response__Sequence * array);

/// Check for srv/ZfSetControlLimits message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Response__Sequence__are_equal(const truck_msgs__srv__ZfSetControlLimits_Response__Sequence * lhs, const truck_msgs__srv__ZfSetControlLimits_Response__Sequence * rhs);

/// Copy an array of srv/ZfSetControlLimits messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_truck_msgs
bool
truck_msgs__srv__ZfSetControlLimits_Response__Sequence__copy(
  const truck_msgs__srv__ZfSetControlLimits_Response__Sequence * input,
  truck_msgs__srv__ZfSetControlLimits_Response__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__SRV__DETAIL__ZF_SET_CONTROL_LIMITS__FUNCTIONS_H_
