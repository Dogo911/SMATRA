// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:srv/ZfSetDebugFlags.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__ZF_SET_DEBUG_FLAGS_H_
#define TRUCK_MSGS__SRV__ZF_SET_DEBUG_FLAGS_H_

#include "truck_msgs/srv/detail/zf_set_debug_flags__struct.h"
#include "truck_msgs/srv/detail/zf_set_debug_flags__functions.h"
#include "truck_msgs/srv/detail/zf_set_debug_flags__type_support.h"

#endif  // TRUCK_MSGS__SRV__ZF_SET_DEBUG_FLAGS_H_
