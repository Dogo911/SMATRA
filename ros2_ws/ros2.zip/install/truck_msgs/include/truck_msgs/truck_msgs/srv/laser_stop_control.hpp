// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__LASER_STOP_CONTROL_HPP_
#define TRUCK_MSGS__SRV__LASER_STOP_CONTROL_HPP_

#include "truck_msgs/srv/detail/laser_stop_control__struct.hpp"
#include "truck_msgs/srv/detail/laser_stop_control__builder.hpp"
#include "truck_msgs/srv/detail/laser_stop_control__traits.hpp"
#include "truck_msgs/srv/detail/laser_stop_control__type_support.hpp"

#endif  // TRUCK_MSGS__SRV__LASER_STOP_CONTROL_HPP_
