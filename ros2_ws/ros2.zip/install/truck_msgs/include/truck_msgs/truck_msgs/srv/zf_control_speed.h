// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:srv/ZfControlSpeed.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__ZF_CONTROL_SPEED_H_
#define TRUCK_MSGS__SRV__ZF_CONTROL_SPEED_H_

#include "truck_msgs/srv/detail/zf_control_speed__struct.h"
#include "truck_msgs/srv/detail/zf_control_speed__functions.h"
#include "truck_msgs/srv/detail/zf_control_speed__type_support.h"

#endif  // TRUCK_MSGS__SRV__ZF_CONTROL_SPEED_H_
