// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:srv/ZfSetEmergencyStop.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__ZF_SET_EMERGENCY_STOP_H_
#define TRUCK_MSGS__SRV__ZF_SET_EMERGENCY_STOP_H_

#include "truck_msgs/srv/detail/zf_set_emergency_stop__struct.h"
#include "truck_msgs/srv/detail/zf_set_emergency_stop__functions.h"
#include "truck_msgs/srv/detail/zf_set_emergency_stop__type_support.h"

#endif  // TRUCK_MSGS__SRV__ZF_SET_EMERGENCY_STOP_H_
