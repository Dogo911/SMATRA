// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__ZF_SET_EMERGENCY_STOP_AUTO_RELEASE_HPP_
#define TRUCK_MSGS__SRV__ZF_SET_EMERGENCY_STOP_AUTO_RELEASE_HPP_

#include "truck_msgs/srv/detail/zf_set_emergency_stop_auto_release__struct.hpp"
#include "truck_msgs/srv/detail/zf_set_emergency_stop_auto_release__builder.hpp"
#include "truck_msgs/srv/detail/zf_set_emergency_stop_auto_release__traits.hpp"
#include "truck_msgs/srv/detail/zf_set_emergency_stop_auto_release__type_support.hpp"

#endif  // TRUCK_MSGS__SRV__ZF_SET_EMERGENCY_STOP_AUTO_RELEASE_HPP_
