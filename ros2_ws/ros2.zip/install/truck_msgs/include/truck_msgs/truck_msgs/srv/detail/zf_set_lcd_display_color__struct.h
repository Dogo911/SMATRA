// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:srv/ZfSetLcdDisplayColor.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__DETAIL__ZF_SET_LCD_DISPLAY_COLOR__STRUCT_H_
#define TRUCK_MSGS__SRV__DETAIL__ZF_SET_LCD_DISPLAY_COLOR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/ZfSetLcdDisplayColor in the package truck_msgs.
typedef struct truck_msgs__srv__ZfSetLcdDisplayColor_Request
{
  /// 0...255
  uint8_t red;
  /// 0...255
  uint8_t green;
  /// 0...255
  uint8_t blue;
} truck_msgs__srv__ZfSetLcdDisplayColor_Request;

// Struct for a sequence of truck_msgs__srv__ZfSetLcdDisplayColor_Request.
typedef struct truck_msgs__srv__ZfSetLcdDisplayColor_Request__Sequence
{
  truck_msgs__srv__ZfSetLcdDisplayColor_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__srv__ZfSetLcdDisplayColor_Request__Sequence;


// Constants defined in the message

/// Struct defined in srv/ZfSetLcdDisplayColor in the package truck_msgs.
typedef struct truck_msgs__srv__ZfSetLcdDisplayColor_Response
{
  /// 0=ok
  int16_t status;
} truck_msgs__srv__ZfSetLcdDisplayColor_Response;

// Struct for a sequence of truck_msgs__srv__ZfSetLcdDisplayColor_Response.
typedef struct truck_msgs__srv__ZfSetLcdDisplayColor_Response__Sequence
{
  truck_msgs__srv__ZfSetLcdDisplayColor_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__srv__ZfSetLcdDisplayColor_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__SRV__DETAIL__ZF_SET_LCD_DISPLAY_COLOR__STRUCT_H_
