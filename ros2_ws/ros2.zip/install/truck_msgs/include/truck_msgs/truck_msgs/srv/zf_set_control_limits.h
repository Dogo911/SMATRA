// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:srv/ZfSetControlLimits.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__ZF_SET_CONTROL_LIMITS_H_
#define TRUCK_MSGS__SRV__ZF_SET_CONTROL_LIMITS_H_

#include "truck_msgs/srv/detail/zf_set_control_limits__struct.h"
#include "truck_msgs/srv/detail/zf_set_control_limits__functions.h"
#include "truck_msgs/srv/detail/zf_set_control_limits__type_support.h"

#endif  // TRUCK_MSGS__SRV__ZF_SET_CONTROL_LIMITS_H_
