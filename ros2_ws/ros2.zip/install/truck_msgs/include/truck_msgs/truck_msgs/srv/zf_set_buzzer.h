// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:srv/ZfSetBuzzer.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__ZF_SET_BUZZER_H_
#define TRUCK_MSGS__SRV__ZF_SET_BUZZER_H_

#include "truck_msgs/srv/detail/zf_set_buzzer__struct.h"
#include "truck_msgs/srv/detail/zf_set_buzzer__functions.h"
#include "truck_msgs/srv/detail/zf_set_buzzer__type_support.h"

#endif  // TRUCK_MSGS__SRV__ZF_SET_BUZZER_H_
