// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__ZF_SET_BUZZER_HPP_
#define TRUCK_MSGS__SRV__ZF_SET_BUZZER_HPP_

#include "truck_msgs/srv/detail/zf_set_buzzer__struct.hpp"
#include "truck_msgs/srv/detail/zf_set_buzzer__builder.hpp"
#include "truck_msgs/srv/detail/zf_set_buzzer__traits.hpp"
#include "truck_msgs/srv/detail/zf_set_buzzer__type_support.hpp"

#endif  // TRUCK_MSGS__SRV__ZF_SET_BUZZER_HPP_
