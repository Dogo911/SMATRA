// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:srv/ZfSetLcdDisplayColor.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__ZF_SET_LCD_DISPLAY_COLOR_H_
#define TRUCK_MSGS__SRV__ZF_SET_LCD_DISPLAY_COLOR_H_

#include "truck_msgs/srv/detail/zf_set_lcd_display_color__struct.h"
#include "truck_msgs/srv/detail/zf_set_lcd_display_color__functions.h"
#include "truck_msgs/srv/detail/zf_set_lcd_display_color__type_support.h"

#endif  // TRUCK_MSGS__SRV__ZF_SET_LCD_DISPLAY_COLOR_H_
