// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:srv/ZfControlSpeed.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__SRV__DETAIL__ZF_CONTROL_SPEED__STRUCT_H_
#define TRUCK_MSGS__SRV__DETAIL__ZF_CONTROL_SPEED__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/ZfControlSpeed in the package truck_msgs.
typedef struct truck_msgs__srv__ZfControlSpeed_Request
{
  /// request fields
  ///  Soll-Geschwindigkeit
  float v;
  /// Soll-Beschleunigung, immer positiv
  float a;
} truck_msgs__srv__ZfControlSpeed_Request;

// Struct for a sequence of truck_msgs__srv__ZfControlSpeed_Request.
typedef struct truck_msgs__srv__ZfControlSpeed_Request__Sequence
{
  truck_msgs__srv__ZfControlSpeed_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__srv__ZfControlSpeed_Request__Sequence;


// Constants defined in the message

/// Struct defined in srv/ZfControlSpeed in the package truck_msgs.
typedef struct truck_msgs__srv__ZfControlSpeed_Response
{
  int16_t status;
} truck_msgs__srv__ZfControlSpeed_Response;

// Struct for a sequence of truck_msgs__srv__ZfControlSpeed_Response.
typedef struct truck_msgs__srv__ZfControlSpeed_Response__Sequence
{
  truck_msgs__srv__ZfControlSpeed_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__srv__ZfControlSpeed_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__SRV__DETAIL__ZF_CONTROL_SPEED__STRUCT_H_
