// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/BeaconState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/beacon_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'p1'
// Member 'p2'
// Member 'p_center'
#include "geometry_msgs/msg/detail/point__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const BeaconState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: sensor_active
  {
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << ", ";
  }

  // member: control_active
  {
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << ", ";
  }

  // member: rviz_marker
  {
    out << "rviz_marker: ";
    rosidl_generator_traits::value_to_yaml(msg.rviz_marker, out);
    out << ", ";
  }

  // member: p1
  {
    out << "p1: ";
    to_flow_style_yaml(msg.p1, out);
    out << ", ";
  }

  // member: p2
  {
    out << "p2: ";
    to_flow_style_yaml(msg.p2, out);
    out << ", ";
  }

  // member: p_center
  {
    out << "p_center: ";
    to_flow_style_yaml(msg.p_center, out);
    out << ", ";
  }

  // member: data_n
  {
    out << "data_n: ";
    rosidl_generator_traits::value_to_yaml(msg.data_n, out);
    out << ", ";
  }

  // member: used_n
  {
    out << "used_n: ";
    rosidl_generator_traits::value_to_yaml(msg.used_n, out);
    out << ", ";
  }

  // member: cnt_b1
  {
    out << "cnt_b1: ";
    rosidl_generator_traits::value_to_yaml(msg.cnt_b1, out);
    out << ", ";
  }

  // member: cnt_b2
  {
    out << "cnt_b2: ";
    rosidl_generator_traits::value_to_yaml(msg.cnt_b2, out);
    out << ", ";
  }

  // member: cnt_mid
  {
    out << "cnt_mid: ";
    rosidl_generator_traits::value_to_yaml(msg.cnt_mid, out);
    out << ", ";
  }

  // member: status_b1
  {
    out << "status_b1: ";
    rosidl_generator_traits::value_to_yaml(msg.status_b1, out);
    out << ", ";
  }

  // member: status_b2
  {
    out << "status_b2: ";
    rosidl_generator_traits::value_to_yaml(msg.status_b2, out);
    out << ", ";
  }

  // member: status
  {
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << ", ";
  }

  // member: alpha
  {
    out << "alpha: ";
    rosidl_generator_traits::value_to_yaml(msg.alpha, out);
    out << ", ";
  }

  // member: delta_target
  {
    out << "delta_target: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_target, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BeaconState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: sensor_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << "\n";
  }

  // member: control_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << "\n";
  }

  // member: rviz_marker
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rviz_marker: ";
    rosidl_generator_traits::value_to_yaml(msg.rviz_marker, out);
    out << "\n";
  }

  // member: p1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p1:\n";
    to_block_style_yaml(msg.p1, out, indentation + 2);
  }

  // member: p2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p2:\n";
    to_block_style_yaml(msg.p2, out, indentation + 2);
  }

  // member: p_center
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_center:\n";
    to_block_style_yaml(msg.p_center, out, indentation + 2);
  }

  // member: data_n
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "data_n: ";
    rosidl_generator_traits::value_to_yaml(msg.data_n, out);
    out << "\n";
  }

  // member: used_n
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "used_n: ";
    rosidl_generator_traits::value_to_yaml(msg.used_n, out);
    out << "\n";
  }

  // member: cnt_b1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cnt_b1: ";
    rosidl_generator_traits::value_to_yaml(msg.cnt_b1, out);
    out << "\n";
  }

  // member: cnt_b2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cnt_b2: ";
    rosidl_generator_traits::value_to_yaml(msg.cnt_b2, out);
    out << "\n";
  }

  // member: cnt_mid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cnt_mid: ";
    rosidl_generator_traits::value_to_yaml(msg.cnt_mid, out);
    out << "\n";
  }

  // member: status_b1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status_b1: ";
    rosidl_generator_traits::value_to_yaml(msg.status_b1, out);
    out << "\n";
  }

  // member: status_b2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status_b2: ";
    rosidl_generator_traits::value_to_yaml(msg.status_b2, out);
    out << "\n";
  }

  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << "\n";
  }

  // member: alpha
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alpha: ";
    rosidl_generator_traits::value_to_yaml(msg.alpha, out);
    out << "\n";
  }

  // member: delta_target
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "delta_target: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_target, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BeaconState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::BeaconState & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::BeaconState & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::BeaconState>()
{
  return "truck_msgs::msg::BeaconState";
}

template<>
inline const char * name<truck_msgs::msg::BeaconState>()
{
  return "truck_msgs/msg/BeaconState";
}

template<>
struct has_fixed_size<truck_msgs::msg::BeaconState>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::Point>::value && has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::BeaconState>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::Point>::value && has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::BeaconState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__TRAITS_HPP_
