// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/ZfLights.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/zf_lights__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
truck_msgs__msg__ZfLights__init(truck_msgs__msg__ZfLights * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    truck_msgs__msg__ZfLights__fini(msg);
    return false;
  }
  // driving
  // braking
  // indicator_left
  // indicator_right
  // high_beam
  // reversing
  // cornering_left
  // cornering_right
  return true;
}

void
truck_msgs__msg__ZfLights__fini(truck_msgs__msg__ZfLights * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // driving
  // braking
  // indicator_left
  // indicator_right
  // high_beam
  // reversing
  // cornering_left
  // cornering_right
}

bool
truck_msgs__msg__ZfLights__are_equal(const truck_msgs__msg__ZfLights * lhs, const truck_msgs__msg__ZfLights * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // driving
  if (lhs->driving != rhs->driving) {
    return false;
  }
  // braking
  if (lhs->braking != rhs->braking) {
    return false;
  }
  // indicator_left
  if (lhs->indicator_left != rhs->indicator_left) {
    return false;
  }
  // indicator_right
  if (lhs->indicator_right != rhs->indicator_right) {
    return false;
  }
  // high_beam
  if (lhs->high_beam != rhs->high_beam) {
    return false;
  }
  // reversing
  if (lhs->reversing != rhs->reversing) {
    return false;
  }
  // cornering_left
  if (lhs->cornering_left != rhs->cornering_left) {
    return false;
  }
  // cornering_right
  if (lhs->cornering_right != rhs->cornering_right) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__ZfLights__copy(
  const truck_msgs__msg__ZfLights * input,
  truck_msgs__msg__ZfLights * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // driving
  output->driving = input->driving;
  // braking
  output->braking = input->braking;
  // indicator_left
  output->indicator_left = input->indicator_left;
  // indicator_right
  output->indicator_right = input->indicator_right;
  // high_beam
  output->high_beam = input->high_beam;
  // reversing
  output->reversing = input->reversing;
  // cornering_left
  output->cornering_left = input->cornering_left;
  // cornering_right
  output->cornering_right = input->cornering_right;
  return true;
}

truck_msgs__msg__ZfLights *
truck_msgs__msg__ZfLights__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfLights * msg = (truck_msgs__msg__ZfLights *)allocator.allocate(sizeof(truck_msgs__msg__ZfLights), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__ZfLights));
  bool success = truck_msgs__msg__ZfLights__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__ZfLights__destroy(truck_msgs__msg__ZfLights * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__ZfLights__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__ZfLights__Sequence__init(truck_msgs__msg__ZfLights__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfLights * data = NULL;

  if (size) {
    data = (truck_msgs__msg__ZfLights *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__ZfLights), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__ZfLights__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__ZfLights__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__ZfLights__Sequence__fini(truck_msgs__msg__ZfLights__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__ZfLights__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__ZfLights__Sequence *
truck_msgs__msg__ZfLights__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfLights__Sequence * array = (truck_msgs__msg__ZfLights__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__ZfLights__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__ZfLights__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__ZfLights__Sequence__destroy(truck_msgs__msg__ZfLights__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__ZfLights__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__ZfLights__Sequence__are_equal(const truck_msgs__msg__ZfLights__Sequence * lhs, const truck_msgs__msg__ZfLights__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__ZfLights__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__ZfLights__Sequence__copy(
  const truck_msgs__msg__ZfLights__Sequence * input,
  truck_msgs__msg__ZfLights__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__ZfLights);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__ZfLights * data =
      (truck_msgs__msg__ZfLights *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__ZfLights__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__ZfLights__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__ZfLights__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
