// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/LaserStopState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/laser_stop_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'tp'
#include "geometry_msgs/msg/detail/point__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const LaserStopState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: sensor_active
  {
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << ", ";
  }

  // member: control_active
  {
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << ", ";
  }

  // member: rviz_marker
  {
    out << "rviz_marker: ";
    rosidl_generator_traits::value_to_yaml(msg.rviz_marker, out);
    out << ", ";
  }

  // member: cycle
  {
    out << "cycle: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle, out);
    out << ", ";
  }

  // member: tp
  {
    out << "tp: ";
    to_flow_style_yaml(msg.tp, out);
    out << ", ";
  }

  // member: min_dist
  {
    out << "min_dist: ";
    rosidl_generator_traits::value_to_yaml(msg.min_dist, out);
    out << ", ";
  }

  // member: ttc
  {
    out << "ttc: ";
    rosidl_generator_traits::value_to_yaml(msg.ttc, out);
    out << ", ";
  }

  // member: v_target
  {
    out << "v_target: ";
    rosidl_generator_traits::value_to_yaml(msg.v_target, out);
    out << ", ";
  }

  // member: steering_min
  {
    out << "steering_min: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_min, out);
    out << ", ";
  }

  // member: steering_max
  {
    out << "steering_max: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_max, out);
    out << ", ";
  }

  // member: speed_min
  {
    out << "speed_min: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_min, out);
    out << ", ";
  }

  // member: speed_max
  {
    out << "speed_max: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_max, out);
    out << ", ";
  }

  // member: accel_min
  {
    out << "accel_min: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_min, out);
    out << ", ";
  }

  // member: accel_max
  {
    out << "accel_max: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_max, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const LaserStopState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: sensor_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << "\n";
  }

  // member: control_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << "\n";
  }

  // member: rviz_marker
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rviz_marker: ";
    rosidl_generator_traits::value_to_yaml(msg.rviz_marker, out);
    out << "\n";
  }

  // member: cycle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cycle: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle, out);
    out << "\n";
  }

  // member: tp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "tp:\n";
    to_block_style_yaml(msg.tp, out, indentation + 2);
  }

  // member: min_dist
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "min_dist: ";
    rosidl_generator_traits::value_to_yaml(msg.min_dist, out);
    out << "\n";
  }

  // member: ttc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ttc: ";
    rosidl_generator_traits::value_to_yaml(msg.ttc, out);
    out << "\n";
  }

  // member: v_target
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "v_target: ";
    rosidl_generator_traits::value_to_yaml(msg.v_target, out);
    out << "\n";
  }

  // member: steering_min
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_min: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_min, out);
    out << "\n";
  }

  // member: steering_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_max: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_max, out);
    out << "\n";
  }

  // member: speed_min
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_min: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_min, out);
    out << "\n";
  }

  // member: speed_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_max: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_max, out);
    out << "\n";
  }

  // member: accel_min
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accel_min: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_min, out);
    out << "\n";
  }

  // member: accel_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accel_max: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_max, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const LaserStopState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::LaserStopState & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::LaserStopState & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::LaserStopState>()
{
  return "truck_msgs::msg::LaserStopState";
}

template<>
inline const char * name<truck_msgs::msg::LaserStopState>()
{
  return "truck_msgs/msg/LaserStopState";
}

template<>
struct has_fixed_size<truck_msgs::msg::LaserStopState>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::Point>::value && has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::LaserStopState>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::Point>::value && has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::LaserStopState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__TRAITS_HPP_
