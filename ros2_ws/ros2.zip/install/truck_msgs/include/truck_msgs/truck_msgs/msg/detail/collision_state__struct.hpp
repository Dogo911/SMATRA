// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/CollisionState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'p1'
// Member 'p2'
#include "geometry_msgs/msg/detail/point__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__CollisionState __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__CollisionState __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CollisionState_
{
  using Type = CollisionState_<ContainerAllocator>;

  explicit CollisionState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    p1(_init),
    p2(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->stop_active = 0;
      this->stop_distance = 0;
      this->sensor_active = 0;
      this->control_active = 0;
      this->target_distance = 0;
      this->max_distance = 0;
      this->width = 0;
      this->dist_x = 0;
      this->offset = 0;
      this->dist = 0;
      this->alpha = 0;
      this->beta = 0;
      this->delta_target = 0;
      this->v_target = 0;
      this->width_status = 0;
      this->dist_status = 0;
      this->status = 0;
    }
  }

  explicit CollisionState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    p1(_alloc, _init),
    p2(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->stop_active = 0;
      this->stop_distance = 0;
      this->sensor_active = 0;
      this->control_active = 0;
      this->target_distance = 0;
      this->max_distance = 0;
      this->width = 0;
      this->dist_x = 0;
      this->offset = 0;
      this->dist = 0;
      this->alpha = 0;
      this->beta = 0;
      this->delta_target = 0;
      this->v_target = 0;
      this->width_status = 0;
      this->dist_status = 0;
      this->status = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _stop_active_type =
    int16_t;
  _stop_active_type stop_active;
  using _stop_distance_type =
    int16_t;
  _stop_distance_type stop_distance;
  using _sensor_active_type =
    int16_t;
  _sensor_active_type sensor_active;
  using _control_active_type =
    int16_t;
  _control_active_type control_active;
  using _target_distance_type =
    int16_t;
  _target_distance_type target_distance;
  using _max_distance_type =
    int16_t;
  _max_distance_type max_distance;
  using _p1_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _p1_type p1;
  using _p2_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _p2_type p2;
  using _width_type =
    int16_t;
  _width_type width;
  using _dist_x_type =
    int16_t;
  _dist_x_type dist_x;
  using _offset_type =
    int16_t;
  _offset_type offset;
  using _dist_type =
    int16_t;
  _dist_type dist;
  using _alpha_type =
    int16_t;
  _alpha_type alpha;
  using _beta_type =
    int16_t;
  _beta_type beta;
  using _delta_target_type =
    int16_t;
  _delta_target_type delta_target;
  using _v_target_type =
    int16_t;
  _v_target_type v_target;
  using _width_status_type =
    int16_t;
  _width_status_type width_status;
  using _dist_status_type =
    int16_t;
  _dist_status_type dist_status;
  using _status_type =
    int16_t;
  _status_type status;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__stop_active(
    const int16_t & _arg)
  {
    this->stop_active = _arg;
    return *this;
  }
  Type & set__stop_distance(
    const int16_t & _arg)
  {
    this->stop_distance = _arg;
    return *this;
  }
  Type & set__sensor_active(
    const int16_t & _arg)
  {
    this->sensor_active = _arg;
    return *this;
  }
  Type & set__control_active(
    const int16_t & _arg)
  {
    this->control_active = _arg;
    return *this;
  }
  Type & set__target_distance(
    const int16_t & _arg)
  {
    this->target_distance = _arg;
    return *this;
  }
  Type & set__max_distance(
    const int16_t & _arg)
  {
    this->max_distance = _arg;
    return *this;
  }
  Type & set__p1(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->p1 = _arg;
    return *this;
  }
  Type & set__p2(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->p2 = _arg;
    return *this;
  }
  Type & set__width(
    const int16_t & _arg)
  {
    this->width = _arg;
    return *this;
  }
  Type & set__dist_x(
    const int16_t & _arg)
  {
    this->dist_x = _arg;
    return *this;
  }
  Type & set__offset(
    const int16_t & _arg)
  {
    this->offset = _arg;
    return *this;
  }
  Type & set__dist(
    const int16_t & _arg)
  {
    this->dist = _arg;
    return *this;
  }
  Type & set__alpha(
    const int16_t & _arg)
  {
    this->alpha = _arg;
    return *this;
  }
  Type & set__beta(
    const int16_t & _arg)
  {
    this->beta = _arg;
    return *this;
  }
  Type & set__delta_target(
    const int16_t & _arg)
  {
    this->delta_target = _arg;
    return *this;
  }
  Type & set__v_target(
    const int16_t & _arg)
  {
    this->v_target = _arg;
    return *this;
  }
  Type & set__width_status(
    const int16_t & _arg)
  {
    this->width_status = _arg;
    return *this;
  }
  Type & set__dist_status(
    const int16_t & _arg)
  {
    this->dist_status = _arg;
    return *this;
  }
  Type & set__status(
    const int16_t & _arg)
  {
    this->status = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::CollisionState_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::CollisionState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::CollisionState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::CollisionState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::CollisionState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::CollisionState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::CollisionState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::CollisionState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::CollisionState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::CollisionState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__CollisionState
    std::shared_ptr<truck_msgs::msg::CollisionState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__CollisionState
    std::shared_ptr<truck_msgs::msg::CollisionState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CollisionState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->stop_active != other.stop_active) {
      return false;
    }
    if (this->stop_distance != other.stop_distance) {
      return false;
    }
    if (this->sensor_active != other.sensor_active) {
      return false;
    }
    if (this->control_active != other.control_active) {
      return false;
    }
    if (this->target_distance != other.target_distance) {
      return false;
    }
    if (this->max_distance != other.max_distance) {
      return false;
    }
    if (this->p1 != other.p1) {
      return false;
    }
    if (this->p2 != other.p2) {
      return false;
    }
    if (this->width != other.width) {
      return false;
    }
    if (this->dist_x != other.dist_x) {
      return false;
    }
    if (this->offset != other.offset) {
      return false;
    }
    if (this->dist != other.dist) {
      return false;
    }
    if (this->alpha != other.alpha) {
      return false;
    }
    if (this->beta != other.beta) {
      return false;
    }
    if (this->delta_target != other.delta_target) {
      return false;
    }
    if (this->v_target != other.v_target) {
      return false;
    }
    if (this->width_status != other.width_status) {
      return false;
    }
    if (this->dist_status != other.dist_status) {
      return false;
    }
    if (this->status != other.status) {
      return false;
    }
    return true;
  }
  bool operator!=(const CollisionState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CollisionState_

// alias to use template instance with default allocator
using CollisionState =
  truck_msgs::msg::CollisionState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__STRUCT_HPP_
