// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/ZfControllerParams.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/zf_controller_params__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
truck_msgs__msg__ZfControllerParams__init(truck_msgs__msg__ZfControllerParams * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    truck_msgs__msg__ZfControllerParams__fini(msg);
    return false;
  }
  // steer_p
  // steer_i
  // steer_d
  // speed_p
  // speed_i
  // speed_d
  // steer_a
  // steer_b
  // steer_c
  // speed_a
  // speed_b
  // speed_c
  return true;
}

void
truck_msgs__msg__ZfControllerParams__fini(truck_msgs__msg__ZfControllerParams * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // steer_p
  // steer_i
  // steer_d
  // speed_p
  // speed_i
  // speed_d
  // steer_a
  // steer_b
  // steer_c
  // speed_a
  // speed_b
  // speed_c
}

bool
truck_msgs__msg__ZfControllerParams__are_equal(const truck_msgs__msg__ZfControllerParams * lhs, const truck_msgs__msg__ZfControllerParams * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // steer_p
  if (lhs->steer_p != rhs->steer_p) {
    return false;
  }
  // steer_i
  if (lhs->steer_i != rhs->steer_i) {
    return false;
  }
  // steer_d
  if (lhs->steer_d != rhs->steer_d) {
    return false;
  }
  // speed_p
  if (lhs->speed_p != rhs->speed_p) {
    return false;
  }
  // speed_i
  if (lhs->speed_i != rhs->speed_i) {
    return false;
  }
  // speed_d
  if (lhs->speed_d != rhs->speed_d) {
    return false;
  }
  // steer_a
  if (lhs->steer_a != rhs->steer_a) {
    return false;
  }
  // steer_b
  if (lhs->steer_b != rhs->steer_b) {
    return false;
  }
  // steer_c
  if (lhs->steer_c != rhs->steer_c) {
    return false;
  }
  // speed_a
  if (lhs->speed_a != rhs->speed_a) {
    return false;
  }
  // speed_b
  if (lhs->speed_b != rhs->speed_b) {
    return false;
  }
  // speed_c
  if (lhs->speed_c != rhs->speed_c) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__ZfControllerParams__copy(
  const truck_msgs__msg__ZfControllerParams * input,
  truck_msgs__msg__ZfControllerParams * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // steer_p
  output->steer_p = input->steer_p;
  // steer_i
  output->steer_i = input->steer_i;
  // steer_d
  output->steer_d = input->steer_d;
  // speed_p
  output->speed_p = input->speed_p;
  // speed_i
  output->speed_i = input->speed_i;
  // speed_d
  output->speed_d = input->speed_d;
  // steer_a
  output->steer_a = input->steer_a;
  // steer_b
  output->steer_b = input->steer_b;
  // steer_c
  output->steer_c = input->steer_c;
  // speed_a
  output->speed_a = input->speed_a;
  // speed_b
  output->speed_b = input->speed_b;
  // speed_c
  output->speed_c = input->speed_c;
  return true;
}

truck_msgs__msg__ZfControllerParams *
truck_msgs__msg__ZfControllerParams__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfControllerParams * msg = (truck_msgs__msg__ZfControllerParams *)allocator.allocate(sizeof(truck_msgs__msg__ZfControllerParams), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__ZfControllerParams));
  bool success = truck_msgs__msg__ZfControllerParams__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__ZfControllerParams__destroy(truck_msgs__msg__ZfControllerParams * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__ZfControllerParams__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__ZfControllerParams__Sequence__init(truck_msgs__msg__ZfControllerParams__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfControllerParams * data = NULL;

  if (size) {
    data = (truck_msgs__msg__ZfControllerParams *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__ZfControllerParams), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__ZfControllerParams__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__ZfControllerParams__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__ZfControllerParams__Sequence__fini(truck_msgs__msg__ZfControllerParams__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__ZfControllerParams__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__ZfControllerParams__Sequence *
truck_msgs__msg__ZfControllerParams__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfControllerParams__Sequence * array = (truck_msgs__msg__ZfControllerParams__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__ZfControllerParams__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__ZfControllerParams__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__ZfControllerParams__Sequence__destroy(truck_msgs__msg__ZfControllerParams__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__ZfControllerParams__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__ZfControllerParams__Sequence__are_equal(const truck_msgs__msg__ZfControllerParams__Sequence * lhs, const truck_msgs__msg__ZfControllerParams__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__ZfControllerParams__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__ZfControllerParams__Sequence__copy(
  const truck_msgs__msg__ZfControllerParams__Sequence * input,
  truck_msgs__msg__ZfControllerParams__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__ZfControllerParams);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__ZfControllerParams * data =
      (truck_msgs__msg__ZfControllerParams *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__ZfControllerParams__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__ZfControllerParams__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__ZfControllerParams__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
