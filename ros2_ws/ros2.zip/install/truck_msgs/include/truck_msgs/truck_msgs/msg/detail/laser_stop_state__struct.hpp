// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/LaserStopState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'tp'
#include "geometry_msgs/msg/detail/point__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__LaserStopState __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__LaserStopState __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LaserStopState_
{
  using Type = LaserStopState_<ContainerAllocator>;

  explicit LaserStopState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    tp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor_active = 0;
      this->control_active = 0;
      this->rviz_marker = 0;
      this->cycle = 0ll;
      this->min_dist = 0.0f;
      this->ttc = 0.0f;
      this->v_target = 0.0f;
      this->steering_min = 0.0f;
      this->steering_max = 0.0f;
      this->speed_min = 0.0f;
      this->speed_max = 0.0f;
      this->accel_min = 0.0f;
      this->accel_max = 0.0f;
    }
  }

  explicit LaserStopState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    tp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor_active = 0;
      this->control_active = 0;
      this->rviz_marker = 0;
      this->cycle = 0ll;
      this->min_dist = 0.0f;
      this->ttc = 0.0f;
      this->v_target = 0.0f;
      this->steering_min = 0.0f;
      this->steering_max = 0.0f;
      this->speed_min = 0.0f;
      this->speed_max = 0.0f;
      this->accel_min = 0.0f;
      this->accel_max = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _sensor_active_type =
    int16_t;
  _sensor_active_type sensor_active;
  using _control_active_type =
    int16_t;
  _control_active_type control_active;
  using _rviz_marker_type =
    int16_t;
  _rviz_marker_type rviz_marker;
  using _cycle_type =
    int64_t;
  _cycle_type cycle;
  using _tp_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _tp_type tp;
  using _min_dist_type =
    float;
  _min_dist_type min_dist;
  using _ttc_type =
    float;
  _ttc_type ttc;
  using _v_target_type =
    float;
  _v_target_type v_target;
  using _steering_min_type =
    float;
  _steering_min_type steering_min;
  using _steering_max_type =
    float;
  _steering_max_type steering_max;
  using _speed_min_type =
    float;
  _speed_min_type speed_min;
  using _speed_max_type =
    float;
  _speed_max_type speed_max;
  using _accel_min_type =
    float;
  _accel_min_type accel_min;
  using _accel_max_type =
    float;
  _accel_max_type accel_max;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__sensor_active(
    const int16_t & _arg)
  {
    this->sensor_active = _arg;
    return *this;
  }
  Type & set__control_active(
    const int16_t & _arg)
  {
    this->control_active = _arg;
    return *this;
  }
  Type & set__rviz_marker(
    const int16_t & _arg)
  {
    this->rviz_marker = _arg;
    return *this;
  }
  Type & set__cycle(
    const int64_t & _arg)
  {
    this->cycle = _arg;
    return *this;
  }
  Type & set__tp(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->tp = _arg;
    return *this;
  }
  Type & set__min_dist(
    const float & _arg)
  {
    this->min_dist = _arg;
    return *this;
  }
  Type & set__ttc(
    const float & _arg)
  {
    this->ttc = _arg;
    return *this;
  }
  Type & set__v_target(
    const float & _arg)
  {
    this->v_target = _arg;
    return *this;
  }
  Type & set__steering_min(
    const float & _arg)
  {
    this->steering_min = _arg;
    return *this;
  }
  Type & set__steering_max(
    const float & _arg)
  {
    this->steering_max = _arg;
    return *this;
  }
  Type & set__speed_min(
    const float & _arg)
  {
    this->speed_min = _arg;
    return *this;
  }
  Type & set__speed_max(
    const float & _arg)
  {
    this->speed_max = _arg;
    return *this;
  }
  Type & set__accel_min(
    const float & _arg)
  {
    this->accel_min = _arg;
    return *this;
  }
  Type & set__accel_max(
    const float & _arg)
  {
    this->accel_max = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::LaserStopState_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::LaserStopState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::LaserStopState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::LaserStopState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::LaserStopState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::LaserStopState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::LaserStopState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::LaserStopState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::LaserStopState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::LaserStopState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__LaserStopState
    std::shared_ptr<truck_msgs::msg::LaserStopState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__LaserStopState
    std::shared_ptr<truck_msgs::msg::LaserStopState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LaserStopState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->sensor_active != other.sensor_active) {
      return false;
    }
    if (this->control_active != other.control_active) {
      return false;
    }
    if (this->rviz_marker != other.rviz_marker) {
      return false;
    }
    if (this->cycle != other.cycle) {
      return false;
    }
    if (this->tp != other.tp) {
      return false;
    }
    if (this->min_dist != other.min_dist) {
      return false;
    }
    if (this->ttc != other.ttc) {
      return false;
    }
    if (this->v_target != other.v_target) {
      return false;
    }
    if (this->steering_min != other.steering_min) {
      return false;
    }
    if (this->steering_max != other.steering_max) {
      return false;
    }
    if (this->speed_min != other.speed_min) {
      return false;
    }
    if (this->speed_max != other.speed_max) {
      return false;
    }
    if (this->accel_min != other.accel_min) {
      return false;
    }
    if (this->accel_max != other.accel_max) {
      return false;
    }
    return true;
  }
  bool operator!=(const LaserStopState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LaserStopState_

// alias to use template instance with default allocator
using LaserStopState =
  truck_msgs::msg::LaserStopState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__STRUCT_HPP_
