// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfSensorConfig.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_sensor_config__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfSensorConfig_cnt
{
public:
  explicit Init_ZfSensorConfig_cnt(::truck_msgs::msg::ZfSensorConfig & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfSensorConfig cnt(::truck_msgs::msg::ZfSensorConfig::_cnt_type arg)
  {
    msg_.cnt = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfSensorConfig msg_;
};

class Init_ZfSensorConfig_config
{
public:
  Init_ZfSensorConfig_config()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfSensorConfig_cnt config(::truck_msgs::msg::ZfSensorConfig::_config_type arg)
  {
    msg_.config = std::move(arg);
    return Init_ZfSensorConfig_cnt(msg_);
  }

private:
  ::truck_msgs::msg::ZfSensorConfig msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfSensorConfig>()
{
  return truck_msgs::msg::builder::Init_ZfSensorConfig_config();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG__BUILDER_HPP_
