﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/BeaconState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'p1'
// Member 'p2'
// Member 'p_center'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in msg/BeaconState in the package truck_msgs.
/**
  * ZF InnoLab ROS message definition
  * beacon_state.msg
  *
  * Version 6.0
 */
typedef struct truck_msgs__msg__BeaconState
{
  std_msgs__msg__Header header;
  /// Steuergrössen:
  int16_t sensor_active;
  int16_t control_active;
  int16_t rviz_marker;
  /// Ausgangswerte der Erkennung:
  /// Mittelpunkte des Beacons 1
  geometry_msgs__msg__Point p1;
  /// Mittelpunkte des Beacons 2
  geometry_msgs__msg__Point p2;
  /// Mittelpunkt der beiden Beacons
  geometry_msgs__msg__Point p_center;
  /// Hilfswerte:
  ///  Anzahl der Werte aus /scan
  int16_t data_n;
  /// data_n, reduziert auf 1 Grad-Werte
  int16_t used_n;
  /// Anzahl der Treffer von Beacon 1
  int16_t cnt_b1;
  /// Anzahl der Treffer von Beacon 2
  int16_t cnt_b2;
  int16_t cnt_mid;
  /// Status Erkennung Beacon 1
  int16_t status_b1;
  /// Status Erkennung Beacon 2
  int16_t status_b2;
  int16_t status;
  /// Winkel zur Mitte des Mittelpunkts der beiden Beacons
  int16_t alpha;
  /// Regler-Sollgroessen:
  /// Soll-Lenkwinkel
  float delta_target;
} truck_msgs__msg__BeaconState;

// Struct for a sequence of truck_msgs__msg__BeaconState.
typedef struct truck_msgs__msg__BeaconState__Sequence
{
  truck_msgs__msg__BeaconState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__BeaconState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__STRUCT_H_
