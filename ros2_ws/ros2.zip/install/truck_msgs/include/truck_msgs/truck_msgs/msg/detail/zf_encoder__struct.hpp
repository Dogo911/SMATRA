// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/ZfEncoder.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__ZfEncoder __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__ZfEncoder __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ZfEncoder_
{
  using Type = ZfEncoder_<ContainerAllocator>;

  explicit ZfEncoder_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->left = 0l;
      this->right = 0l;
      this->back = 0l;
      this->steering = 0l;
      this->trailer = 0l;
      this->timestamp_slave = 0ul;
      this->timestamp_master = 0ul;
      this->timestamp_bridge = 0ul;
    }
  }

  explicit ZfEncoder_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->left = 0l;
      this->right = 0l;
      this->back = 0l;
      this->steering = 0l;
      this->trailer = 0l;
      this->timestamp_slave = 0ul;
      this->timestamp_master = 0ul;
      this->timestamp_bridge = 0ul;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _left_type =
    int32_t;
  _left_type left;
  using _right_type =
    int32_t;
  _right_type right;
  using _back_type =
    int32_t;
  _back_type back;
  using _steering_type =
    int32_t;
  _steering_type steering;
  using _trailer_type =
    int32_t;
  _trailer_type trailer;
  using _timestamp_slave_type =
    uint32_t;
  _timestamp_slave_type timestamp_slave;
  using _timestamp_master_type =
    uint32_t;
  _timestamp_master_type timestamp_master;
  using _timestamp_bridge_type =
    uint32_t;
  _timestamp_bridge_type timestamp_bridge;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__left(
    const int32_t & _arg)
  {
    this->left = _arg;
    return *this;
  }
  Type & set__right(
    const int32_t & _arg)
  {
    this->right = _arg;
    return *this;
  }
  Type & set__back(
    const int32_t & _arg)
  {
    this->back = _arg;
    return *this;
  }
  Type & set__steering(
    const int32_t & _arg)
  {
    this->steering = _arg;
    return *this;
  }
  Type & set__trailer(
    const int32_t & _arg)
  {
    this->trailer = _arg;
    return *this;
  }
  Type & set__timestamp_slave(
    const uint32_t & _arg)
  {
    this->timestamp_slave = _arg;
    return *this;
  }
  Type & set__timestamp_master(
    const uint32_t & _arg)
  {
    this->timestamp_master = _arg;
    return *this;
  }
  Type & set__timestamp_bridge(
    const uint32_t & _arg)
  {
    this->timestamp_bridge = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::ZfEncoder_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::ZfEncoder_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfEncoder_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfEncoder_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfEncoder_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfEncoder_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfEncoder_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfEncoder_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfEncoder_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfEncoder_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__ZfEncoder
    std::shared_ptr<truck_msgs::msg::ZfEncoder_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__ZfEncoder
    std::shared_ptr<truck_msgs::msg::ZfEncoder_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ZfEncoder_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->left != other.left) {
      return false;
    }
    if (this->right != other.right) {
      return false;
    }
    if (this->back != other.back) {
      return false;
    }
    if (this->steering != other.steering) {
      return false;
    }
    if (this->trailer != other.trailer) {
      return false;
    }
    if (this->timestamp_slave != other.timestamp_slave) {
      return false;
    }
    if (this->timestamp_master != other.timestamp_master) {
      return false;
    }
    if (this->timestamp_bridge != other.timestamp_bridge) {
      return false;
    }
    return true;
  }
  bool operator!=(const ZfEncoder_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ZfEncoder_

// alias to use template instance with default allocator
using ZfEncoder =
  truck_msgs::msg::ZfEncoder_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__STRUCT_HPP_
