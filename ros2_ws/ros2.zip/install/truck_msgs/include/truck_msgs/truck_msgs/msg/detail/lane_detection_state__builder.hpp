// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/LaneDetectionState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__LANE_DETECTION_STATE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__LANE_DETECTION_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/lane_detection_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_LaneDetectionState_non_zero_y
{
public:
  explicit Init_LaneDetectionState_non_zero_y(::truck_msgs::msg::LaneDetectionState & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::LaneDetectionState non_zero_y(::truck_msgs::msg::LaneDetectionState::_non_zero_y_type arg)
  {
    msg_.non_zero_y = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::LaneDetectionState msg_;
};

class Init_LaneDetectionState_non_zero_x
{
public:
  explicit Init_LaneDetectionState_non_zero_x(::truck_msgs::msg::LaneDetectionState & msg)
  : msg_(msg)
  {}
  Init_LaneDetectionState_non_zero_y non_zero_x(::truck_msgs::msg::LaneDetectionState::_non_zero_x_type arg)
  {
    msg_.non_zero_x = std::move(arg);
    return Init_LaneDetectionState_non_zero_y(msg_);
  }

private:
  ::truck_msgs::msg::LaneDetectionState msg_;
};

class Init_LaneDetectionState_offset
{
public:
  explicit Init_LaneDetectionState_offset(::truck_msgs::msg::LaneDetectionState & msg)
  : msg_(msg)
  {}
  Init_LaneDetectionState_non_zero_x offset(::truck_msgs::msg::LaneDetectionState::_offset_type arg)
  {
    msg_.offset = std::move(arg);
    return Init_LaneDetectionState_non_zero_x(msg_);
  }

private:
  ::truck_msgs::msg::LaneDetectionState msg_;
};

class Init_LaneDetectionState_right_curvature
{
public:
  explicit Init_LaneDetectionState_right_curvature(::truck_msgs::msg::LaneDetectionState & msg)
  : msg_(msg)
  {}
  Init_LaneDetectionState_offset right_curvature(::truck_msgs::msg::LaneDetectionState::_right_curvature_type arg)
  {
    msg_.right_curvature = std::move(arg);
    return Init_LaneDetectionState_offset(msg_);
  }

private:
  ::truck_msgs::msg::LaneDetectionState msg_;
};

class Init_LaneDetectionState_left_curvature
{
public:
  explicit Init_LaneDetectionState_left_curvature(::truck_msgs::msg::LaneDetectionState & msg)
  : msg_(msg)
  {}
  Init_LaneDetectionState_right_curvature left_curvature(::truck_msgs::msg::LaneDetectionState::_left_curvature_type arg)
  {
    msg_.left_curvature = std::move(arg);
    return Init_LaneDetectionState_right_curvature(msg_);
  }

private:
  ::truck_msgs::msg::LaneDetectionState msg_;
};

class Init_LaneDetectionState_right_fit
{
public:
  explicit Init_LaneDetectionState_right_fit(::truck_msgs::msg::LaneDetectionState & msg)
  : msg_(msg)
  {}
  Init_LaneDetectionState_left_curvature right_fit(::truck_msgs::msg::LaneDetectionState::_right_fit_type arg)
  {
    msg_.right_fit = std::move(arg);
    return Init_LaneDetectionState_left_curvature(msg_);
  }

private:
  ::truck_msgs::msg::LaneDetectionState msg_;
};

class Init_LaneDetectionState_left_fit
{
public:
  explicit Init_LaneDetectionState_left_fit(::truck_msgs::msg::LaneDetectionState & msg)
  : msg_(msg)
  {}
  Init_LaneDetectionState_right_fit left_fit(::truck_msgs::msg::LaneDetectionState::_left_fit_type arg)
  {
    msg_.left_fit = std::move(arg);
    return Init_LaneDetectionState_right_fit(msg_);
  }

private:
  ::truck_msgs::msg::LaneDetectionState msg_;
};

class Init_LaneDetectionState_header
{
public:
  Init_LaneDetectionState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LaneDetectionState_left_fit header(::truck_msgs::msg::LaneDetectionState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_LaneDetectionState_left_fit(msg_);
  }

private:
  ::truck_msgs::msg::LaneDetectionState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::LaneDetectionState>()
{
  return truck_msgs::msg::builder::Init_LaneDetectionState_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__LANE_DETECTION_STATE__BUILDER_HPP_
