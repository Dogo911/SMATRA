// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfControllerState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_STATE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_controller_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfControllerState_speed_steering
{
public:
  explicit Init_ZfControllerState_speed_steering(::truck_msgs::msg::ZfControllerState & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfControllerState speed_steering(::truck_msgs::msg::ZfControllerState::_speed_steering_type arg)
  {
    msg_.speed_steering = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerState msg_;
};

class Init_ZfControllerState_speed_p
{
public:
  explicit Init_ZfControllerState_speed_p(::truck_msgs::msg::ZfControllerState & msg)
  : msg_(msg)
  {}
  Init_ZfControllerState_speed_steering speed_p(::truck_msgs::msg::ZfControllerState::_speed_p_type arg)
  {
    msg_.speed_p = std::move(arg);
    return Init_ZfControllerState_speed_steering(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerState msg_;
};

class Init_ZfControllerState_speed_forward
{
public:
  explicit Init_ZfControllerState_speed_forward(::truck_msgs::msg::ZfControllerState & msg)
  : msg_(msg)
  {}
  Init_ZfControllerState_speed_p speed_forward(::truck_msgs::msg::ZfControllerState::_speed_forward_type arg)
  {
    msg_.speed_forward = std::move(arg);
    return Init_ZfControllerState_speed_p(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerState msg_;
};

class Init_ZfControllerState_header
{
public:
  Init_ZfControllerState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfControllerState_speed_forward header(::truck_msgs::msg::ZfControllerState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfControllerState_speed_forward(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfControllerState>()
{
  return truck_msgs::msg::builder::Init_ZfControllerState_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_STATE__BUILDER_HPP_
