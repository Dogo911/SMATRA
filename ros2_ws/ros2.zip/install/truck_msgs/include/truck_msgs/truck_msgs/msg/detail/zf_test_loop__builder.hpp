// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfTestLoop.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_test_loop__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfTestLoop_ros_to_ros
{
public:
  explicit Init_ZfTestLoop_ros_to_ros(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfTestLoop ros_to_ros(::truck_msgs::msg::ZfTestLoop::_ros_to_ros_type arg)
  {
    msg_.ros_to_ros = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_bridge_to_bridge
{
public:
  explicit Init_ZfTestLoop_bridge_to_bridge(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_ros_to_ros bridge_to_bridge(::truck_msgs::msg::ZfTestLoop::_bridge_to_bridge_type arg)
  {
    msg_.bridge_to_bridge = std::move(arg);
    return Init_ZfTestLoop_ros_to_ros(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_master_to_master
{
public:
  explicit Init_ZfTestLoop_master_to_master(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_bridge_to_bridge master_to_master(::truck_msgs::msg::ZfTestLoop::_master_to_master_type arg)
  {
    msg_.master_to_master = std::move(arg);
    return Init_ZfTestLoop_bridge_to_bridge(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_timestamp_ros_in
{
public:
  explicit Init_ZfTestLoop_timestamp_ros_in(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_master_to_master timestamp_ros_in(::truck_msgs::msg::ZfTestLoop::_timestamp_ros_in_type arg)
  {
    msg_.timestamp_ros_in = std::move(arg);
    return Init_ZfTestLoop_master_to_master(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_timestamp_bridge_in
{
public:
  explicit Init_ZfTestLoop_timestamp_bridge_in(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_timestamp_ros_in timestamp_bridge_in(::truck_msgs::msg::ZfTestLoop::_timestamp_bridge_in_type arg)
  {
    msg_.timestamp_bridge_in = std::move(arg);
    return Init_ZfTestLoop_timestamp_ros_in(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_timestamp_master_in
{
public:
  explicit Init_ZfTestLoop_timestamp_master_in(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_timestamp_bridge_in timestamp_master_in(::truck_msgs::msg::ZfTestLoop::_timestamp_master_in_type arg)
  {
    msg_.timestamp_master_in = std::move(arg);
    return Init_ZfTestLoop_timestamp_bridge_in(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_timestamp_slave
{
public:
  explicit Init_ZfTestLoop_timestamp_slave(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_timestamp_master_in timestamp_slave(::truck_msgs::msg::ZfTestLoop::_timestamp_slave_type arg)
  {
    msg_.timestamp_slave = std::move(arg);
    return Init_ZfTestLoop_timestamp_master_in(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_timestamp_master_out
{
public:
  explicit Init_ZfTestLoop_timestamp_master_out(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_timestamp_slave timestamp_master_out(::truck_msgs::msg::ZfTestLoop::_timestamp_master_out_type arg)
  {
    msg_.timestamp_master_out = std::move(arg);
    return Init_ZfTestLoop_timestamp_slave(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_timestamp_bridge_out
{
public:
  explicit Init_ZfTestLoop_timestamp_bridge_out(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_timestamp_master_out timestamp_bridge_out(::truck_msgs::msg::ZfTestLoop::_timestamp_bridge_out_type arg)
  {
    msg_.timestamp_bridge_out = std::move(arg);
    return Init_ZfTestLoop_timestamp_master_out(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_timestamp_ros_out
{
public:
  explicit Init_ZfTestLoop_timestamp_ros_out(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_timestamp_bridge_out timestamp_ros_out(::truck_msgs::msg::ZfTestLoop::_timestamp_ros_out_type arg)
  {
    msg_.timestamp_ros_out = std::move(arg);
    return Init_ZfTestLoop_timestamp_bridge_out(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_sender
{
public:
  explicit Init_ZfTestLoop_sender(::truck_msgs::msg::ZfTestLoop & msg)
  : msg_(msg)
  {}
  Init_ZfTestLoop_timestamp_ros_out sender(::truck_msgs::msg::ZfTestLoop::_sender_type arg)
  {
    msg_.sender = std::move(arg);
    return Init_ZfTestLoop_timestamp_ros_out(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

class Init_ZfTestLoop_header
{
public:
  Init_ZfTestLoop_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfTestLoop_sender header(::truck_msgs::msg::ZfTestLoop::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfTestLoop_sender(msg_);
  }

private:
  ::truck_msgs::msg::ZfTestLoop msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfTestLoop>()
{
  return truck_msgs::msg::builder::Init_ZfTestLoop_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__BUILDER_HPP_
