// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfSensorConfigOne.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_sensor_config_one__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfSensorConfigOne_stop_dist
{
public:
  explicit Init_ZfSensorConfigOne_stop_dist(::truck_msgs::msg::ZfSensorConfigOne & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfSensorConfigOne stop_dist(::truck_msgs::msg::ZfSensorConfigOne::_stop_dist_type arg)
  {
    msg_.stop_dist = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfSensorConfigOne msg_;
};

class Init_ZfSensorConfigOne_stop_active
{
public:
  explicit Init_ZfSensorConfigOne_stop_active(::truck_msgs::msg::ZfSensorConfigOne & msg)
  : msg_(msg)
  {}
  Init_ZfSensorConfigOne_stop_dist stop_active(::truck_msgs::msg::ZfSensorConfigOne::_stop_active_type arg)
  {
    msg_.stop_active = std::move(arg);
    return Init_ZfSensorConfigOne_stop_dist(msg_);
  }

private:
  ::truck_msgs::msg::ZfSensorConfigOne msg_;
};

class Init_ZfSensorConfigOne_sensor_active
{
public:
  explicit Init_ZfSensorConfigOne_sensor_active(::truck_msgs::msg::ZfSensorConfigOne & msg)
  : msg_(msg)
  {}
  Init_ZfSensorConfigOne_stop_active sensor_active(::truck_msgs::msg::ZfSensorConfigOne::_sensor_active_type arg)
  {
    msg_.sensor_active = std::move(arg);
    return Init_ZfSensorConfigOne_stop_active(msg_);
  }

private:
  ::truck_msgs::msg::ZfSensorConfigOne msg_;
};

class Init_ZfSensorConfigOne_id
{
public:
  Init_ZfSensorConfigOne_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfSensorConfigOne_sensor_active id(::truck_msgs::msg::ZfSensorConfigOne::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_ZfSensorConfigOne_sensor_active(msg_);
  }

private:
  ::truck_msgs::msg::ZfSensorConfigOne msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfSensorConfigOne>()
{
  return truck_msgs::msg::builder::Init_ZfSensorConfigOne_id();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__BUILDER_HPP_
