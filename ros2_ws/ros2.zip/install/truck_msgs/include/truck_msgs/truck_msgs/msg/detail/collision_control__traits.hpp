// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/CollisionControl.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__COLLISION_CONTROL__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__COLLISION_CONTROL__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/collision_control__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const CollisionControl & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: sensor_active
  {
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << ", ";
  }

  // member: control_active
  {
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << ", ";
  }

  // member: target_distance
  {
    out << "target_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.target_distance, out);
    out << ", ";
  }

  // member: max_distance
  {
    out << "max_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.max_distance, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CollisionControl & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: sensor_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << "\n";
  }

  // member: control_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << "\n";
  }

  // member: target_distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.target_distance, out);
    out << "\n";
  }

  // member: max_distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "max_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.max_distance, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CollisionControl & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::CollisionControl & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::CollisionControl & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::CollisionControl>()
{
  return "truck_msgs::msg::CollisionControl";
}

template<>
inline const char * name<truck_msgs::msg::CollisionControl>()
{
  return "truck_msgs/msg/CollisionControl";
}

template<>
struct has_fixed_size<truck_msgs::msg::CollisionControl>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::CollisionControl>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::CollisionControl>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__COLLISION_CONTROL__TRAITS_HPP_
