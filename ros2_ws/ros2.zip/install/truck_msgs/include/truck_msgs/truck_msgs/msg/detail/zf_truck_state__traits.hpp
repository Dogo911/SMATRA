// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfTruckState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_truck_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfTruckState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: mode_lat
  {
    out << "mode_lat: ";
    rosidl_generator_traits::value_to_yaml(msg.mode_lat, out);
    out << ", ";
  }

  // member: mode_long
  {
    out << "mode_long: ";
    rosidl_generator_traits::value_to_yaml(msg.mode_long, out);
    out << ", ";
  }

  // member: control_v
  {
    out << "control_v: ";
    rosidl_generator_traits::value_to_yaml(msg.control_v, out);
    out << ", ";
  }

  // member: control_a
  {
    out << "control_a: ";
    rosidl_generator_traits::value_to_yaml(msg.control_a, out);
    out << ", ";
  }

  // member: control_delta
  {
    out << "control_delta: ";
    rosidl_generator_traits::value_to_yaml(msg.control_delta, out);
    out << ", ";
  }

  // member: control_v_delta
  {
    out << "control_v_delta: ";
    rosidl_generator_traits::value_to_yaml(msg.control_v_delta, out);
    out << ", ";
  }

  // member: v
  {
    out << "v: ";
    rosidl_generator_traits::value_to_yaml(msg.v, out);
    out << ", ";
  }

  // member: delta
  {
    out << "delta: ";
    rosidl_generator_traits::value_to_yaml(msg.delta, out);
    out << ", ";
  }

  // member: cmd_steer
  {
    out << "cmd_steer: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_steer, out);
    out << ", ";
  }

  // member: cmd_speed
  {
    out << "cmd_speed: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_speed, out);
    out << ", ";
  }

  // member: cycle_ard0
  {
    out << "cycle_ard0: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle_ard0, out);
    out << ", ";
  }

  // member: cycle_hub
  {
    out << "cycle_hub: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle_hub, out);
    out << ", ";
  }

  // member: cycle_tf
  {
    out << "cycle_tf: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle_tf, out);
    out << ", ";
  }

  // member: btn_emerg_stop
  {
    out << "btn_emerg_stop: ";
    rosidl_generator_traits::value_to_yaml(msg.btn_emerg_stop, out);
    out << ", ";
  }

  // member: emerg_stop
  {
    out << "emerg_stop: ";
    rosidl_generator_traits::value_to_yaml(msg.emerg_stop, out);
    out << ", ";
  }

  // member: emerg_stop_rsn
  {
    out << "emerg_stop_rsn: ";
    rosidl_generator_traits::value_to_yaml(msg.emerg_stop_rsn, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfTruckState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: mode_lat
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mode_lat: ";
    rosidl_generator_traits::value_to_yaml(msg.mode_lat, out);
    out << "\n";
  }

  // member: mode_long
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mode_long: ";
    rosidl_generator_traits::value_to_yaml(msg.mode_long, out);
    out << "\n";
  }

  // member: control_v
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_v: ";
    rosidl_generator_traits::value_to_yaml(msg.control_v, out);
    out << "\n";
  }

  // member: control_a
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_a: ";
    rosidl_generator_traits::value_to_yaml(msg.control_a, out);
    out << "\n";
  }

  // member: control_delta
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_delta: ";
    rosidl_generator_traits::value_to_yaml(msg.control_delta, out);
    out << "\n";
  }

  // member: control_v_delta
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_v_delta: ";
    rosidl_generator_traits::value_to_yaml(msg.control_v_delta, out);
    out << "\n";
  }

  // member: v
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "v: ";
    rosidl_generator_traits::value_to_yaml(msg.v, out);
    out << "\n";
  }

  // member: delta
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "delta: ";
    rosidl_generator_traits::value_to_yaml(msg.delta, out);
    out << "\n";
  }

  // member: cmd_steer
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_steer: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_steer, out);
    out << "\n";
  }

  // member: cmd_speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_speed: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_speed, out);
    out << "\n";
  }

  // member: cycle_ard0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cycle_ard0: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle_ard0, out);
    out << "\n";
  }

  // member: cycle_hub
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cycle_hub: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle_hub, out);
    out << "\n";
  }

  // member: cycle_tf
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cycle_tf: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle_tf, out);
    out << "\n";
  }

  // member: btn_emerg_stop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "btn_emerg_stop: ";
    rosidl_generator_traits::value_to_yaml(msg.btn_emerg_stop, out);
    out << "\n";
  }

  // member: emerg_stop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "emerg_stop: ";
    rosidl_generator_traits::value_to_yaml(msg.emerg_stop, out);
    out << "\n";
  }

  // member: emerg_stop_rsn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "emerg_stop_rsn: ";
    rosidl_generator_traits::value_to_yaml(msg.emerg_stop_rsn, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfTruckState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfTruckState & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfTruckState & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfTruckState>()
{
  return "truck_msgs::msg::ZfTruckState";
}

template<>
inline const char * name<truck_msgs::msg::ZfTruckState>()
{
  return "truck_msgs/msg/ZfTruckState";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfTruckState>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfTruckState>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfTruckState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__TRAITS_HPP_
