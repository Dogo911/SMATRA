// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/ZfTruckState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__ZfTruckState __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__ZfTruckState __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ZfTruckState_
{
  using Type = ZfTruckState_<ContainerAllocator>;

  explicit ZfTruckState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mode_lat = 0;
      this->mode_long = 0;
      this->control_v = 0.0f;
      this->control_a = 0.0f;
      this->control_delta = 0.0f;
      this->control_v_delta = 0.0f;
      this->v = 0.0f;
      this->delta = 0.0f;
      this->cmd_steer = 0;
      this->cmd_speed = 0;
      this->cycle_ard0 = 0ul;
      this->cycle_hub = 0ul;
      this->cycle_tf = 0ul;
      this->btn_emerg_stop = false;
      this->emerg_stop = false;
      this->emerg_stop_rsn = 0;
    }
  }

  explicit ZfTruckState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mode_lat = 0;
      this->mode_long = 0;
      this->control_v = 0.0f;
      this->control_a = 0.0f;
      this->control_delta = 0.0f;
      this->control_v_delta = 0.0f;
      this->v = 0.0f;
      this->delta = 0.0f;
      this->cmd_steer = 0;
      this->cmd_speed = 0;
      this->cycle_ard0 = 0ul;
      this->cycle_hub = 0ul;
      this->cycle_tf = 0ul;
      this->btn_emerg_stop = false;
      this->emerg_stop = false;
      this->emerg_stop_rsn = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _mode_lat_type =
    int8_t;
  _mode_lat_type mode_lat;
  using _mode_long_type =
    int8_t;
  _mode_long_type mode_long;
  using _control_v_type =
    float;
  _control_v_type control_v;
  using _control_a_type =
    float;
  _control_a_type control_a;
  using _control_delta_type =
    float;
  _control_delta_type control_delta;
  using _control_v_delta_type =
    float;
  _control_v_delta_type control_v_delta;
  using _v_type =
    float;
  _v_type v;
  using _delta_type =
    float;
  _delta_type delta;
  using _cmd_steer_type =
    int8_t;
  _cmd_steer_type cmd_steer;
  using _cmd_speed_type =
    int8_t;
  _cmd_speed_type cmd_speed;
  using _cycle_ard0_type =
    uint32_t;
  _cycle_ard0_type cycle_ard0;
  using _cycle_hub_type =
    uint32_t;
  _cycle_hub_type cycle_hub;
  using _cycle_tf_type =
    uint32_t;
  _cycle_tf_type cycle_tf;
  using _btn_emerg_stop_type =
    bool;
  _btn_emerg_stop_type btn_emerg_stop;
  using _emerg_stop_type =
    bool;
  _emerg_stop_type emerg_stop;
  using _emerg_stop_rsn_type =
    int16_t;
  _emerg_stop_rsn_type emerg_stop_rsn;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__mode_lat(
    const int8_t & _arg)
  {
    this->mode_lat = _arg;
    return *this;
  }
  Type & set__mode_long(
    const int8_t & _arg)
  {
    this->mode_long = _arg;
    return *this;
  }
  Type & set__control_v(
    const float & _arg)
  {
    this->control_v = _arg;
    return *this;
  }
  Type & set__control_a(
    const float & _arg)
  {
    this->control_a = _arg;
    return *this;
  }
  Type & set__control_delta(
    const float & _arg)
  {
    this->control_delta = _arg;
    return *this;
  }
  Type & set__control_v_delta(
    const float & _arg)
  {
    this->control_v_delta = _arg;
    return *this;
  }
  Type & set__v(
    const float & _arg)
  {
    this->v = _arg;
    return *this;
  }
  Type & set__delta(
    const float & _arg)
  {
    this->delta = _arg;
    return *this;
  }
  Type & set__cmd_steer(
    const int8_t & _arg)
  {
    this->cmd_steer = _arg;
    return *this;
  }
  Type & set__cmd_speed(
    const int8_t & _arg)
  {
    this->cmd_speed = _arg;
    return *this;
  }
  Type & set__cycle_ard0(
    const uint32_t & _arg)
  {
    this->cycle_ard0 = _arg;
    return *this;
  }
  Type & set__cycle_hub(
    const uint32_t & _arg)
  {
    this->cycle_hub = _arg;
    return *this;
  }
  Type & set__cycle_tf(
    const uint32_t & _arg)
  {
    this->cycle_tf = _arg;
    return *this;
  }
  Type & set__btn_emerg_stop(
    const bool & _arg)
  {
    this->btn_emerg_stop = _arg;
    return *this;
  }
  Type & set__emerg_stop(
    const bool & _arg)
  {
    this->emerg_stop = _arg;
    return *this;
  }
  Type & set__emerg_stop_rsn(
    const int16_t & _arg)
  {
    this->emerg_stop_rsn = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::ZfTruckState_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::ZfTruckState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfTruckState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfTruckState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfTruckState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfTruckState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfTruckState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfTruckState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfTruckState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfTruckState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__ZfTruckState
    std::shared_ptr<truck_msgs::msg::ZfTruckState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__ZfTruckState
    std::shared_ptr<truck_msgs::msg::ZfTruckState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ZfTruckState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->mode_lat != other.mode_lat) {
      return false;
    }
    if (this->mode_long != other.mode_long) {
      return false;
    }
    if (this->control_v != other.control_v) {
      return false;
    }
    if (this->control_a != other.control_a) {
      return false;
    }
    if (this->control_delta != other.control_delta) {
      return false;
    }
    if (this->control_v_delta != other.control_v_delta) {
      return false;
    }
    if (this->v != other.v) {
      return false;
    }
    if (this->delta != other.delta) {
      return false;
    }
    if (this->cmd_steer != other.cmd_steer) {
      return false;
    }
    if (this->cmd_speed != other.cmd_speed) {
      return false;
    }
    if (this->cycle_ard0 != other.cycle_ard0) {
      return false;
    }
    if (this->cycle_hub != other.cycle_hub) {
      return false;
    }
    if (this->cycle_tf != other.cycle_tf) {
      return false;
    }
    if (this->btn_emerg_stop != other.btn_emerg_stop) {
      return false;
    }
    if (this->emerg_stop != other.emerg_stop) {
      return false;
    }
    if (this->emerg_stop_rsn != other.emerg_stop_rsn) {
      return false;
    }
    return true;
  }
  bool operator!=(const ZfTruckState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ZfTruckState_

// alias to use template instance with default allocator
using ZfTruckState =
  truck_msgs::msg::ZfTruckState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__STRUCT_HPP_
