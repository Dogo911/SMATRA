// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/ZfRcState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_RC_STATE__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_RC_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__ZfRcState __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__ZfRcState __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ZfRcState_
{
  using Type = ZfRcState_<ContainerAllocator>;

  explicit ZfRcState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->rc_1 = 0;
      this->rc_2 = 0;
      this->rc_3 = 0;
    }
  }

  explicit ZfRcState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->rc_1 = 0;
      this->rc_2 = 0;
      this->rc_3 = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _rc_1_type =
    int16_t;
  _rc_1_type rc_1;
  using _rc_2_type =
    int16_t;
  _rc_2_type rc_2;
  using _rc_3_type =
    int16_t;
  _rc_3_type rc_3;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__rc_1(
    const int16_t & _arg)
  {
    this->rc_1 = _arg;
    return *this;
  }
  Type & set__rc_2(
    const int16_t & _arg)
  {
    this->rc_2 = _arg;
    return *this;
  }
  Type & set__rc_3(
    const int16_t & _arg)
  {
    this->rc_3 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::ZfRcState_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::ZfRcState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfRcState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfRcState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfRcState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfRcState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfRcState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfRcState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfRcState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfRcState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__ZfRcState
    std::shared_ptr<truck_msgs::msg::ZfRcState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__ZfRcState
    std::shared_ptr<truck_msgs::msg::ZfRcState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ZfRcState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->rc_1 != other.rc_1) {
      return false;
    }
    if (this->rc_2 != other.rc_2) {
      return false;
    }
    if (this->rc_3 != other.rc_3) {
      return false;
    }
    return true;
  }
  bool operator!=(const ZfRcState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ZfRcState_

// alias to use template instance with default allocator
using ZfRcState =
  truck_msgs::msg::ZfRcState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_RC_STATE__STRUCT_HPP_
