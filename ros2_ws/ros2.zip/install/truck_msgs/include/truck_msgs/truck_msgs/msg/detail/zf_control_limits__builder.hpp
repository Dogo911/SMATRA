// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfControlLimits.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_LIMITS__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_LIMITS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_control_limits__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfControlLimits_accel_max
{
public:
  explicit Init_ZfControlLimits_accel_max(::truck_msgs::msg::ZfControlLimits & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfControlLimits accel_max(::truck_msgs::msg::ZfControlLimits::_accel_max_type arg)
  {
    msg_.accel_max = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlLimits msg_;
};

class Init_ZfControlLimits_accel_min
{
public:
  explicit Init_ZfControlLimits_accel_min(::truck_msgs::msg::ZfControlLimits & msg)
  : msg_(msg)
  {}
  Init_ZfControlLimits_accel_max accel_min(::truck_msgs::msg::ZfControlLimits::_accel_min_type arg)
  {
    msg_.accel_min = std::move(arg);
    return Init_ZfControlLimits_accel_max(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlLimits msg_;
};

class Init_ZfControlLimits_speed_max
{
public:
  explicit Init_ZfControlLimits_speed_max(::truck_msgs::msg::ZfControlLimits & msg)
  : msg_(msg)
  {}
  Init_ZfControlLimits_accel_min speed_max(::truck_msgs::msg::ZfControlLimits::_speed_max_type arg)
  {
    msg_.speed_max = std::move(arg);
    return Init_ZfControlLimits_accel_min(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlLimits msg_;
};

class Init_ZfControlLimits_speed_min
{
public:
  explicit Init_ZfControlLimits_speed_min(::truck_msgs::msg::ZfControlLimits & msg)
  : msg_(msg)
  {}
  Init_ZfControlLimits_speed_max speed_min(::truck_msgs::msg::ZfControlLimits::_speed_min_type arg)
  {
    msg_.speed_min = std::move(arg);
    return Init_ZfControlLimits_speed_max(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlLimits msg_;
};

class Init_ZfControlLimits_steering_max
{
public:
  explicit Init_ZfControlLimits_steering_max(::truck_msgs::msg::ZfControlLimits & msg)
  : msg_(msg)
  {}
  Init_ZfControlLimits_speed_min steering_max(::truck_msgs::msg::ZfControlLimits::_steering_max_type arg)
  {
    msg_.steering_max = std::move(arg);
    return Init_ZfControlLimits_speed_min(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlLimits msg_;
};

class Init_ZfControlLimits_steering_min
{
public:
  explicit Init_ZfControlLimits_steering_min(::truck_msgs::msg::ZfControlLimits & msg)
  : msg_(msg)
  {}
  Init_ZfControlLimits_steering_max steering_min(::truck_msgs::msg::ZfControlLimits::_steering_min_type arg)
  {
    msg_.steering_min = std::move(arg);
    return Init_ZfControlLimits_steering_max(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlLimits msg_;
};

class Init_ZfControlLimits_header
{
public:
  Init_ZfControlLimits_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfControlLimits_steering_min header(::truck_msgs::msg::ZfControlLimits::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfControlLimits_steering_min(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlLimits msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfControlLimits>()
{
  return truck_msgs::msg::builder::Init_ZfControlLimits_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_LIMITS__BUILDER_HPP_
