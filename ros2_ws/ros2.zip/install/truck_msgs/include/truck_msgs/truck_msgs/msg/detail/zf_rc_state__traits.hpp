// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfRcState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_RC_STATE__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_RC_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_rc_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfRcState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: rc_1
  {
    out << "rc_1: ";
    rosidl_generator_traits::value_to_yaml(msg.rc_1, out);
    out << ", ";
  }

  // member: rc_2
  {
    out << "rc_2: ";
    rosidl_generator_traits::value_to_yaml(msg.rc_2, out);
    out << ", ";
  }

  // member: rc_3
  {
    out << "rc_3: ";
    rosidl_generator_traits::value_to_yaml(msg.rc_3, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfRcState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: rc_1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rc_1: ";
    rosidl_generator_traits::value_to_yaml(msg.rc_1, out);
    out << "\n";
  }

  // member: rc_2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rc_2: ";
    rosidl_generator_traits::value_to_yaml(msg.rc_2, out);
    out << "\n";
  }

  // member: rc_3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rc_3: ";
    rosidl_generator_traits::value_to_yaml(msg.rc_3, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfRcState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfRcState & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfRcState & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfRcState>()
{
  return "truck_msgs::msg::ZfRcState";
}

template<>
inline const char * name<truck_msgs::msg::ZfRcState>()
{
  return "truck_msgs/msg/ZfRcState";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfRcState>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfRcState>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfRcState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_RC_STATE__TRAITS_HPP_
