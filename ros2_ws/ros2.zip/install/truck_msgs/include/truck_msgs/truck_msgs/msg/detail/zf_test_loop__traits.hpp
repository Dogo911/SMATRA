// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfTestLoop.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_test_loop__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfTestLoop & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: sender
  {
    out << "sender: ";
    rosidl_generator_traits::value_to_yaml(msg.sender, out);
    out << ", ";
  }

  // member: timestamp_ros_out
  {
    out << "timestamp_ros_out: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_ros_out, out);
    out << ", ";
  }

  // member: timestamp_bridge_out
  {
    out << "timestamp_bridge_out: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_bridge_out, out);
    out << ", ";
  }

  // member: timestamp_master_out
  {
    out << "timestamp_master_out: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_master_out, out);
    out << ", ";
  }

  // member: timestamp_slave
  {
    out << "timestamp_slave: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_slave, out);
    out << ", ";
  }

  // member: timestamp_master_in
  {
    out << "timestamp_master_in: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_master_in, out);
    out << ", ";
  }

  // member: timestamp_bridge_in
  {
    out << "timestamp_bridge_in: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_bridge_in, out);
    out << ", ";
  }

  // member: timestamp_ros_in
  {
    out << "timestamp_ros_in: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_ros_in, out);
    out << ", ";
  }

  // member: master_to_master
  {
    out << "master_to_master: ";
    rosidl_generator_traits::value_to_yaml(msg.master_to_master, out);
    out << ", ";
  }

  // member: bridge_to_bridge
  {
    out << "bridge_to_bridge: ";
    rosidl_generator_traits::value_to_yaml(msg.bridge_to_bridge, out);
    out << ", ";
  }

  // member: ros_to_ros
  {
    out << "ros_to_ros: ";
    rosidl_generator_traits::value_to_yaml(msg.ros_to_ros, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfTestLoop & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: sender
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sender: ";
    rosidl_generator_traits::value_to_yaml(msg.sender, out);
    out << "\n";
  }

  // member: timestamp_ros_out
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_ros_out: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_ros_out, out);
    out << "\n";
  }

  // member: timestamp_bridge_out
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_bridge_out: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_bridge_out, out);
    out << "\n";
  }

  // member: timestamp_master_out
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_master_out: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_master_out, out);
    out << "\n";
  }

  // member: timestamp_slave
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_slave: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_slave, out);
    out << "\n";
  }

  // member: timestamp_master_in
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_master_in: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_master_in, out);
    out << "\n";
  }

  // member: timestamp_bridge_in
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_bridge_in: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_bridge_in, out);
    out << "\n";
  }

  // member: timestamp_ros_in
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_ros_in: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_ros_in, out);
    out << "\n";
  }

  // member: master_to_master
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "master_to_master: ";
    rosidl_generator_traits::value_to_yaml(msg.master_to_master, out);
    out << "\n";
  }

  // member: bridge_to_bridge
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "bridge_to_bridge: ";
    rosidl_generator_traits::value_to_yaml(msg.bridge_to_bridge, out);
    out << "\n";
  }

  // member: ros_to_ros
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ros_to_ros: ";
    rosidl_generator_traits::value_to_yaml(msg.ros_to_ros, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfTestLoop & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfTestLoop & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfTestLoop & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfTestLoop>()
{
  return "truck_msgs::msg::ZfTestLoop";
}

template<>
inline const char * name<truck_msgs::msg::ZfTestLoop>()
{
  return "truck_msgs/msg/ZfTestLoop";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfTestLoop>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfTestLoop>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfTestLoop>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__TRAITS_HPP_
