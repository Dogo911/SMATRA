// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:msg/ZfTruckStateSlow.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__ZF_TRUCK_STATE_SLOW_H_
#define TRUCK_MSGS__MSG__ZF_TRUCK_STATE_SLOW_H_

#include "truck_msgs/msg/detail/zf_truck_state_slow__struct.h"
#include "truck_msgs/msg/detail/zf_truck_state_slow__functions.h"
#include "truck_msgs/msg/detail/zf_truck_state_slow__type_support.h"

#endif  // TRUCK_MSGS__MSG__ZF_TRUCK_STATE_SLOW_H_
