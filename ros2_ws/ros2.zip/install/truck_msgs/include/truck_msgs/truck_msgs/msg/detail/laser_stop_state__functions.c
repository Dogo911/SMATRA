// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/LaserStopState.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/laser_stop_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `tp`
#include "geometry_msgs/msg/detail/point__functions.h"

bool
truck_msgs__msg__LaserStopState__init(truck_msgs__msg__LaserStopState * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    truck_msgs__msg__LaserStopState__fini(msg);
    return false;
  }
  // sensor_active
  // control_active
  // rviz_marker
  // cycle
  // tp
  if (!geometry_msgs__msg__Point__init(&msg->tp)) {
    truck_msgs__msg__LaserStopState__fini(msg);
    return false;
  }
  // min_dist
  // ttc
  // v_target
  // steering_min
  // steering_max
  // speed_min
  // speed_max
  // accel_min
  // accel_max
  return true;
}

void
truck_msgs__msg__LaserStopState__fini(truck_msgs__msg__LaserStopState * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // sensor_active
  // control_active
  // rviz_marker
  // cycle
  // tp
  geometry_msgs__msg__Point__fini(&msg->tp);
  // min_dist
  // ttc
  // v_target
  // steering_min
  // steering_max
  // speed_min
  // speed_max
  // accel_min
  // accel_max
}

bool
truck_msgs__msg__LaserStopState__are_equal(const truck_msgs__msg__LaserStopState * lhs, const truck_msgs__msg__LaserStopState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // sensor_active
  if (lhs->sensor_active != rhs->sensor_active) {
    return false;
  }
  // control_active
  if (lhs->control_active != rhs->control_active) {
    return false;
  }
  // rviz_marker
  if (lhs->rviz_marker != rhs->rviz_marker) {
    return false;
  }
  // cycle
  if (lhs->cycle != rhs->cycle) {
    return false;
  }
  // tp
  if (!geometry_msgs__msg__Point__are_equal(
      &(lhs->tp), &(rhs->tp)))
  {
    return false;
  }
  // min_dist
  if (lhs->min_dist != rhs->min_dist) {
    return false;
  }
  // ttc
  if (lhs->ttc != rhs->ttc) {
    return false;
  }
  // v_target
  if (lhs->v_target != rhs->v_target) {
    return false;
  }
  // steering_min
  if (lhs->steering_min != rhs->steering_min) {
    return false;
  }
  // steering_max
  if (lhs->steering_max != rhs->steering_max) {
    return false;
  }
  // speed_min
  if (lhs->speed_min != rhs->speed_min) {
    return false;
  }
  // speed_max
  if (lhs->speed_max != rhs->speed_max) {
    return false;
  }
  // accel_min
  if (lhs->accel_min != rhs->accel_min) {
    return false;
  }
  // accel_max
  if (lhs->accel_max != rhs->accel_max) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__LaserStopState__copy(
  const truck_msgs__msg__LaserStopState * input,
  truck_msgs__msg__LaserStopState * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // sensor_active
  output->sensor_active = input->sensor_active;
  // control_active
  output->control_active = input->control_active;
  // rviz_marker
  output->rviz_marker = input->rviz_marker;
  // cycle
  output->cycle = input->cycle;
  // tp
  if (!geometry_msgs__msg__Point__copy(
      &(input->tp), &(output->tp)))
  {
    return false;
  }
  // min_dist
  output->min_dist = input->min_dist;
  // ttc
  output->ttc = input->ttc;
  // v_target
  output->v_target = input->v_target;
  // steering_min
  output->steering_min = input->steering_min;
  // steering_max
  output->steering_max = input->steering_max;
  // speed_min
  output->speed_min = input->speed_min;
  // speed_max
  output->speed_max = input->speed_max;
  // accel_min
  output->accel_min = input->accel_min;
  // accel_max
  output->accel_max = input->accel_max;
  return true;
}

truck_msgs__msg__LaserStopState *
truck_msgs__msg__LaserStopState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__LaserStopState * msg = (truck_msgs__msg__LaserStopState *)allocator.allocate(sizeof(truck_msgs__msg__LaserStopState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__LaserStopState));
  bool success = truck_msgs__msg__LaserStopState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__LaserStopState__destroy(truck_msgs__msg__LaserStopState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__LaserStopState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__LaserStopState__Sequence__init(truck_msgs__msg__LaserStopState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__LaserStopState * data = NULL;

  if (size) {
    data = (truck_msgs__msg__LaserStopState *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__LaserStopState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__LaserStopState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__LaserStopState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__LaserStopState__Sequence__fini(truck_msgs__msg__LaserStopState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__LaserStopState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__LaserStopState__Sequence *
truck_msgs__msg__LaserStopState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__LaserStopState__Sequence * array = (truck_msgs__msg__LaserStopState__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__LaserStopState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__LaserStopState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__LaserStopState__Sequence__destroy(truck_msgs__msg__LaserStopState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__LaserStopState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__LaserStopState__Sequence__are_equal(const truck_msgs__msg__LaserStopState__Sequence * lhs, const truck_msgs__msg__LaserStopState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__LaserStopState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__LaserStopState__Sequence__copy(
  const truck_msgs__msg__LaserStopState__Sequence * input,
  truck_msgs__msg__LaserStopState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__LaserStopState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__LaserStopState * data =
      (truck_msgs__msg__LaserStopState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__LaserStopState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__LaserStopState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__LaserStopState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
