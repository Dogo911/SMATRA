// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/SafeRcState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__SafeRcState __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__SafeRcState __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SafeRcState_
{
  using Type = SafeRcState_<ContainerAllocator>;

  explicit SafeRcState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor_active = 0;
      this->control_active = 0;
      this->rviz_lines = 0;
      this->cycle = 0ll;
      this->scenario = 0;
      this->scenario_lower = 0;
      this->scenario_upper = 0;
      this->left_wall = 0;
      this->middle_wall = 0;
      this->right_wall = 0;
      this->lower_corner = 0;
      this->upper_corner = 0;
      this->steering_min = 0.0f;
      this->steering_max = 0.0f;
      this->speed_min = 0.0f;
      this->speed_max = 0.0f;
      this->accel_min = 0.0f;
      this->accel_max = 0.0f;
    }
  }

  explicit SafeRcState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor_active = 0;
      this->control_active = 0;
      this->rviz_lines = 0;
      this->cycle = 0ll;
      this->scenario = 0;
      this->scenario_lower = 0;
      this->scenario_upper = 0;
      this->left_wall = 0;
      this->middle_wall = 0;
      this->right_wall = 0;
      this->lower_corner = 0;
      this->upper_corner = 0;
      this->steering_min = 0.0f;
      this->steering_max = 0.0f;
      this->speed_min = 0.0f;
      this->speed_max = 0.0f;
      this->accel_min = 0.0f;
      this->accel_max = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _sensor_active_type =
    int16_t;
  _sensor_active_type sensor_active;
  using _control_active_type =
    int16_t;
  _control_active_type control_active;
  using _rviz_lines_type =
    int16_t;
  _rviz_lines_type rviz_lines;
  using _cycle_type =
    int64_t;
  _cycle_type cycle;
  using _scenario_type =
    int16_t;
  _scenario_type scenario;
  using _scenario_lower_type =
    int16_t;
  _scenario_lower_type scenario_lower;
  using _scenario_upper_type =
    int16_t;
  _scenario_upper_type scenario_upper;
  using _left_wall_type =
    int16_t;
  _left_wall_type left_wall;
  using _middle_wall_type =
    int16_t;
  _middle_wall_type middle_wall;
  using _right_wall_type =
    int16_t;
  _right_wall_type right_wall;
  using _lower_corner_type =
    int16_t;
  _lower_corner_type lower_corner;
  using _upper_corner_type =
    int16_t;
  _upper_corner_type upper_corner;
  using _steering_min_type =
    float;
  _steering_min_type steering_min;
  using _steering_max_type =
    float;
  _steering_max_type steering_max;
  using _speed_min_type =
    float;
  _speed_min_type speed_min;
  using _speed_max_type =
    float;
  _speed_max_type speed_max;
  using _accel_min_type =
    float;
  _accel_min_type accel_min;
  using _accel_max_type =
    float;
  _accel_max_type accel_max;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__sensor_active(
    const int16_t & _arg)
  {
    this->sensor_active = _arg;
    return *this;
  }
  Type & set__control_active(
    const int16_t & _arg)
  {
    this->control_active = _arg;
    return *this;
  }
  Type & set__rviz_lines(
    const int16_t & _arg)
  {
    this->rviz_lines = _arg;
    return *this;
  }
  Type & set__cycle(
    const int64_t & _arg)
  {
    this->cycle = _arg;
    return *this;
  }
  Type & set__scenario(
    const int16_t & _arg)
  {
    this->scenario = _arg;
    return *this;
  }
  Type & set__scenario_lower(
    const int16_t & _arg)
  {
    this->scenario_lower = _arg;
    return *this;
  }
  Type & set__scenario_upper(
    const int16_t & _arg)
  {
    this->scenario_upper = _arg;
    return *this;
  }
  Type & set__left_wall(
    const int16_t & _arg)
  {
    this->left_wall = _arg;
    return *this;
  }
  Type & set__middle_wall(
    const int16_t & _arg)
  {
    this->middle_wall = _arg;
    return *this;
  }
  Type & set__right_wall(
    const int16_t & _arg)
  {
    this->right_wall = _arg;
    return *this;
  }
  Type & set__lower_corner(
    const int16_t & _arg)
  {
    this->lower_corner = _arg;
    return *this;
  }
  Type & set__upper_corner(
    const int16_t & _arg)
  {
    this->upper_corner = _arg;
    return *this;
  }
  Type & set__steering_min(
    const float & _arg)
  {
    this->steering_min = _arg;
    return *this;
  }
  Type & set__steering_max(
    const float & _arg)
  {
    this->steering_max = _arg;
    return *this;
  }
  Type & set__speed_min(
    const float & _arg)
  {
    this->speed_min = _arg;
    return *this;
  }
  Type & set__speed_max(
    const float & _arg)
  {
    this->speed_max = _arg;
    return *this;
  }
  Type & set__accel_min(
    const float & _arg)
  {
    this->accel_min = _arg;
    return *this;
  }
  Type & set__accel_max(
    const float & _arg)
  {
    this->accel_max = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::SafeRcState_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::SafeRcState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::SafeRcState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::SafeRcState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::SafeRcState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::SafeRcState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::SafeRcState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::SafeRcState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::SafeRcState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::SafeRcState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__SafeRcState
    std::shared_ptr<truck_msgs::msg::SafeRcState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__SafeRcState
    std::shared_ptr<truck_msgs::msg::SafeRcState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SafeRcState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->sensor_active != other.sensor_active) {
      return false;
    }
    if (this->control_active != other.control_active) {
      return false;
    }
    if (this->rviz_lines != other.rviz_lines) {
      return false;
    }
    if (this->cycle != other.cycle) {
      return false;
    }
    if (this->scenario != other.scenario) {
      return false;
    }
    if (this->scenario_lower != other.scenario_lower) {
      return false;
    }
    if (this->scenario_upper != other.scenario_upper) {
      return false;
    }
    if (this->left_wall != other.left_wall) {
      return false;
    }
    if (this->middle_wall != other.middle_wall) {
      return false;
    }
    if (this->right_wall != other.right_wall) {
      return false;
    }
    if (this->lower_corner != other.lower_corner) {
      return false;
    }
    if (this->upper_corner != other.upper_corner) {
      return false;
    }
    if (this->steering_min != other.steering_min) {
      return false;
    }
    if (this->steering_max != other.steering_max) {
      return false;
    }
    if (this->speed_min != other.speed_min) {
      return false;
    }
    if (this->speed_max != other.speed_max) {
      return false;
    }
    if (this->accel_min != other.accel_min) {
      return false;
    }
    if (this->accel_max != other.accel_max) {
      return false;
    }
    return true;
  }
  bool operator!=(const SafeRcState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SafeRcState_

// alias to use template instance with default allocator
using SafeRcState =
  truck_msgs::msg::SafeRcState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__STRUCT_HPP_
