﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfSensorConfig.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'config'
#include "truck_msgs/msg/detail/zf_sensor_config_one__struct.h"

/// Struct defined in msg/ZfSensorConfig in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * zf_sensor_config.msg
  *
  * Version 5.7
 */
typedef struct truck_msgs__msg__ZfSensorConfig
{
  truck_msgs__msg__ZfSensorConfigOne config[7];
  /// Anzahl gültiger Werte
  int16_t cnt;
} truck_msgs__msg__ZfSensorConfig;

// Struct for a sequence of truck_msgs__msg__ZfSensorConfig.
typedef struct truck_msgs__msg__ZfSensorConfig__Sequence
{
  truck_msgs__msg__ZfSensorConfig * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfSensorConfig__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG__STRUCT_H_
