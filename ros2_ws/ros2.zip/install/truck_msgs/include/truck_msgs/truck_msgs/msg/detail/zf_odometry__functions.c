// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/ZfOdometry.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/zf_odometry__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
truck_msgs__msg__ZfOdometry__init(truck_msgs__msg__ZfOdometry * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    truck_msgs__msg__ZfOdometry__fini(msg);
    return false;
  }
  // dist_left
  // dist_right
  // dist_back
  // delta_encoder
  // yaw
  // yaw_diff
  return true;
}

void
truck_msgs__msg__ZfOdometry__fini(truck_msgs__msg__ZfOdometry * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // dist_left
  // dist_right
  // dist_back
  // delta_encoder
  // yaw
  // yaw_diff
}

bool
truck_msgs__msg__ZfOdometry__are_equal(const truck_msgs__msg__ZfOdometry * lhs, const truck_msgs__msg__ZfOdometry * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // dist_left
  if (lhs->dist_left != rhs->dist_left) {
    return false;
  }
  // dist_right
  if (lhs->dist_right != rhs->dist_right) {
    return false;
  }
  // dist_back
  if (lhs->dist_back != rhs->dist_back) {
    return false;
  }
  // delta_encoder
  if (lhs->delta_encoder != rhs->delta_encoder) {
    return false;
  }
  // yaw
  if (lhs->yaw != rhs->yaw) {
    return false;
  }
  // yaw_diff
  if (lhs->yaw_diff != rhs->yaw_diff) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__ZfOdometry__copy(
  const truck_msgs__msg__ZfOdometry * input,
  truck_msgs__msg__ZfOdometry * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // dist_left
  output->dist_left = input->dist_left;
  // dist_right
  output->dist_right = input->dist_right;
  // dist_back
  output->dist_back = input->dist_back;
  // delta_encoder
  output->delta_encoder = input->delta_encoder;
  // yaw
  output->yaw = input->yaw;
  // yaw_diff
  output->yaw_diff = input->yaw_diff;
  return true;
}

truck_msgs__msg__ZfOdometry *
truck_msgs__msg__ZfOdometry__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfOdometry * msg = (truck_msgs__msg__ZfOdometry *)allocator.allocate(sizeof(truck_msgs__msg__ZfOdometry), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__ZfOdometry));
  bool success = truck_msgs__msg__ZfOdometry__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__ZfOdometry__destroy(truck_msgs__msg__ZfOdometry * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__ZfOdometry__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__ZfOdometry__Sequence__init(truck_msgs__msg__ZfOdometry__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfOdometry * data = NULL;

  if (size) {
    data = (truck_msgs__msg__ZfOdometry *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__ZfOdometry), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__ZfOdometry__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__ZfOdometry__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__ZfOdometry__Sequence__fini(truck_msgs__msg__ZfOdometry__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__ZfOdometry__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__ZfOdometry__Sequence *
truck_msgs__msg__ZfOdometry__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfOdometry__Sequence * array = (truck_msgs__msg__ZfOdometry__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__ZfOdometry__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__ZfOdometry__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__ZfOdometry__Sequence__destroy(truck_msgs__msg__ZfOdometry__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__ZfOdometry__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__ZfOdometry__Sequence__are_equal(const truck_msgs__msg__ZfOdometry__Sequence * lhs, const truck_msgs__msg__ZfOdometry__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__ZfOdometry__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__ZfOdometry__Sequence__copy(
  const truck_msgs__msg__ZfOdometry__Sequence * input,
  truck_msgs__msg__ZfOdometry__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__ZfOdometry);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__ZfOdometry * data =
      (truck_msgs__msg__ZfOdometry *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__ZfOdometry__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__ZfOdometry__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__ZfOdometry__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
