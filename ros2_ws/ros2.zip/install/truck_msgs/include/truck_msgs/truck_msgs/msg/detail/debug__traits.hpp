// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/Debug.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__DEBUG__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__DEBUG__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/debug__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Debug & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: enc_diff_left
  {
    out << "enc_diff_left: ";
    rosidl_generator_traits::value_to_yaml(msg.enc_diff_left, out);
    out << ", ";
  }

  // member: enc_diff_right
  {
    out << "enc_diff_right: ";
    rosidl_generator_traits::value_to_yaml(msg.enc_diff_right, out);
    out << ", ";
  }

  // member: enc_diff_back
  {
    out << "enc_diff_back: ";
    rosidl_generator_traits::value_to_yaml(msg.enc_diff_back, out);
    out << ", ";
  }

  // member: enc_diff_lr
  {
    out << "enc_diff_lr: ";
    rosidl_generator_traits::value_to_yaml(msg.enc_diff_lr, out);
    out << ", ";
  }

  // member: wheel_diff_left
  {
    out << "wheel_diff_left: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_left, out);
    out << ", ";
  }

  // member: wheel_diff_right
  {
    out << "wheel_diff_right: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_right, out);
    out << ", ";
  }

  // member: wheel_diff_back
  {
    out << "wheel_diff_back: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_back, out);
    out << ", ";
  }

  // member: wheel_diff_lr
  {
    out << "wheel_diff_lr: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_lr, out);
    out << ", ";
  }

  // member: steering_diff
  {
    out << "steering_diff: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_diff, out);
    out << ", ";
  }

  // member: wheel_diff_steer
  {
    out << "wheel_diff_steer: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_steer, out);
    out << ", ";
  }

  // member: dyaw
  {
    out << "dyaw: ";
    rosidl_generator_traits::value_to_yaml(msg.dyaw, out);
    out << ", ";
  }

  // member: steering_angle
  {
    out << "steering_angle: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_angle, out);
    out << ", ";
  }

  // member: wheelbase
  {
    out << "wheelbase: ";
    rosidl_generator_traits::value_to_yaml(msg.wheelbase, out);
    out << ", ";
  }

  // member: dx
  {
    out << "dx: ";
    rosidl_generator_traits::value_to_yaml(msg.dx, out);
    out << ", ";
  }

  // member: dy
  {
    out << "dy: ";
    rosidl_generator_traits::value_to_yaml(msg.dy, out);
    out << ", ";
  }

  // member: delta_x
  {
    out << "delta_x: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_x, out);
    out << ", ";
  }

  // member: delta_y
  {
    out << "delta_y: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_y, out);
    out << ", ";
  }

  // member: x
  {
    out << "x: ";
    rosidl_generator_traits::value_to_yaml(msg.x, out);
    out << ", ";
  }

  // member: y
  {
    out << "y: ";
    rosidl_generator_traits::value_to_yaml(msg.y, out);
    out << ", ";
  }

  // member: yaw
  {
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
    out << ", ";
  }

  // member: x_t
  {
    out << "x_t: ";
    rosidl_generator_traits::value_to_yaml(msg.x_t, out);
    out << ", ";
  }

  // member: y_t
  {
    out << "y_t: ";
    rosidl_generator_traits::value_to_yaml(msg.y_t, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Debug & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: enc_diff_left
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "enc_diff_left: ";
    rosidl_generator_traits::value_to_yaml(msg.enc_diff_left, out);
    out << "\n";
  }

  // member: enc_diff_right
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "enc_diff_right: ";
    rosidl_generator_traits::value_to_yaml(msg.enc_diff_right, out);
    out << "\n";
  }

  // member: enc_diff_back
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "enc_diff_back: ";
    rosidl_generator_traits::value_to_yaml(msg.enc_diff_back, out);
    out << "\n";
  }

  // member: enc_diff_lr
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "enc_diff_lr: ";
    rosidl_generator_traits::value_to_yaml(msg.enc_diff_lr, out);
    out << "\n";
  }

  // member: wheel_diff_left
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheel_diff_left: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_left, out);
    out << "\n";
  }

  // member: wheel_diff_right
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheel_diff_right: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_right, out);
    out << "\n";
  }

  // member: wheel_diff_back
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheel_diff_back: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_back, out);
    out << "\n";
  }

  // member: wheel_diff_lr
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheel_diff_lr: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_lr, out);
    out << "\n";
  }

  // member: steering_diff
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_diff: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_diff, out);
    out << "\n";
  }

  // member: wheel_diff_steer
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheel_diff_steer: ";
    rosidl_generator_traits::value_to_yaml(msg.wheel_diff_steer, out);
    out << "\n";
  }

  // member: dyaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dyaw: ";
    rosidl_generator_traits::value_to_yaml(msg.dyaw, out);
    out << "\n";
  }

  // member: steering_angle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_angle: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_angle, out);
    out << "\n";
  }

  // member: wheelbase
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wheelbase: ";
    rosidl_generator_traits::value_to_yaml(msg.wheelbase, out);
    out << "\n";
  }

  // member: dx
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dx: ";
    rosidl_generator_traits::value_to_yaml(msg.dx, out);
    out << "\n";
  }

  // member: dy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dy: ";
    rosidl_generator_traits::value_to_yaml(msg.dy, out);
    out << "\n";
  }

  // member: delta_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "delta_x: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_x, out);
    out << "\n";
  }

  // member: delta_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "delta_y: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_y, out);
    out << "\n";
  }

  // member: x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x: ";
    rosidl_generator_traits::value_to_yaml(msg.x, out);
    out << "\n";
  }

  // member: y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y: ";
    rosidl_generator_traits::value_to_yaml(msg.y, out);
    out << "\n";
  }

  // member: yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
    out << "\n";
  }

  // member: x_t
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x_t: ";
    rosidl_generator_traits::value_to_yaml(msg.x_t, out);
    out << "\n";
  }

  // member: y_t
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y_t: ";
    rosidl_generator_traits::value_to_yaml(msg.y_t, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Debug & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::Debug & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::Debug & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::Debug>()
{
  return "truck_msgs::msg::Debug";
}

template<>
inline const char * name<truck_msgs::msg::Debug>()
{
  return "truck_msgs/msg/Debug";
}

template<>
struct has_fixed_size<truck_msgs::msg::Debug>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::Debug>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::Debug>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__DEBUG__TRAITS_HPP_
