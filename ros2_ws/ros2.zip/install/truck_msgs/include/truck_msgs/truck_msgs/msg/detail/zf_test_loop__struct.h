// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfTestLoop.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ZfTestLoop in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * Encoder 12bit raw data
 */
typedef struct truck_msgs__msg__ZfTestLoop
{
  std_msgs__msg__Header header;
  /// 1=test_node (request), 2=ros_bridge (answer), 3=test_node (result)
  uint16_t sender;
  /// |  ros_node, outgoing
  uint32_t timestamp_ros_out;
  /// |  ros_bridge, outgoing
  uint32_t timestamp_bridge_out;
  /// |  master arduino, outgoing
  uint16_t timestamp_master_out;
  /// |  slave arduino
  uint16_t timestamp_slave;
  /// |  master arduino, incoming
  uint16_t timestamp_master_in;
  /// |  ros_bridge, incoming
  uint32_t timestamp_bridge_in;
  /// V  ros_node, incoming
  uint32_t timestamp_ros_in;
  /// timespan
  uint16_t master_to_master;
  /// timespan
  uint16_t bridge_to_bridge;
  /// timespan
  uint16_t ros_to_ros;
} truck_msgs__msg__ZfTestLoop;

// Struct for a sequence of truck_msgs__msg__ZfTestLoop.
typedef struct truck_msgs__msg__ZfTestLoop__Sequence
{
  truck_msgs__msg__ZfTestLoop * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfTestLoop__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__STRUCT_H_
