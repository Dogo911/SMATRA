// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfControllerParams.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ZfControllerParams in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * zf_controller_params.msg
  *
  * PID-Parameter mit 100 multipliziert, d.h. 100 entspricht 1
  *
  * Version 6.0
 */
typedef struct truck_msgs__msg__ZfControllerParams
{
  std_msgs__msg__Header header;
  /// Lenkwinkel-Regler, P-Anteil
  int16_t steer_p;
  /// Lenkwinkel-Regler, I-Anteil
  int16_t steer_i;
  /// Lenkwinkel-Regler, D-Anteil
  int16_t steer_d;
  /// Geschwindigkeits-Regler, P-Anteil
  int16_t speed_p;
  /// Geschwindigkeits-Regler, I-Anteil
  int16_t speed_i;
  /// Geschwindigkeits-Regler, D-Anteil
  int16_t speed_d;
  /// Lenkwinkel-Regler, freier Parameter A
  int16_t steer_a;
  /// Lenkwinkel-Regler, freier Parameter B
  int16_t steer_b;
  /// Lenkwinkel-Regler, freier Parameter C
  int16_t steer_c;
  /// Geschwindigkeits-Regler, freier Parameter A
  int16_t speed_a;
  /// Geschwindigkeits-Regler, freier Parameter B
  int16_t speed_b;
  /// Geschwindigkeits-Regler, freier Parameter C
  int16_t speed_c;
} truck_msgs__msg__ZfControllerParams;

// Struct for a sequence of truck_msgs__msg__ZfControllerParams.
typedef struct truck_msgs__msg__ZfControllerParams__Sequence
{
  truck_msgs__msg__ZfControllerParams * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfControllerParams__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__STRUCT_H_
