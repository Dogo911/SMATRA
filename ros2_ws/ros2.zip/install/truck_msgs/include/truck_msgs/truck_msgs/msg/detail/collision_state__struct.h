﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/CollisionState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'p1'
// Member 'p2'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in msg/CollisionState in the package truck_msgs.
/**
  * ZF InnoLab ROS message definition
 */
typedef struct truck_msgs__msg__CollisionState
{
  std_msgs__msg__Header header;
  /// Stop-Funktion:
  int16_t stop_active;
  int16_t stop_distance;
  /// Steuergrössen:
  int16_t sensor_active;
  int16_t control_active;
  int16_t target_distance;
  int16_t max_distance;
  /// Ausgangswerte der Erkennung:
  /// Eckpunkte der erkannten Linie
  geometry_msgs__msg__Point p1;
  geometry_msgs__msg__Point p2;
  /// Breite des Vorderfahrzeugs
  int16_t width;
  /// Abstand zum Vorderfahrzeug, in x-Richtung
  int16_t dist_x;
  /// seitlicher Offset des Vorderfahrzeugs, in y-Richtung
  int16_t offset;
  /// kartesischer Abstand zum Vorderfahrzeug
  int16_t dist;
  /// Winkel zur Mitte des Vorderfahrzeugs (offset=0 => alpha=0)
  int16_t alpha;
  /// relativer Gierwinkel des Vorderfahrzeugs
  int16_t beta;
  /// Regler-Sollgroessen:
  /// Soll-Lenkwinkel
  int16_t delta_target;
  /// Soll-Geschwindigkeit
  int16_t v_target;
  /// Status:
  /// Breite im Suchfenster ?
  int16_t width_status;
  /// Abstand im Suchfenster ?
  int16_t dist_status;
  /// Gesamt-Status der Erkennung
  int16_t status;
} truck_msgs__msg__CollisionState;

// Struct for a sequence of truck_msgs__msg__CollisionState.
typedef struct truck_msgs__msg__CollisionState__Sequence
{
  truck_msgs__msg__CollisionState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__CollisionState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__STRUCT_H_
