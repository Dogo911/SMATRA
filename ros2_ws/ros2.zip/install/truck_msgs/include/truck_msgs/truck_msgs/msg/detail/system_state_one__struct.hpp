// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/SystemStateOne.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE_ONE__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE_ONE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__SystemStateOne __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__SystemStateOne __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SystemStateOne_
{
  using Type = SystemStateOne_<ContainerAllocator>;

  explicit SystemStateOne_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->millis = 0ll;
      this->cycle = 0ll;
      this->freq = 0l;
      this->status = 0l;
      this->timestamp = 0l;
    }
  }

  explicit SystemStateOne_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->millis = 0ll;
      this->cycle = 0ll;
      this->freq = 0l;
      this->status = 0l;
      this->timestamp = 0l;
    }
  }

  // field types and members
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _millis_type =
    int64_t;
  _millis_type millis;
  using _cycle_type =
    int64_t;
  _cycle_type cycle;
  using _freq_type =
    int32_t;
  _freq_type freq;
  using _status_type =
    int32_t;
  _status_type status;
  using _timestamp_type =
    int32_t;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__millis(
    const int64_t & _arg)
  {
    this->millis = _arg;
    return *this;
  }
  Type & set__cycle(
    const int64_t & _arg)
  {
    this->cycle = _arg;
    return *this;
  }
  Type & set__freq(
    const int32_t & _arg)
  {
    this->freq = _arg;
    return *this;
  }
  Type & set__status(
    const int32_t & _arg)
  {
    this->status = _arg;
    return *this;
  }
  Type & set__timestamp(
    const int32_t & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::SystemStateOne_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::SystemStateOne_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::SystemStateOne_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::SystemStateOne_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::SystemStateOne_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::SystemStateOne_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::SystemStateOne_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::SystemStateOne_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::SystemStateOne_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::SystemStateOne_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__SystemStateOne
    std::shared_ptr<truck_msgs::msg::SystemStateOne_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__SystemStateOne
    std::shared_ptr<truck_msgs::msg::SystemStateOne_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SystemStateOne_ & other) const
  {
    if (this->name != other.name) {
      return false;
    }
    if (this->millis != other.millis) {
      return false;
    }
    if (this->cycle != other.cycle) {
      return false;
    }
    if (this->freq != other.freq) {
      return false;
    }
    if (this->status != other.status) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const SystemStateOne_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SystemStateOne_

// alias to use template instance with default allocator
using SystemStateOne =
  truck_msgs::msg::SystemStateOne_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE_ONE__STRUCT_HPP_
