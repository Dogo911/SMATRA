// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfSensorConfigOne.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/ZfSensorConfigOne in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * zf_sensor_config_one.msg
  *
  * Version 5.7
 */
typedef struct truck_msgs__msg__ZfSensorConfigOne
{
  /// sensor id
  int16_t id;
  /// sensor data receiving
  int16_t sensor_active;
  /// sensor used for low-level emergency stop
  int16_t stop_active;
  /// emergency stop distance
  int16_t stop_dist;
} truck_msgs__msg__ZfSensorConfigOne;

// Struct for a sequence of truck_msgs__msg__ZfSensorConfigOne.
typedef struct truck_msgs__msg__ZfSensorConfigOne__Sequence
{
  truck_msgs__msg__ZfSensorConfigOne * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfSensorConfigOne__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__STRUCT_H_
