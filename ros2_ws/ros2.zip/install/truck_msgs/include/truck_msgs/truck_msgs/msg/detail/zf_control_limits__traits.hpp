// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfControlLimits.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_LIMITS__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_LIMITS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_control_limits__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfControlLimits & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: steering_min
  {
    out << "steering_min: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_min, out);
    out << ", ";
  }

  // member: steering_max
  {
    out << "steering_max: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_max, out);
    out << ", ";
  }

  // member: speed_min
  {
    out << "speed_min: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_min, out);
    out << ", ";
  }

  // member: speed_max
  {
    out << "speed_max: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_max, out);
    out << ", ";
  }

  // member: accel_min
  {
    out << "accel_min: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_min, out);
    out << ", ";
  }

  // member: accel_max
  {
    out << "accel_max: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_max, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfControlLimits & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: steering_min
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_min: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_min, out);
    out << "\n";
  }

  // member: steering_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_max: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_max, out);
    out << "\n";
  }

  // member: speed_min
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_min: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_min, out);
    out << "\n";
  }

  // member: speed_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_max: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_max, out);
    out << "\n";
  }

  // member: accel_min
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accel_min: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_min, out);
    out << "\n";
  }

  // member: accel_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accel_max: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_max, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfControlLimits & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfControlLimits & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfControlLimits & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfControlLimits>()
{
  return "truck_msgs::msg::ZfControlLimits";
}

template<>
inline const char * name<truck_msgs::msg::ZfControlLimits>()
{
  return "truck_msgs/msg/ZfControlLimits";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfControlLimits>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfControlLimits>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfControlLimits>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_LIMITS__TRAITS_HPP_
