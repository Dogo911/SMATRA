﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/LaserStopState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'tp'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in msg/LaserStopState in the package truck_msgs.
/**
  * ZF InnoLab ROS message definition
  * laser_stop_state.msg
  *
  * Version 6.0
 */
typedef struct truck_msgs__msg__LaserStopState
{
  std_msgs__msg__Header header;
  /// Steuergrössen:
  /// 1=ja 0=nein
  int16_t sensor_active;
  /// 1=ja 0=nein
  int16_t control_active;
  /// 1=ja 0=nein
  int16_t rviz_marker;
  /// für System-Monitor:
  int64_t cycle;
  /// Ausgangswerte der Erkennung:
  /// Trigger Punkt
  geometry_msgs__msg__Point tp;
  float min_dist;
  /// time to collision
  float ttc;
  /// Regler-Sollgroessen:
  /// Soll-Geschwindigkeit
  float v_target;
  /// kleinster erlaubter Lenkwinkel, minimal -50
  float steering_min;
  /// grösster erlaubter Lenkwinkel, maximal 50
  float steering_max;
  /// kleinste erlaubte Geschwindigkeit, minimal 0
  float speed_min;
  /// grösste erlaubte Geschwindigkeit, maximal 1.000
  float speed_max;
  /// kleinste erlaubte Beschleunigung, minimal 50 (?)
  float accel_min;
  /// grösste erlaubte Beschleunigung, maximal 500 (?)
  float accel_max;
} truck_msgs__msg__LaserStopState;

// Struct for a sequence of truck_msgs__msg__LaserStopState.
typedef struct truck_msgs__msg__LaserStopState__Sequence
{
  truck_msgs__msg__LaserStopState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__LaserStopState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__STRUCT_H_
