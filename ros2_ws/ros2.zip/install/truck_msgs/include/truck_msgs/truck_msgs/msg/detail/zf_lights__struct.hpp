// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/ZfLights.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__ZfLights __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__ZfLights __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ZfLights_
{
  using Type = ZfLights_<ContainerAllocator>;

  explicit ZfLights_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->driving = 0;
      this->braking = 0;
      this->indicator_left = 0;
      this->indicator_right = 0;
      this->high_beam = 0;
      this->reversing = 0;
      this->cornering_left = 0;
      this->cornering_right = 0;
    }
  }

  explicit ZfLights_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->driving = 0;
      this->braking = 0;
      this->indicator_left = 0;
      this->indicator_right = 0;
      this->high_beam = 0;
      this->reversing = 0;
      this->cornering_left = 0;
      this->cornering_right = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _driving_type =
    int8_t;
  _driving_type driving;
  using _braking_type =
    int8_t;
  _braking_type braking;
  using _indicator_left_type =
    int8_t;
  _indicator_left_type indicator_left;
  using _indicator_right_type =
    int8_t;
  _indicator_right_type indicator_right;
  using _high_beam_type =
    int8_t;
  _high_beam_type high_beam;
  using _reversing_type =
    int8_t;
  _reversing_type reversing;
  using _cornering_left_type =
    int8_t;
  _cornering_left_type cornering_left;
  using _cornering_right_type =
    int8_t;
  _cornering_right_type cornering_right;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__driving(
    const int8_t & _arg)
  {
    this->driving = _arg;
    return *this;
  }
  Type & set__braking(
    const int8_t & _arg)
  {
    this->braking = _arg;
    return *this;
  }
  Type & set__indicator_left(
    const int8_t & _arg)
  {
    this->indicator_left = _arg;
    return *this;
  }
  Type & set__indicator_right(
    const int8_t & _arg)
  {
    this->indicator_right = _arg;
    return *this;
  }
  Type & set__high_beam(
    const int8_t & _arg)
  {
    this->high_beam = _arg;
    return *this;
  }
  Type & set__reversing(
    const int8_t & _arg)
  {
    this->reversing = _arg;
    return *this;
  }
  Type & set__cornering_left(
    const int8_t & _arg)
  {
    this->cornering_left = _arg;
    return *this;
  }
  Type & set__cornering_right(
    const int8_t & _arg)
  {
    this->cornering_right = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::ZfLights_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::ZfLights_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfLights_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfLights_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfLights_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfLights_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfLights_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfLights_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfLights_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfLights_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__ZfLights
    std::shared_ptr<truck_msgs::msg::ZfLights_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__ZfLights
    std::shared_ptr<truck_msgs::msg::ZfLights_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ZfLights_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->driving != other.driving) {
      return false;
    }
    if (this->braking != other.braking) {
      return false;
    }
    if (this->indicator_left != other.indicator_left) {
      return false;
    }
    if (this->indicator_right != other.indicator_right) {
      return false;
    }
    if (this->high_beam != other.high_beam) {
      return false;
    }
    if (this->reversing != other.reversing) {
      return false;
    }
    if (this->cornering_left != other.cornering_left) {
      return false;
    }
    if (this->cornering_right != other.cornering_right) {
      return false;
    }
    return true;
  }
  bool operator!=(const ZfLights_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ZfLights_

// alias to use template instance with default allocator
using ZfLights =
  truck_msgs::msg::ZfLights_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__STRUCT_HPP_
