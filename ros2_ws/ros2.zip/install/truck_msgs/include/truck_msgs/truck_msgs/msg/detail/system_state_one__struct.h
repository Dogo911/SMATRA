// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/SystemStateOne.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE_ONE__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE_ONE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/SystemStateOne in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * system_state_one.msg
  *
  * Version 6.0
 */
typedef struct truck_msgs__msg__SystemStateOne
{
  rosidl_runtime_c__String name;
  int64_t millis;
  int64_t cycle;
  int32_t freq;
  int32_t status;
  int32_t timestamp;
} truck_msgs__msg__SystemStateOne;

// Struct for a sequence of truck_msgs__msg__SystemStateOne.
typedef struct truck_msgs__msg__SystemStateOne__Sequence
{
  truck_msgs__msg__SystemStateOne * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__SystemStateOne__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE_ONE__STRUCT_H_
