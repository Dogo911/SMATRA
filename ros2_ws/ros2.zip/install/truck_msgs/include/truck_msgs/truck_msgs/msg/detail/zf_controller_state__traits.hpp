// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfControllerState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_STATE__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_controller_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfControllerState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: speed_forward
  {
    out << "speed_forward: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_forward, out);
    out << ", ";
  }

  // member: speed_p
  {
    out << "speed_p: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_p, out);
    out << ", ";
  }

  // member: speed_steering
  {
    out << "speed_steering: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_steering, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfControllerState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: speed_forward
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_forward: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_forward, out);
    out << "\n";
  }

  // member: speed_p
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_p: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_p, out);
    out << "\n";
  }

  // member: speed_steering
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_steering: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_steering, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfControllerState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfControllerState & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfControllerState & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfControllerState>()
{
  return "truck_msgs::msg::ZfControllerState";
}

template<>
inline const char * name<truck_msgs::msg::ZfControllerState>()
{
  return "truck_msgs/msg/ZfControllerState";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfControllerState>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfControllerState>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfControllerState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_STATE__TRAITS_HPP_
