﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfLights.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ZfLights in the package truck_msgs.
/**
  *  ZF DHBW InnoLab ROS message definition
  *  Truck Lights
  *
  *  Version 5.7
  *
  *  Protokoll aus Truck_Interface.h:
  *
  * define LIGHT_CMD_DRIVING     1
  * define LIGHT_CMD_HIGHBEAM    2
  * define LIGHT_CMD_CORNERING   3
  * define LIGHT_CMD_BRAKING     4
  * define LIGHT_CMD_INDICATOR   5
  * define LIGHT_CMD_REVERSING   6
 */
typedef struct truck_msgs__msg__ZfLights
{
  /// define LIGHT_LEFT    1
  /// define LIGHT_RIGHT   2
  /// define LIGHTS_CMD_OFF        0
  /// define LIGHTS_CMD_ON         1
  /// define LIGHTS_CMD_FLASHING   2
  /// define LIGHTS_STATE_OFF            0
  /// define LIGHTS_STATE_ON             BIT3
  /// define LIGHTS_STATE_FRONT_LEFT_ON  BIT4
  /// define LIGHTS_STATE_FRONT_RIGHT_ON BIT5
  /// define LIGHTS_STATE_REAR_LEFT_ON   BIT6
  /// define LIGHTS_STATE_REAR_RIGHT_ON  BIT7
  std_msgs__msg__Header header;
  /// normale Beleuchtung vorne+hinten
  int8_t driving;
  /// Bremslicht hinten, 0=aus, 1=an, andere Zahl x = Flackern mit x ms An- und Auszeit
  int8_t braking;
  /// Blinker links, 0=aus, 1=an, 2=blinken
  int8_t indicator_left;
  /// Blinker rechts, 0=aus, 1=an, 2=blinken
  int8_t indicator_right;
  /// Fernlicht
  int8_t high_beam;
  /// Rückfahrlicht
  int8_t reversing;
  /// Kurvenlicht links
  int8_t cornering_left;
  /// Kurvenlicht rechts
  int8_t cornering_right;
} truck_msgs__msg__ZfLights;

// Struct for a sequence of truck_msgs__msg__ZfLights.
typedef struct truck_msgs__msg__ZfLights__Sequence
{
  truck_msgs__msg__ZfLights * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfLights__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__STRUCT_H_
