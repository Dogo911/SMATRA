// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/SafeRcState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/safe_rc_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SafeRcState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: sensor_active
  {
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << ", ";
  }

  // member: control_active
  {
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << ", ";
  }

  // member: rviz_lines
  {
    out << "rviz_lines: ";
    rosidl_generator_traits::value_to_yaml(msg.rviz_lines, out);
    out << ", ";
  }

  // member: cycle
  {
    out << "cycle: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle, out);
    out << ", ";
  }

  // member: scenario
  {
    out << "scenario: ";
    rosidl_generator_traits::value_to_yaml(msg.scenario, out);
    out << ", ";
  }

  // member: scenario_lower
  {
    out << "scenario_lower: ";
    rosidl_generator_traits::value_to_yaml(msg.scenario_lower, out);
    out << ", ";
  }

  // member: scenario_upper
  {
    out << "scenario_upper: ";
    rosidl_generator_traits::value_to_yaml(msg.scenario_upper, out);
    out << ", ";
  }

  // member: left_wall
  {
    out << "left_wall: ";
    rosidl_generator_traits::value_to_yaml(msg.left_wall, out);
    out << ", ";
  }

  // member: middle_wall
  {
    out << "middle_wall: ";
    rosidl_generator_traits::value_to_yaml(msg.middle_wall, out);
    out << ", ";
  }

  // member: right_wall
  {
    out << "right_wall: ";
    rosidl_generator_traits::value_to_yaml(msg.right_wall, out);
    out << ", ";
  }

  // member: lower_corner
  {
    out << "lower_corner: ";
    rosidl_generator_traits::value_to_yaml(msg.lower_corner, out);
    out << ", ";
  }

  // member: upper_corner
  {
    out << "upper_corner: ";
    rosidl_generator_traits::value_to_yaml(msg.upper_corner, out);
    out << ", ";
  }

  // member: steering_min
  {
    out << "steering_min: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_min, out);
    out << ", ";
  }

  // member: steering_max
  {
    out << "steering_max: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_max, out);
    out << ", ";
  }

  // member: speed_min
  {
    out << "speed_min: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_min, out);
    out << ", ";
  }

  // member: speed_max
  {
    out << "speed_max: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_max, out);
    out << ", ";
  }

  // member: accel_min
  {
    out << "accel_min: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_min, out);
    out << ", ";
  }

  // member: accel_max
  {
    out << "accel_max: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_max, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SafeRcState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: sensor_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << "\n";
  }

  // member: control_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << "\n";
  }

  // member: rviz_lines
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rviz_lines: ";
    rosidl_generator_traits::value_to_yaml(msg.rviz_lines, out);
    out << "\n";
  }

  // member: cycle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cycle: ";
    rosidl_generator_traits::value_to_yaml(msg.cycle, out);
    out << "\n";
  }

  // member: scenario
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "scenario: ";
    rosidl_generator_traits::value_to_yaml(msg.scenario, out);
    out << "\n";
  }

  // member: scenario_lower
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "scenario_lower: ";
    rosidl_generator_traits::value_to_yaml(msg.scenario_lower, out);
    out << "\n";
  }

  // member: scenario_upper
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "scenario_upper: ";
    rosidl_generator_traits::value_to_yaml(msg.scenario_upper, out);
    out << "\n";
  }

  // member: left_wall
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_wall: ";
    rosidl_generator_traits::value_to_yaml(msg.left_wall, out);
    out << "\n";
  }

  // member: middle_wall
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "middle_wall: ";
    rosidl_generator_traits::value_to_yaml(msg.middle_wall, out);
    out << "\n";
  }

  // member: right_wall
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_wall: ";
    rosidl_generator_traits::value_to_yaml(msg.right_wall, out);
    out << "\n";
  }

  // member: lower_corner
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lower_corner: ";
    rosidl_generator_traits::value_to_yaml(msg.lower_corner, out);
    out << "\n";
  }

  // member: upper_corner
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "upper_corner: ";
    rosidl_generator_traits::value_to_yaml(msg.upper_corner, out);
    out << "\n";
  }

  // member: steering_min
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_min: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_min, out);
    out << "\n";
  }

  // member: steering_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_max: ";
    rosidl_generator_traits::value_to_yaml(msg.steering_max, out);
    out << "\n";
  }

  // member: speed_min
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_min: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_min, out);
    out << "\n";
  }

  // member: speed_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_max: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_max, out);
    out << "\n";
  }

  // member: accel_min
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accel_min: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_min, out);
    out << "\n";
  }

  // member: accel_max
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accel_max: ";
    rosidl_generator_traits::value_to_yaml(msg.accel_max, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SafeRcState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::SafeRcState & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::SafeRcState & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::SafeRcState>()
{
  return "truck_msgs::msg::SafeRcState";
}

template<>
inline const char * name<truck_msgs::msg::SafeRcState>()
{
  return "truck_msgs/msg/SafeRcState";
}

template<>
struct has_fixed_size<truck_msgs::msg::SafeRcState>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::SafeRcState>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::SafeRcState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__TRAITS_HPP_
