// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfControllerParams.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_controller_params__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfControllerParams & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: steer_p
  {
    out << "steer_p: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_p, out);
    out << ", ";
  }

  // member: steer_i
  {
    out << "steer_i: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_i, out);
    out << ", ";
  }

  // member: steer_d
  {
    out << "steer_d: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_d, out);
    out << ", ";
  }

  // member: speed_p
  {
    out << "speed_p: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_p, out);
    out << ", ";
  }

  // member: speed_i
  {
    out << "speed_i: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_i, out);
    out << ", ";
  }

  // member: speed_d
  {
    out << "speed_d: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_d, out);
    out << ", ";
  }

  // member: steer_a
  {
    out << "steer_a: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_a, out);
    out << ", ";
  }

  // member: steer_b
  {
    out << "steer_b: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_b, out);
    out << ", ";
  }

  // member: steer_c
  {
    out << "steer_c: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_c, out);
    out << ", ";
  }

  // member: speed_a
  {
    out << "speed_a: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_a, out);
    out << ", ";
  }

  // member: speed_b
  {
    out << "speed_b: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_b, out);
    out << ", ";
  }

  // member: speed_c
  {
    out << "speed_c: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_c, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfControllerParams & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: steer_p
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steer_p: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_p, out);
    out << "\n";
  }

  // member: steer_i
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steer_i: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_i, out);
    out << "\n";
  }

  // member: steer_d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steer_d: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_d, out);
    out << "\n";
  }

  // member: speed_p
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_p: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_p, out);
    out << "\n";
  }

  // member: speed_i
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_i: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_i, out);
    out << "\n";
  }

  // member: speed_d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_d: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_d, out);
    out << "\n";
  }

  // member: steer_a
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steer_a: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_a, out);
    out << "\n";
  }

  // member: steer_b
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steer_b: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_b, out);
    out << "\n";
  }

  // member: steer_c
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steer_c: ";
    rosidl_generator_traits::value_to_yaml(msg.steer_c, out);
    out << "\n";
  }

  // member: speed_a
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_a: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_a, out);
    out << "\n";
  }

  // member: speed_b
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_b: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_b, out);
    out << "\n";
  }

  // member: speed_c
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_c: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_c, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfControllerParams & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfControllerParams & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfControllerParams & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfControllerParams>()
{
  return "truck_msgs::msg::ZfControllerParams";
}

template<>
inline const char * name<truck_msgs::msg::ZfControllerParams>()
{
  return "truck_msgs/msg/ZfControllerParams";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfControllerParams>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfControllerParams>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfControllerParams>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__TRAITS_HPP_
