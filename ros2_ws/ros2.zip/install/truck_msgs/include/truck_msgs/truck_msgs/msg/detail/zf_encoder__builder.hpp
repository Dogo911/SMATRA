// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfEncoder.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_encoder__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfEncoder_timestamp_bridge
{
public:
  explicit Init_ZfEncoder_timestamp_bridge(::truck_msgs::msg::ZfEncoder & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfEncoder timestamp_bridge(::truck_msgs::msg::ZfEncoder::_timestamp_bridge_type arg)
  {
    msg_.timestamp_bridge = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfEncoder msg_;
};

class Init_ZfEncoder_timestamp_master
{
public:
  explicit Init_ZfEncoder_timestamp_master(::truck_msgs::msg::ZfEncoder & msg)
  : msg_(msg)
  {}
  Init_ZfEncoder_timestamp_bridge timestamp_master(::truck_msgs::msg::ZfEncoder::_timestamp_master_type arg)
  {
    msg_.timestamp_master = std::move(arg);
    return Init_ZfEncoder_timestamp_bridge(msg_);
  }

private:
  ::truck_msgs::msg::ZfEncoder msg_;
};

class Init_ZfEncoder_timestamp_slave
{
public:
  explicit Init_ZfEncoder_timestamp_slave(::truck_msgs::msg::ZfEncoder & msg)
  : msg_(msg)
  {}
  Init_ZfEncoder_timestamp_master timestamp_slave(::truck_msgs::msg::ZfEncoder::_timestamp_slave_type arg)
  {
    msg_.timestamp_slave = std::move(arg);
    return Init_ZfEncoder_timestamp_master(msg_);
  }

private:
  ::truck_msgs::msg::ZfEncoder msg_;
};

class Init_ZfEncoder_trailer
{
public:
  explicit Init_ZfEncoder_trailer(::truck_msgs::msg::ZfEncoder & msg)
  : msg_(msg)
  {}
  Init_ZfEncoder_timestamp_slave trailer(::truck_msgs::msg::ZfEncoder::_trailer_type arg)
  {
    msg_.trailer = std::move(arg);
    return Init_ZfEncoder_timestamp_slave(msg_);
  }

private:
  ::truck_msgs::msg::ZfEncoder msg_;
};

class Init_ZfEncoder_steering
{
public:
  explicit Init_ZfEncoder_steering(::truck_msgs::msg::ZfEncoder & msg)
  : msg_(msg)
  {}
  Init_ZfEncoder_trailer steering(::truck_msgs::msg::ZfEncoder::_steering_type arg)
  {
    msg_.steering = std::move(arg);
    return Init_ZfEncoder_trailer(msg_);
  }

private:
  ::truck_msgs::msg::ZfEncoder msg_;
};

class Init_ZfEncoder_back
{
public:
  explicit Init_ZfEncoder_back(::truck_msgs::msg::ZfEncoder & msg)
  : msg_(msg)
  {}
  Init_ZfEncoder_steering back(::truck_msgs::msg::ZfEncoder::_back_type arg)
  {
    msg_.back = std::move(arg);
    return Init_ZfEncoder_steering(msg_);
  }

private:
  ::truck_msgs::msg::ZfEncoder msg_;
};

class Init_ZfEncoder_right
{
public:
  explicit Init_ZfEncoder_right(::truck_msgs::msg::ZfEncoder & msg)
  : msg_(msg)
  {}
  Init_ZfEncoder_back right(::truck_msgs::msg::ZfEncoder::_right_type arg)
  {
    msg_.right = std::move(arg);
    return Init_ZfEncoder_back(msg_);
  }

private:
  ::truck_msgs::msg::ZfEncoder msg_;
};

class Init_ZfEncoder_left
{
public:
  explicit Init_ZfEncoder_left(::truck_msgs::msg::ZfEncoder & msg)
  : msg_(msg)
  {}
  Init_ZfEncoder_right left(::truck_msgs::msg::ZfEncoder::_left_type arg)
  {
    msg_.left = std::move(arg);
    return Init_ZfEncoder_right(msg_);
  }

private:
  ::truck_msgs::msg::ZfEncoder msg_;
};

class Init_ZfEncoder_header
{
public:
  Init_ZfEncoder_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfEncoder_left header(::truck_msgs::msg::ZfEncoder::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfEncoder_left(msg_);
  }

private:
  ::truck_msgs::msg::ZfEncoder msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfEncoder>()
{
  return truck_msgs::msg::builder::Init_ZfEncoder_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__BUILDER_HPP_
