// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:msg/CollisionControl.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__COLLISION_CONTROL_H_
#define TRUCK_MSGS__MSG__COLLISION_CONTROL_H_

#include "truck_msgs/msg/detail/collision_control__struct.h"
#include "truck_msgs/msg/detail/collision_control__functions.h"
#include "truck_msgs/msg/detail/collision_control__type_support.h"

#endif  // TRUCK_MSGS__MSG__COLLISION_CONTROL_H_
