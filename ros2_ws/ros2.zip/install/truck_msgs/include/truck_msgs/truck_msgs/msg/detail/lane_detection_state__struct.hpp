// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/LaneDetectionState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__LANE_DETECTION_STATE__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__LANE_DETECTION_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__LaneDetectionState __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__LaneDetectionState __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LaneDetectionState_
{
  using Type = LaneDetectionState_<ContainerAllocator>;

  explicit LaneDetectionState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->left_fit = 0.0f;
      this->right_fit = 0.0f;
      this->left_curvature = 0.0f;
      this->right_curvature = 0.0f;
      this->offset = 0.0f;
      this->non_zero_x = 0.0f;
      this->non_zero_y = 0.0f;
    }
  }

  explicit LaneDetectionState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->left_fit = 0.0f;
      this->right_fit = 0.0f;
      this->left_curvature = 0.0f;
      this->right_curvature = 0.0f;
      this->offset = 0.0f;
      this->non_zero_x = 0.0f;
      this->non_zero_y = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _left_fit_type =
    float;
  _left_fit_type left_fit;
  using _right_fit_type =
    float;
  _right_fit_type right_fit;
  using _left_curvature_type =
    float;
  _left_curvature_type left_curvature;
  using _right_curvature_type =
    float;
  _right_curvature_type right_curvature;
  using _offset_type =
    float;
  _offset_type offset;
  using _non_zero_x_type =
    float;
  _non_zero_x_type non_zero_x;
  using _non_zero_y_type =
    float;
  _non_zero_y_type non_zero_y;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__left_fit(
    const float & _arg)
  {
    this->left_fit = _arg;
    return *this;
  }
  Type & set__right_fit(
    const float & _arg)
  {
    this->right_fit = _arg;
    return *this;
  }
  Type & set__left_curvature(
    const float & _arg)
  {
    this->left_curvature = _arg;
    return *this;
  }
  Type & set__right_curvature(
    const float & _arg)
  {
    this->right_curvature = _arg;
    return *this;
  }
  Type & set__offset(
    const float & _arg)
  {
    this->offset = _arg;
    return *this;
  }
  Type & set__non_zero_x(
    const float & _arg)
  {
    this->non_zero_x = _arg;
    return *this;
  }
  Type & set__non_zero_y(
    const float & _arg)
  {
    this->non_zero_y = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::LaneDetectionState_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::LaneDetectionState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::LaneDetectionState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::LaneDetectionState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::LaneDetectionState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::LaneDetectionState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::LaneDetectionState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::LaneDetectionState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::LaneDetectionState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::LaneDetectionState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__LaneDetectionState
    std::shared_ptr<truck_msgs::msg::LaneDetectionState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__LaneDetectionState
    std::shared_ptr<truck_msgs::msg::LaneDetectionState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LaneDetectionState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->left_fit != other.left_fit) {
      return false;
    }
    if (this->right_fit != other.right_fit) {
      return false;
    }
    if (this->left_curvature != other.left_curvature) {
      return false;
    }
    if (this->right_curvature != other.right_curvature) {
      return false;
    }
    if (this->offset != other.offset) {
      return false;
    }
    if (this->non_zero_x != other.non_zero_x) {
      return false;
    }
    if (this->non_zero_y != other.non_zero_y) {
      return false;
    }
    return true;
  }
  bool operator!=(const LaneDetectionState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LaneDetectionState_

// alias to use template instance with default allocator
using LaneDetectionState =
  truck_msgs::msg::LaneDetectionState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__LANE_DETECTION_STATE__STRUCT_HPP_
