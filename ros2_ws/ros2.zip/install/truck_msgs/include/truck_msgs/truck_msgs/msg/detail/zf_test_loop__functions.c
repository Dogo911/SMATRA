// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/ZfTestLoop.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/zf_test_loop__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
truck_msgs__msg__ZfTestLoop__init(truck_msgs__msg__ZfTestLoop * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    truck_msgs__msg__ZfTestLoop__fini(msg);
    return false;
  }
  // sender
  // timestamp_ros_out
  // timestamp_bridge_out
  // timestamp_master_out
  // timestamp_slave
  // timestamp_master_in
  // timestamp_bridge_in
  // timestamp_ros_in
  // master_to_master
  // bridge_to_bridge
  // ros_to_ros
  return true;
}

void
truck_msgs__msg__ZfTestLoop__fini(truck_msgs__msg__ZfTestLoop * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // sender
  // timestamp_ros_out
  // timestamp_bridge_out
  // timestamp_master_out
  // timestamp_slave
  // timestamp_master_in
  // timestamp_bridge_in
  // timestamp_ros_in
  // master_to_master
  // bridge_to_bridge
  // ros_to_ros
}

bool
truck_msgs__msg__ZfTestLoop__are_equal(const truck_msgs__msg__ZfTestLoop * lhs, const truck_msgs__msg__ZfTestLoop * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // sender
  if (lhs->sender != rhs->sender) {
    return false;
  }
  // timestamp_ros_out
  if (lhs->timestamp_ros_out != rhs->timestamp_ros_out) {
    return false;
  }
  // timestamp_bridge_out
  if (lhs->timestamp_bridge_out != rhs->timestamp_bridge_out) {
    return false;
  }
  // timestamp_master_out
  if (lhs->timestamp_master_out != rhs->timestamp_master_out) {
    return false;
  }
  // timestamp_slave
  if (lhs->timestamp_slave != rhs->timestamp_slave) {
    return false;
  }
  // timestamp_master_in
  if (lhs->timestamp_master_in != rhs->timestamp_master_in) {
    return false;
  }
  // timestamp_bridge_in
  if (lhs->timestamp_bridge_in != rhs->timestamp_bridge_in) {
    return false;
  }
  // timestamp_ros_in
  if (lhs->timestamp_ros_in != rhs->timestamp_ros_in) {
    return false;
  }
  // master_to_master
  if (lhs->master_to_master != rhs->master_to_master) {
    return false;
  }
  // bridge_to_bridge
  if (lhs->bridge_to_bridge != rhs->bridge_to_bridge) {
    return false;
  }
  // ros_to_ros
  if (lhs->ros_to_ros != rhs->ros_to_ros) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__ZfTestLoop__copy(
  const truck_msgs__msg__ZfTestLoop * input,
  truck_msgs__msg__ZfTestLoop * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // sender
  output->sender = input->sender;
  // timestamp_ros_out
  output->timestamp_ros_out = input->timestamp_ros_out;
  // timestamp_bridge_out
  output->timestamp_bridge_out = input->timestamp_bridge_out;
  // timestamp_master_out
  output->timestamp_master_out = input->timestamp_master_out;
  // timestamp_slave
  output->timestamp_slave = input->timestamp_slave;
  // timestamp_master_in
  output->timestamp_master_in = input->timestamp_master_in;
  // timestamp_bridge_in
  output->timestamp_bridge_in = input->timestamp_bridge_in;
  // timestamp_ros_in
  output->timestamp_ros_in = input->timestamp_ros_in;
  // master_to_master
  output->master_to_master = input->master_to_master;
  // bridge_to_bridge
  output->bridge_to_bridge = input->bridge_to_bridge;
  // ros_to_ros
  output->ros_to_ros = input->ros_to_ros;
  return true;
}

truck_msgs__msg__ZfTestLoop *
truck_msgs__msg__ZfTestLoop__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfTestLoop * msg = (truck_msgs__msg__ZfTestLoop *)allocator.allocate(sizeof(truck_msgs__msg__ZfTestLoop), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__ZfTestLoop));
  bool success = truck_msgs__msg__ZfTestLoop__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__ZfTestLoop__destroy(truck_msgs__msg__ZfTestLoop * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__ZfTestLoop__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__ZfTestLoop__Sequence__init(truck_msgs__msg__ZfTestLoop__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfTestLoop * data = NULL;

  if (size) {
    data = (truck_msgs__msg__ZfTestLoop *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__ZfTestLoop), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__ZfTestLoop__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__ZfTestLoop__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__ZfTestLoop__Sequence__fini(truck_msgs__msg__ZfTestLoop__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__ZfTestLoop__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__ZfTestLoop__Sequence *
truck_msgs__msg__ZfTestLoop__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfTestLoop__Sequence * array = (truck_msgs__msg__ZfTestLoop__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__ZfTestLoop__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__ZfTestLoop__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__ZfTestLoop__Sequence__destroy(truck_msgs__msg__ZfTestLoop__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__ZfTestLoop__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__ZfTestLoop__Sequence__are_equal(const truck_msgs__msg__ZfTestLoop__Sequence * lhs, const truck_msgs__msg__ZfTestLoop__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__ZfTestLoop__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__ZfTestLoop__Sequence__copy(
  const truck_msgs__msg__ZfTestLoop__Sequence * input,
  truck_msgs__msg__ZfTestLoop__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__ZfTestLoop);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__ZfTestLoop * data =
      (truck_msgs__msg__ZfTestLoop *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__ZfTestLoop__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__ZfTestLoop__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__ZfTestLoop__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
