// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfOdometry.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_ODOMETRY__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_ODOMETRY__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_odometry__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfOdometry & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: dist_left
  {
    out << "dist_left: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_left, out);
    out << ", ";
  }

  // member: dist_right
  {
    out << "dist_right: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_right, out);
    out << ", ";
  }

  // member: dist_back
  {
    out << "dist_back: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_back, out);
    out << ", ";
  }

  // member: delta_encoder
  {
    out << "delta_encoder: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_encoder, out);
    out << ", ";
  }

  // member: yaw
  {
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
    out << ", ";
  }

  // member: yaw_diff
  {
    out << "yaw_diff: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw_diff, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfOdometry & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: dist_left
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dist_left: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_left, out);
    out << "\n";
  }

  // member: dist_right
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dist_right: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_right, out);
    out << "\n";
  }

  // member: dist_back
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dist_back: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_back, out);
    out << "\n";
  }

  // member: delta_encoder
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "delta_encoder: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_encoder, out);
    out << "\n";
  }

  // member: yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
    out << "\n";
  }

  // member: yaw_diff
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "yaw_diff: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw_diff, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfOdometry & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfOdometry & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfOdometry & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfOdometry>()
{
  return "truck_msgs::msg::ZfOdometry";
}

template<>
inline const char * name<truck_msgs::msg::ZfOdometry>()
{
  return "truck_msgs/msg/ZfOdometry";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfOdometry>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfOdometry>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfOdometry>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_ODOMETRY__TRAITS_HPP_
