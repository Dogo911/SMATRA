// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfTruckStateSlow.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE_SLOW__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE_SLOW__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_truck_state_slow__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfTruckStateSlow_emerg_stop_auto_release
{
public:
  explicit Init_ZfTruckStateSlow_emerg_stop_auto_release(::truck_msgs::msg::ZfTruckStateSlow & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfTruckStateSlow emerg_stop_auto_release(::truck_msgs::msg::ZfTruckStateSlow::_emerg_stop_auto_release_type arg)
  {
    msg_.emerg_stop_auto_release = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckStateSlow msg_;
};

class Init_ZfTruckStateSlow_i_total
{
public:
  explicit Init_ZfTruckStateSlow_i_total(::truck_msgs::msg::ZfTruckStateSlow & msg)
  : msg_(msg)
  {}
  Init_ZfTruckStateSlow_emerg_stop_auto_release i_total(::truck_msgs::msg::ZfTruckStateSlow::_i_total_type arg)
  {
    msg_.i_total = std::move(arg);
    return Init_ZfTruckStateSlow_emerg_stop_auto_release(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckStateSlow msg_;
};

class Init_ZfTruckStateSlow_u_5
{
public:
  explicit Init_ZfTruckStateSlow_u_5(::truck_msgs::msg::ZfTruckStateSlow & msg)
  : msg_(msg)
  {}
  Init_ZfTruckStateSlow_i_total u_5(::truck_msgs::msg::ZfTruckStateSlow::_u_5_type arg)
  {
    msg_.u_5 = std::move(arg);
    return Init_ZfTruckStateSlow_i_total(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckStateSlow msg_;
};

class Init_ZfTruckStateSlow_u_12
{
public:
  explicit Init_ZfTruckStateSlow_u_12(::truck_msgs::msg::ZfTruckStateSlow & msg)
  : msg_(msg)
  {}
  Init_ZfTruckStateSlow_u_5 u_12(::truck_msgs::msg::ZfTruckStateSlow::_u_12_type arg)
  {
    msg_.u_12 = std::move(arg);
    return Init_ZfTruckStateSlow_u_5(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckStateSlow msg_;
};

class Init_ZfTruckStateSlow_header
{
public:
  Init_ZfTruckStateSlow_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfTruckStateSlow_u_12 header(::truck_msgs::msg::ZfTruckStateSlow::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfTruckStateSlow_u_12(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckStateSlow msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfTruckStateSlow>()
{
  return truck_msgs::msg::builder::Init_ZfTruckStateSlow_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE_SLOW__BUILDER_HPP_
