// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/SystemState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/system_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_SystemState_cnt
{
public:
  explicit Init_SystemState_cnt(::truck_msgs::msg::SystemState & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::SystemState cnt(::truck_msgs::msg::SystemState::_cnt_type arg)
  {
    msg_.cnt = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::SystemState msg_;
};

class Init_SystemState_state
{
public:
  explicit Init_SystemState_state(::truck_msgs::msg::SystemState & msg)
  : msg_(msg)
  {}
  Init_SystemState_cnt state(::truck_msgs::msg::SystemState::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_SystemState_cnt(msg_);
  }

private:
  ::truck_msgs::msg::SystemState msg_;
};

class Init_SystemState_header
{
public:
  Init_SystemState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SystemState_state header(::truck_msgs::msg::SystemState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SystemState_state(msg_);
  }

private:
  ::truck_msgs::msg::SystemState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::SystemState>()
{
  return truck_msgs::msg::builder::Init_SystemState_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE__BUILDER_HPP_
