// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:msg/ZfTruckInit.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__ZF_TRUCK_INIT_H_
#define TRUCK_MSGS__MSG__ZF_TRUCK_INIT_H_

#include "truck_msgs/msg/detail/zf_truck_init__struct.h"
#include "truck_msgs/msg/detail/zf_truck_init__functions.h"
#include "truck_msgs/msg/detail/zf_truck_init__type_support.h"

#endif  // TRUCK_MSGS__MSG__ZF_TRUCK_INIT_H_
