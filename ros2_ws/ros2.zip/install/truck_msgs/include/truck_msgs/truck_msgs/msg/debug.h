// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:msg/Debug.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DEBUG_H_
#define TRUCK_MSGS__MSG__DEBUG_H_

#include "truck_msgs/msg/detail/debug__struct.h"
#include "truck_msgs/msg/detail/debug__functions.h"
#include "truck_msgs/msg/detail/debug__type_support.h"

#endif  // TRUCK_MSGS__MSG__DEBUG_H_
