// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfLights.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_lights__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfLights & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: driving
  {
    out << "driving: ";
    rosidl_generator_traits::value_to_yaml(msg.driving, out);
    out << ", ";
  }

  // member: braking
  {
    out << "braking: ";
    rosidl_generator_traits::value_to_yaml(msg.braking, out);
    out << ", ";
  }

  // member: indicator_left
  {
    out << "indicator_left: ";
    rosidl_generator_traits::value_to_yaml(msg.indicator_left, out);
    out << ", ";
  }

  // member: indicator_right
  {
    out << "indicator_right: ";
    rosidl_generator_traits::value_to_yaml(msg.indicator_right, out);
    out << ", ";
  }

  // member: high_beam
  {
    out << "high_beam: ";
    rosidl_generator_traits::value_to_yaml(msg.high_beam, out);
    out << ", ";
  }

  // member: reversing
  {
    out << "reversing: ";
    rosidl_generator_traits::value_to_yaml(msg.reversing, out);
    out << ", ";
  }

  // member: cornering_left
  {
    out << "cornering_left: ";
    rosidl_generator_traits::value_to_yaml(msg.cornering_left, out);
    out << ", ";
  }

  // member: cornering_right
  {
    out << "cornering_right: ";
    rosidl_generator_traits::value_to_yaml(msg.cornering_right, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfLights & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: driving
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "driving: ";
    rosidl_generator_traits::value_to_yaml(msg.driving, out);
    out << "\n";
  }

  // member: braking
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "braking: ";
    rosidl_generator_traits::value_to_yaml(msg.braking, out);
    out << "\n";
  }

  // member: indicator_left
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "indicator_left: ";
    rosidl_generator_traits::value_to_yaml(msg.indicator_left, out);
    out << "\n";
  }

  // member: indicator_right
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "indicator_right: ";
    rosidl_generator_traits::value_to_yaml(msg.indicator_right, out);
    out << "\n";
  }

  // member: high_beam
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "high_beam: ";
    rosidl_generator_traits::value_to_yaml(msg.high_beam, out);
    out << "\n";
  }

  // member: reversing
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reversing: ";
    rosidl_generator_traits::value_to_yaml(msg.reversing, out);
    out << "\n";
  }

  // member: cornering_left
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cornering_left: ";
    rosidl_generator_traits::value_to_yaml(msg.cornering_left, out);
    out << "\n";
  }

  // member: cornering_right
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cornering_right: ";
    rosidl_generator_traits::value_to_yaml(msg.cornering_right, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfLights & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfLights & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfLights & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfLights>()
{
  return "truck_msgs::msg::ZfLights";
}

template<>
inline const char * name<truck_msgs::msg::ZfLights>()
{
  return "truck_msgs/msg/ZfLights";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfLights>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfLights>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfLights>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__TRAITS_HPP_
