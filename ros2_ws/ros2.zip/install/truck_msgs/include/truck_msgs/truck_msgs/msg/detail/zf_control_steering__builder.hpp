// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfControlSteering.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_STEERING__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_STEERING__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_control_steering__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfControlSteering_v_delta
{
public:
  explicit Init_ZfControlSteering_v_delta(::truck_msgs::msg::ZfControlSteering & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfControlSteering v_delta(::truck_msgs::msg::ZfControlSteering::_v_delta_type arg)
  {
    msg_.v_delta = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlSteering msg_;
};

class Init_ZfControlSteering_delta
{
public:
  explicit Init_ZfControlSteering_delta(::truck_msgs::msg::ZfControlSteering & msg)
  : msg_(msg)
  {}
  Init_ZfControlSteering_v_delta delta(::truck_msgs::msg::ZfControlSteering::_delta_type arg)
  {
    msg_.delta = std::move(arg);
    return Init_ZfControlSteering_v_delta(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlSteering msg_;
};

class Init_ZfControlSteering_header
{
public:
  Init_ZfControlSteering_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfControlSteering_delta header(::truck_msgs::msg::ZfControlSteering::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfControlSteering_delta(msg_);
  }

private:
  ::truck_msgs::msg::ZfControlSteering msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfControlSteering>()
{
  return truck_msgs::msg::builder::Init_ZfControlSteering_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_STEERING__BUILDER_HPP_
