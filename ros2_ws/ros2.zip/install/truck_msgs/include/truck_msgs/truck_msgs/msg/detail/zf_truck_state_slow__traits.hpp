// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfTruckStateSlow.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE_SLOW__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE_SLOW__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_truck_state_slow__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfTruckStateSlow & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: u_12
  {
    out << "u_12: ";
    rosidl_generator_traits::value_to_yaml(msg.u_12, out);
    out << ", ";
  }

  // member: u_5
  {
    out << "u_5: ";
    rosidl_generator_traits::value_to_yaml(msg.u_5, out);
    out << ", ";
  }

  // member: i_total
  {
    out << "i_total: ";
    rosidl_generator_traits::value_to_yaml(msg.i_total, out);
    out << ", ";
  }

  // member: emerg_stop_auto_release
  {
    out << "emerg_stop_auto_release: ";
    rosidl_generator_traits::value_to_yaml(msg.emerg_stop_auto_release, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfTruckStateSlow & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: u_12
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "u_12: ";
    rosidl_generator_traits::value_to_yaml(msg.u_12, out);
    out << "\n";
  }

  // member: u_5
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "u_5: ";
    rosidl_generator_traits::value_to_yaml(msg.u_5, out);
    out << "\n";
  }

  // member: i_total
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "i_total: ";
    rosidl_generator_traits::value_to_yaml(msg.i_total, out);
    out << "\n";
  }

  // member: emerg_stop_auto_release
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "emerg_stop_auto_release: ";
    rosidl_generator_traits::value_to_yaml(msg.emerg_stop_auto_release, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfTruckStateSlow & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfTruckStateSlow & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfTruckStateSlow & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfTruckStateSlow>()
{
  return "truck_msgs::msg::ZfTruckStateSlow";
}

template<>
inline const char * name<truck_msgs::msg::ZfTruckStateSlow>()
{
  return "truck_msgs/msg/ZfTruckStateSlow";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfTruckStateSlow>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfTruckStateSlow>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfTruckStateSlow>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE_SLOW__TRAITS_HPP_
