// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/Debug.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__DEBUG__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__DEBUG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/Debug in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * debug.msg
  *
  * Version 6.0.8   21.11.2023
 */
typedef struct truck_msgs__msg__Debug
{
  std_msgs__msg__Header header;
  /// Odometry
  ///  encoder difference in one cycle
  int16_t enc_diff_left;
  /// encoder difference in one cycle
  int16_t enc_diff_right;
  /// encoder difference in one cycle
  int16_t enc_diff_back;
  /// encoder difference (left - right) in one cycle
  int16_t enc_diff_lr;
  /// wheel movement in one cycle
  float wheel_diff_left;
  /// wheel movement in one cycle
  float wheel_diff_right;
  /// wheel movement in one cycle
  float wheel_diff_back;
  /// wheel movement average left+right in one cycle
  float wheel_diff_lr;
  /// change of steering angle in one cycle
  float steering_diff;
  /// wheel movement (correction) caused by change of steering angle
  float wheel_diff_steer;
  /// change of yaw in one cycle
  float dyaw;
  float steering_angle;
  float wheelbase;
  /// x movement in car coord. system
  float dx;
  /// y movement in car coord. system
  float dy;
  /// x movement in world coord. system
  float delta_x;
  /// y movement in world coord. system
  float delta_y;
  /// x position in world coord. system
  float x;
  /// y position in world coord. system
  float y;
  /// yaw angle
  float yaw;
  /// x position of ref. point in world coord. system
  float x_t;
  /// y position of ref. point in world coord. system
  float y_t;
} truck_msgs__msg__Debug;

// Struct for a sequence of truck_msgs__msg__Debug.
typedef struct truck_msgs__msg__Debug__Sequence
{
  truck_msgs__msg__Debug * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__Debug__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__DEBUG__STRUCT_H_
