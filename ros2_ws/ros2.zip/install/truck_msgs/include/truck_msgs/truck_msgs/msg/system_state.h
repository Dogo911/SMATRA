// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:msg/SystemState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__SYSTEM_STATE_H_
#define TRUCK_MSGS__MSG__SYSTEM_STATE_H_

#include "truck_msgs/msg/detail/system_state__struct.h"
#include "truck_msgs/msg/detail/system_state__functions.h"
#include "truck_msgs/msg/detail/system_state__type_support.h"

#endif  // TRUCK_MSGS__MSG__SYSTEM_STATE_H_
