// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/LaneDetectionState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__LANE_DETECTION_STATE__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__LANE_DETECTION_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/LaneDetectionState in the package truck_msgs.
/**
  * ZF InnoLab ROS message definition
 */
typedef struct truck_msgs__msg__LaneDetectionState
{
  std_msgs__msg__Header header;
  /// Ausgangswerte der Erkennung:
  float left_fit;
  float right_fit;
  float left_curvature;
  float right_curvature;
  float offset;
  float non_zero_x;
  float non_zero_y;
} truck_msgs__msg__LaneDetectionState;

// Struct for a sequence of truck_msgs__msg__LaneDetectionState.
typedef struct truck_msgs__msg__LaneDetectionState__Sequence
{
  truck_msgs__msg__LaneDetectionState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__LaneDetectionState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__LANE_DETECTION_STATE__STRUCT_H_
