// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/ZfSensorConfigOne.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__ZfSensorConfigOne __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__ZfSensorConfigOne __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ZfSensorConfigOne_
{
  using Type = ZfSensorConfigOne_<ContainerAllocator>;

  explicit ZfSensorConfigOne_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->id = 0;
      this->sensor_active = 0;
      this->stop_active = 0;
      this->stop_dist = 0;
    }
  }

  explicit ZfSensorConfigOne_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->id = 0;
      this->sensor_active = 0;
      this->stop_active = 0;
      this->stop_dist = 0;
    }
  }

  // field types and members
  using _id_type =
    int16_t;
  _id_type id;
  using _sensor_active_type =
    int16_t;
  _sensor_active_type sensor_active;
  using _stop_active_type =
    int16_t;
  _stop_active_type stop_active;
  using _stop_dist_type =
    int16_t;
  _stop_dist_type stop_dist;

  // setters for named parameter idiom
  Type & set__id(
    const int16_t & _arg)
  {
    this->id = _arg;
    return *this;
  }
  Type & set__sensor_active(
    const int16_t & _arg)
  {
    this->sensor_active = _arg;
    return *this;
  }
  Type & set__stop_active(
    const int16_t & _arg)
  {
    this->stop_active = _arg;
    return *this;
  }
  Type & set__stop_dist(
    const int16_t & _arg)
  {
    this->stop_dist = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__ZfSensorConfigOne
    std::shared_ptr<truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__ZfSensorConfigOne
    std::shared_ptr<truck_msgs::msg::ZfSensorConfigOne_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ZfSensorConfigOne_ & other) const
  {
    if (this->id != other.id) {
      return false;
    }
    if (this->sensor_active != other.sensor_active) {
      return false;
    }
    if (this->stop_active != other.stop_active) {
      return false;
    }
    if (this->stop_dist != other.stop_dist) {
      return false;
    }
    return true;
  }
  bool operator!=(const ZfSensorConfigOne_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ZfSensorConfigOne_

// alias to use template instance with default allocator
using ZfSensorConfigOne =
  truck_msgs::msg::ZfSensorConfigOne_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__STRUCT_HPP_
