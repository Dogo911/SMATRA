// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfRcState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_RC_STATE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_RC_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_rc_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfRcState_rc_3
{
public:
  explicit Init_ZfRcState_rc_3(::truck_msgs::msg::ZfRcState & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfRcState rc_3(::truck_msgs::msg::ZfRcState::_rc_3_type arg)
  {
    msg_.rc_3 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfRcState msg_;
};

class Init_ZfRcState_rc_2
{
public:
  explicit Init_ZfRcState_rc_2(::truck_msgs::msg::ZfRcState & msg)
  : msg_(msg)
  {}
  Init_ZfRcState_rc_3 rc_2(::truck_msgs::msg::ZfRcState::_rc_2_type arg)
  {
    msg_.rc_2 = std::move(arg);
    return Init_ZfRcState_rc_3(msg_);
  }

private:
  ::truck_msgs::msg::ZfRcState msg_;
};

class Init_ZfRcState_rc_1
{
public:
  explicit Init_ZfRcState_rc_1(::truck_msgs::msg::ZfRcState & msg)
  : msg_(msg)
  {}
  Init_ZfRcState_rc_2 rc_1(::truck_msgs::msg::ZfRcState::_rc_1_type arg)
  {
    msg_.rc_1 = std::move(arg);
    return Init_ZfRcState_rc_2(msg_);
  }

private:
  ::truck_msgs::msg::ZfRcState msg_;
};

class Init_ZfRcState_header
{
public:
  Init_ZfRcState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfRcState_rc_1 header(::truck_msgs::msg::ZfRcState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfRcState_rc_1(msg_);
  }

private:
  ::truck_msgs::msg::ZfRcState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfRcState>()
{
  return truck_msgs::msg::builder::Init_ZfRcState_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_RC_STATE__BUILDER_HPP_
