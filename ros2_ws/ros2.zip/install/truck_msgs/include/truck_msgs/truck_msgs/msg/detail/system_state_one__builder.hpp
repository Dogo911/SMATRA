// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/SystemStateOne.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE_ONE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE_ONE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/system_state_one__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_SystemStateOne_timestamp
{
public:
  explicit Init_SystemStateOne_timestamp(::truck_msgs::msg::SystemStateOne & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::SystemStateOne timestamp(::truck_msgs::msg::SystemStateOne::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::SystemStateOne msg_;
};

class Init_SystemStateOne_status
{
public:
  explicit Init_SystemStateOne_status(::truck_msgs::msg::SystemStateOne & msg)
  : msg_(msg)
  {}
  Init_SystemStateOne_timestamp status(::truck_msgs::msg::SystemStateOne::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_SystemStateOne_timestamp(msg_);
  }

private:
  ::truck_msgs::msg::SystemStateOne msg_;
};

class Init_SystemStateOne_freq
{
public:
  explicit Init_SystemStateOne_freq(::truck_msgs::msg::SystemStateOne & msg)
  : msg_(msg)
  {}
  Init_SystemStateOne_status freq(::truck_msgs::msg::SystemStateOne::_freq_type arg)
  {
    msg_.freq = std::move(arg);
    return Init_SystemStateOne_status(msg_);
  }

private:
  ::truck_msgs::msg::SystemStateOne msg_;
};

class Init_SystemStateOne_cycle
{
public:
  explicit Init_SystemStateOne_cycle(::truck_msgs::msg::SystemStateOne & msg)
  : msg_(msg)
  {}
  Init_SystemStateOne_freq cycle(::truck_msgs::msg::SystemStateOne::_cycle_type arg)
  {
    msg_.cycle = std::move(arg);
    return Init_SystemStateOne_freq(msg_);
  }

private:
  ::truck_msgs::msg::SystemStateOne msg_;
};

class Init_SystemStateOne_millis
{
public:
  explicit Init_SystemStateOne_millis(::truck_msgs::msg::SystemStateOne & msg)
  : msg_(msg)
  {}
  Init_SystemStateOne_cycle millis(::truck_msgs::msg::SystemStateOne::_millis_type arg)
  {
    msg_.millis = std::move(arg);
    return Init_SystemStateOne_cycle(msg_);
  }

private:
  ::truck_msgs::msg::SystemStateOne msg_;
};

class Init_SystemStateOne_name
{
public:
  Init_SystemStateOne_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SystemStateOne_millis name(::truck_msgs::msg::SystemStateOne::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_SystemStateOne_millis(msg_);
  }

private:
  ::truck_msgs::msg::SystemStateOne msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::SystemStateOne>()
{
  return truck_msgs::msg::builder::Init_SystemStateOne_name();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__SYSTEM_STATE_ONE__BUILDER_HPP_
