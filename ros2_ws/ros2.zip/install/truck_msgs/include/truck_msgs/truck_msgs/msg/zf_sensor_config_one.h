// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:msg/ZfSensorConfigOne.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__ZF_SENSOR_CONFIG_ONE_H_
#define TRUCK_MSGS__MSG__ZF_SENSOR_CONFIG_ONE_H_

#include "truck_msgs/msg/detail/zf_sensor_config_one__struct.h"
#include "truck_msgs/msg/detail/zf_sensor_config_one__functions.h"
#include "truck_msgs/msg/detail/zf_sensor_config_one__type_support.h"

#endif  // TRUCK_MSGS__MSG__ZF_SENSOR_CONFIG_ONE_H_
