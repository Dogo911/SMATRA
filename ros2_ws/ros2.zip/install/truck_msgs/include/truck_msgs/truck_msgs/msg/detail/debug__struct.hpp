// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/Debug.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__DEBUG__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__DEBUG__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__Debug __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__Debug __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Debug_
{
  using Type = Debug_<ContainerAllocator>;

  explicit Debug_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->enc_diff_left = 0;
      this->enc_diff_right = 0;
      this->enc_diff_back = 0;
      this->enc_diff_lr = 0;
      this->wheel_diff_left = 0.0f;
      this->wheel_diff_right = 0.0f;
      this->wheel_diff_back = 0.0f;
      this->wheel_diff_lr = 0.0f;
      this->steering_diff = 0.0f;
      this->wheel_diff_steer = 0.0f;
      this->dyaw = 0.0f;
      this->steering_angle = 0.0f;
      this->wheelbase = 0.0f;
      this->dx = 0.0f;
      this->dy = 0.0f;
      this->delta_x = 0.0f;
      this->delta_y = 0.0f;
      this->x = 0.0f;
      this->y = 0.0f;
      this->yaw = 0.0f;
      this->x_t = 0.0f;
      this->y_t = 0.0f;
    }
  }

  explicit Debug_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->enc_diff_left = 0;
      this->enc_diff_right = 0;
      this->enc_diff_back = 0;
      this->enc_diff_lr = 0;
      this->wheel_diff_left = 0.0f;
      this->wheel_diff_right = 0.0f;
      this->wheel_diff_back = 0.0f;
      this->wheel_diff_lr = 0.0f;
      this->steering_diff = 0.0f;
      this->wheel_diff_steer = 0.0f;
      this->dyaw = 0.0f;
      this->steering_angle = 0.0f;
      this->wheelbase = 0.0f;
      this->dx = 0.0f;
      this->dy = 0.0f;
      this->delta_x = 0.0f;
      this->delta_y = 0.0f;
      this->x = 0.0f;
      this->y = 0.0f;
      this->yaw = 0.0f;
      this->x_t = 0.0f;
      this->y_t = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _enc_diff_left_type =
    int16_t;
  _enc_diff_left_type enc_diff_left;
  using _enc_diff_right_type =
    int16_t;
  _enc_diff_right_type enc_diff_right;
  using _enc_diff_back_type =
    int16_t;
  _enc_diff_back_type enc_diff_back;
  using _enc_diff_lr_type =
    int16_t;
  _enc_diff_lr_type enc_diff_lr;
  using _wheel_diff_left_type =
    float;
  _wheel_diff_left_type wheel_diff_left;
  using _wheel_diff_right_type =
    float;
  _wheel_diff_right_type wheel_diff_right;
  using _wheel_diff_back_type =
    float;
  _wheel_diff_back_type wheel_diff_back;
  using _wheel_diff_lr_type =
    float;
  _wheel_diff_lr_type wheel_diff_lr;
  using _steering_diff_type =
    float;
  _steering_diff_type steering_diff;
  using _wheel_diff_steer_type =
    float;
  _wheel_diff_steer_type wheel_diff_steer;
  using _dyaw_type =
    float;
  _dyaw_type dyaw;
  using _steering_angle_type =
    float;
  _steering_angle_type steering_angle;
  using _wheelbase_type =
    float;
  _wheelbase_type wheelbase;
  using _dx_type =
    float;
  _dx_type dx;
  using _dy_type =
    float;
  _dy_type dy;
  using _delta_x_type =
    float;
  _delta_x_type delta_x;
  using _delta_y_type =
    float;
  _delta_y_type delta_y;
  using _x_type =
    float;
  _x_type x;
  using _y_type =
    float;
  _y_type y;
  using _yaw_type =
    float;
  _yaw_type yaw;
  using _x_t_type =
    float;
  _x_t_type x_t;
  using _y_t_type =
    float;
  _y_t_type y_t;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__enc_diff_left(
    const int16_t & _arg)
  {
    this->enc_diff_left = _arg;
    return *this;
  }
  Type & set__enc_diff_right(
    const int16_t & _arg)
  {
    this->enc_diff_right = _arg;
    return *this;
  }
  Type & set__enc_diff_back(
    const int16_t & _arg)
  {
    this->enc_diff_back = _arg;
    return *this;
  }
  Type & set__enc_diff_lr(
    const int16_t & _arg)
  {
    this->enc_diff_lr = _arg;
    return *this;
  }
  Type & set__wheel_diff_left(
    const float & _arg)
  {
    this->wheel_diff_left = _arg;
    return *this;
  }
  Type & set__wheel_diff_right(
    const float & _arg)
  {
    this->wheel_diff_right = _arg;
    return *this;
  }
  Type & set__wheel_diff_back(
    const float & _arg)
  {
    this->wheel_diff_back = _arg;
    return *this;
  }
  Type & set__wheel_diff_lr(
    const float & _arg)
  {
    this->wheel_diff_lr = _arg;
    return *this;
  }
  Type & set__steering_diff(
    const float & _arg)
  {
    this->steering_diff = _arg;
    return *this;
  }
  Type & set__wheel_diff_steer(
    const float & _arg)
  {
    this->wheel_diff_steer = _arg;
    return *this;
  }
  Type & set__dyaw(
    const float & _arg)
  {
    this->dyaw = _arg;
    return *this;
  }
  Type & set__steering_angle(
    const float & _arg)
  {
    this->steering_angle = _arg;
    return *this;
  }
  Type & set__wheelbase(
    const float & _arg)
  {
    this->wheelbase = _arg;
    return *this;
  }
  Type & set__dx(
    const float & _arg)
  {
    this->dx = _arg;
    return *this;
  }
  Type & set__dy(
    const float & _arg)
  {
    this->dy = _arg;
    return *this;
  }
  Type & set__delta_x(
    const float & _arg)
  {
    this->delta_x = _arg;
    return *this;
  }
  Type & set__delta_y(
    const float & _arg)
  {
    this->delta_y = _arg;
    return *this;
  }
  Type & set__x(
    const float & _arg)
  {
    this->x = _arg;
    return *this;
  }
  Type & set__y(
    const float & _arg)
  {
    this->y = _arg;
    return *this;
  }
  Type & set__yaw(
    const float & _arg)
  {
    this->yaw = _arg;
    return *this;
  }
  Type & set__x_t(
    const float & _arg)
  {
    this->x_t = _arg;
    return *this;
  }
  Type & set__y_t(
    const float & _arg)
  {
    this->y_t = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::Debug_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::Debug_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::Debug_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::Debug_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::Debug_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::Debug_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::Debug_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::Debug_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::Debug_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::Debug_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__Debug
    std::shared_ptr<truck_msgs::msg::Debug_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__Debug
    std::shared_ptr<truck_msgs::msg::Debug_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Debug_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->enc_diff_left != other.enc_diff_left) {
      return false;
    }
    if (this->enc_diff_right != other.enc_diff_right) {
      return false;
    }
    if (this->enc_diff_back != other.enc_diff_back) {
      return false;
    }
    if (this->enc_diff_lr != other.enc_diff_lr) {
      return false;
    }
    if (this->wheel_diff_left != other.wheel_diff_left) {
      return false;
    }
    if (this->wheel_diff_right != other.wheel_diff_right) {
      return false;
    }
    if (this->wheel_diff_back != other.wheel_diff_back) {
      return false;
    }
    if (this->wheel_diff_lr != other.wheel_diff_lr) {
      return false;
    }
    if (this->steering_diff != other.steering_diff) {
      return false;
    }
    if (this->wheel_diff_steer != other.wheel_diff_steer) {
      return false;
    }
    if (this->dyaw != other.dyaw) {
      return false;
    }
    if (this->steering_angle != other.steering_angle) {
      return false;
    }
    if (this->wheelbase != other.wheelbase) {
      return false;
    }
    if (this->dx != other.dx) {
      return false;
    }
    if (this->dy != other.dy) {
      return false;
    }
    if (this->delta_x != other.delta_x) {
      return false;
    }
    if (this->delta_y != other.delta_y) {
      return false;
    }
    if (this->x != other.x) {
      return false;
    }
    if (this->y != other.y) {
      return false;
    }
    if (this->yaw != other.yaw) {
      return false;
    }
    if (this->x_t != other.x_t) {
      return false;
    }
    if (this->y_t != other.y_t) {
      return false;
    }
    return true;
  }
  bool operator!=(const Debug_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Debug_

// alias to use template instance with default allocator
using Debug =
  truck_msgs::msg::Debug_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__DEBUG__STRUCT_HPP_
