// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfTruckConfig.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_CONFIG__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_CONFIG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_truck_config__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfTruckConfig_sensor_config
{
public:
  explicit Init_ZfTruckConfig_sensor_config(::truck_msgs::msg::ZfTruckConfig & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfTruckConfig sensor_config(::truck_msgs::msg::ZfTruckConfig::_sensor_config_type arg)
  {
    msg_.sensor_config = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckConfig msg_;
};

class Init_ZfTruckConfig_controller_params
{
public:
  explicit Init_ZfTruckConfig_controller_params(::truck_msgs::msg::ZfTruckConfig & msg)
  : msg_(msg)
  {}
  Init_ZfTruckConfig_sensor_config controller_params(::truck_msgs::msg::ZfTruckConfig::_controller_params_type arg)
  {
    msg_.controller_params = std::move(arg);
    return Init_ZfTruckConfig_sensor_config(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckConfig msg_;
};

class Init_ZfTruckConfig_header
{
public:
  Init_ZfTruckConfig_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfTruckConfig_controller_params header(::truck_msgs::msg::ZfTruckConfig::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfTruckConfig_controller_params(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckConfig msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfTruckConfig>()
{
  return truck_msgs::msg::builder::Init_ZfTruckConfig_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_CONFIG__BUILDER_HPP_
