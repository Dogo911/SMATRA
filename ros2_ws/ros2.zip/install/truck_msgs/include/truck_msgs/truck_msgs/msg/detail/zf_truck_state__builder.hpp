// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfTruckState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_truck_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfTruckState_emerg_stop_rsn
{
public:
  explicit Init_ZfTruckState_emerg_stop_rsn(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfTruckState emerg_stop_rsn(::truck_msgs::msg::ZfTruckState::_emerg_stop_rsn_type arg)
  {
    msg_.emerg_stop_rsn = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_emerg_stop
{
public:
  explicit Init_ZfTruckState_emerg_stop(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_emerg_stop_rsn emerg_stop(::truck_msgs::msg::ZfTruckState::_emerg_stop_type arg)
  {
    msg_.emerg_stop = std::move(arg);
    return Init_ZfTruckState_emerg_stop_rsn(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_btn_emerg_stop
{
public:
  explicit Init_ZfTruckState_btn_emerg_stop(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_emerg_stop btn_emerg_stop(::truck_msgs::msg::ZfTruckState::_btn_emerg_stop_type arg)
  {
    msg_.btn_emerg_stop = std::move(arg);
    return Init_ZfTruckState_emerg_stop(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_cycle_tf
{
public:
  explicit Init_ZfTruckState_cycle_tf(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_btn_emerg_stop cycle_tf(::truck_msgs::msg::ZfTruckState::_cycle_tf_type arg)
  {
    msg_.cycle_tf = std::move(arg);
    return Init_ZfTruckState_btn_emerg_stop(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_cycle_hub
{
public:
  explicit Init_ZfTruckState_cycle_hub(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_cycle_tf cycle_hub(::truck_msgs::msg::ZfTruckState::_cycle_hub_type arg)
  {
    msg_.cycle_hub = std::move(arg);
    return Init_ZfTruckState_cycle_tf(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_cycle_ard0
{
public:
  explicit Init_ZfTruckState_cycle_ard0(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_cycle_hub cycle_ard0(::truck_msgs::msg::ZfTruckState::_cycle_ard0_type arg)
  {
    msg_.cycle_ard0 = std::move(arg);
    return Init_ZfTruckState_cycle_hub(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_cmd_speed
{
public:
  explicit Init_ZfTruckState_cmd_speed(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_cycle_ard0 cmd_speed(::truck_msgs::msg::ZfTruckState::_cmd_speed_type arg)
  {
    msg_.cmd_speed = std::move(arg);
    return Init_ZfTruckState_cycle_ard0(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_cmd_steer
{
public:
  explicit Init_ZfTruckState_cmd_steer(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_cmd_speed cmd_steer(::truck_msgs::msg::ZfTruckState::_cmd_steer_type arg)
  {
    msg_.cmd_steer = std::move(arg);
    return Init_ZfTruckState_cmd_speed(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_delta
{
public:
  explicit Init_ZfTruckState_delta(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_cmd_steer delta(::truck_msgs::msg::ZfTruckState::_delta_type arg)
  {
    msg_.delta = std::move(arg);
    return Init_ZfTruckState_cmd_steer(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_v
{
public:
  explicit Init_ZfTruckState_v(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_delta v(::truck_msgs::msg::ZfTruckState::_v_type arg)
  {
    msg_.v = std::move(arg);
    return Init_ZfTruckState_delta(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_control_v_delta
{
public:
  explicit Init_ZfTruckState_control_v_delta(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_v control_v_delta(::truck_msgs::msg::ZfTruckState::_control_v_delta_type arg)
  {
    msg_.control_v_delta = std::move(arg);
    return Init_ZfTruckState_v(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_control_delta
{
public:
  explicit Init_ZfTruckState_control_delta(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_control_v_delta control_delta(::truck_msgs::msg::ZfTruckState::_control_delta_type arg)
  {
    msg_.control_delta = std::move(arg);
    return Init_ZfTruckState_control_v_delta(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_control_a
{
public:
  explicit Init_ZfTruckState_control_a(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_control_delta control_a(::truck_msgs::msg::ZfTruckState::_control_a_type arg)
  {
    msg_.control_a = std::move(arg);
    return Init_ZfTruckState_control_delta(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_control_v
{
public:
  explicit Init_ZfTruckState_control_v(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_control_a control_v(::truck_msgs::msg::ZfTruckState::_control_v_type arg)
  {
    msg_.control_v = std::move(arg);
    return Init_ZfTruckState_control_a(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_mode_long
{
public:
  explicit Init_ZfTruckState_mode_long(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_control_v mode_long(::truck_msgs::msg::ZfTruckState::_mode_long_type arg)
  {
    msg_.mode_long = std::move(arg);
    return Init_ZfTruckState_control_v(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_mode_lat
{
public:
  explicit Init_ZfTruckState_mode_lat(::truck_msgs::msg::ZfTruckState & msg)
  : msg_(msg)
  {}
  Init_ZfTruckState_mode_long mode_lat(::truck_msgs::msg::ZfTruckState::_mode_lat_type arg)
  {
    msg_.mode_lat = std::move(arg);
    return Init_ZfTruckState_mode_long(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

class Init_ZfTruckState_header
{
public:
  Init_ZfTruckState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfTruckState_mode_lat header(::truck_msgs::msg::ZfTruckState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfTruckState_mode_lat(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfTruckState>()
{
  return truck_msgs::msg::builder::Init_ZfTruckState_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__BUILDER_HPP_
