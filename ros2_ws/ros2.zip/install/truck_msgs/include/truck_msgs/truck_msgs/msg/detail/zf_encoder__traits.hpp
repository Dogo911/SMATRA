// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfEncoder.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_encoder__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfEncoder & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: left
  {
    out << "left: ";
    rosidl_generator_traits::value_to_yaml(msg.left, out);
    out << ", ";
  }

  // member: right
  {
    out << "right: ";
    rosidl_generator_traits::value_to_yaml(msg.right, out);
    out << ", ";
  }

  // member: back
  {
    out << "back: ";
    rosidl_generator_traits::value_to_yaml(msg.back, out);
    out << ", ";
  }

  // member: steering
  {
    out << "steering: ";
    rosidl_generator_traits::value_to_yaml(msg.steering, out);
    out << ", ";
  }

  // member: trailer
  {
    out << "trailer: ";
    rosidl_generator_traits::value_to_yaml(msg.trailer, out);
    out << ", ";
  }

  // member: timestamp_slave
  {
    out << "timestamp_slave: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_slave, out);
    out << ", ";
  }

  // member: timestamp_master
  {
    out << "timestamp_master: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_master, out);
    out << ", ";
  }

  // member: timestamp_bridge
  {
    out << "timestamp_bridge: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_bridge, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfEncoder & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: left
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left: ";
    rosidl_generator_traits::value_to_yaml(msg.left, out);
    out << "\n";
  }

  // member: right
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right: ";
    rosidl_generator_traits::value_to_yaml(msg.right, out);
    out << "\n";
  }

  // member: back
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "back: ";
    rosidl_generator_traits::value_to_yaml(msg.back, out);
    out << "\n";
  }

  // member: steering
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering: ";
    rosidl_generator_traits::value_to_yaml(msg.steering, out);
    out << "\n";
  }

  // member: trailer
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "trailer: ";
    rosidl_generator_traits::value_to_yaml(msg.trailer, out);
    out << "\n";
  }

  // member: timestamp_slave
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_slave: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_slave, out);
    out << "\n";
  }

  // member: timestamp_master
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_master: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_master, out);
    out << "\n";
  }

  // member: timestamp_bridge
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_bridge: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_bridge, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfEncoder & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfEncoder & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfEncoder & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfEncoder>()
{
  return "truck_msgs::msg::ZfEncoder";
}

template<>
inline const char * name<truck_msgs::msg::ZfEncoder>()
{
  return "truck_msgs/msg/ZfEncoder";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfEncoder>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfEncoder>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfEncoder>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__TRAITS_HPP_
