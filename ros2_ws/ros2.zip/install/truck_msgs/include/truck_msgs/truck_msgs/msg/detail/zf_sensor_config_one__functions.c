// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/ZfSensorConfigOne.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/zf_sensor_config_one__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
truck_msgs__msg__ZfSensorConfigOne__init(truck_msgs__msg__ZfSensorConfigOne * msg)
{
  if (!msg) {
    return false;
  }
  // id
  // sensor_active
  // stop_active
  // stop_dist
  return true;
}

void
truck_msgs__msg__ZfSensorConfigOne__fini(truck_msgs__msg__ZfSensorConfigOne * msg)
{
  if (!msg) {
    return;
  }
  // id
  // sensor_active
  // stop_active
  // stop_dist
}

bool
truck_msgs__msg__ZfSensorConfigOne__are_equal(const truck_msgs__msg__ZfSensorConfigOne * lhs, const truck_msgs__msg__ZfSensorConfigOne * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // id
  if (lhs->id != rhs->id) {
    return false;
  }
  // sensor_active
  if (lhs->sensor_active != rhs->sensor_active) {
    return false;
  }
  // stop_active
  if (lhs->stop_active != rhs->stop_active) {
    return false;
  }
  // stop_dist
  if (lhs->stop_dist != rhs->stop_dist) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__ZfSensorConfigOne__copy(
  const truck_msgs__msg__ZfSensorConfigOne * input,
  truck_msgs__msg__ZfSensorConfigOne * output)
{
  if (!input || !output) {
    return false;
  }
  // id
  output->id = input->id;
  // sensor_active
  output->sensor_active = input->sensor_active;
  // stop_active
  output->stop_active = input->stop_active;
  // stop_dist
  output->stop_dist = input->stop_dist;
  return true;
}

truck_msgs__msg__ZfSensorConfigOne *
truck_msgs__msg__ZfSensorConfigOne__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfSensorConfigOne * msg = (truck_msgs__msg__ZfSensorConfigOne *)allocator.allocate(sizeof(truck_msgs__msg__ZfSensorConfigOne), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__ZfSensorConfigOne));
  bool success = truck_msgs__msg__ZfSensorConfigOne__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__ZfSensorConfigOne__destroy(truck_msgs__msg__ZfSensorConfigOne * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__ZfSensorConfigOne__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__ZfSensorConfigOne__Sequence__init(truck_msgs__msg__ZfSensorConfigOne__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfSensorConfigOne * data = NULL;

  if (size) {
    data = (truck_msgs__msg__ZfSensorConfigOne *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__ZfSensorConfigOne), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__ZfSensorConfigOne__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__ZfSensorConfigOne__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__ZfSensorConfigOne__Sequence__fini(truck_msgs__msg__ZfSensorConfigOne__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__ZfSensorConfigOne__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__ZfSensorConfigOne__Sequence *
truck_msgs__msg__ZfSensorConfigOne__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfSensorConfigOne__Sequence * array = (truck_msgs__msg__ZfSensorConfigOne__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__ZfSensorConfigOne__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__ZfSensorConfigOne__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__ZfSensorConfigOne__Sequence__destroy(truck_msgs__msg__ZfSensorConfigOne__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__ZfSensorConfigOne__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__ZfSensorConfigOne__Sequence__are_equal(const truck_msgs__msg__ZfSensorConfigOne__Sequence * lhs, const truck_msgs__msg__ZfSensorConfigOne__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__ZfSensorConfigOne__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__ZfSensorConfigOne__Sequence__copy(
  const truck_msgs__msg__ZfSensorConfigOne__Sequence * input,
  truck_msgs__msg__ZfSensorConfigOne__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__ZfSensorConfigOne);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__ZfSensorConfigOne * data =
      (truck_msgs__msg__ZfSensorConfigOne *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__ZfSensorConfigOne__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__ZfSensorConfigOne__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__ZfSensorConfigOne__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
