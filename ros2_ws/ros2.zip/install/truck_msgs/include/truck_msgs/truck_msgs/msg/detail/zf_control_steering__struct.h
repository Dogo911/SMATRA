// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfControlSteering.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_STEERING__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_STEERING__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ZfControlSteering in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
 */
typedef struct truck_msgs__msg__ZfControlSteering
{
  std_msgs__msg__Header header;
  /// Soll-Lenkwinkel
  float delta;
  /// Soll-Lenkwinkelgeschwindigkeit
  float v_delta;
} truck_msgs__msg__ZfControlSteering;

// Struct for a sequence of truck_msgs__msg__ZfControlSteering.
typedef struct truck_msgs__msg__ZfControlSteering__Sequence
{
  truck_msgs__msg__ZfControlSteering * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfControlSteering__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_STEERING__STRUCT_H_
