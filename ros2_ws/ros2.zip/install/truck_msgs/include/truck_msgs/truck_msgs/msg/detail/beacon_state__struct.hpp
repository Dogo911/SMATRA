// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/BeaconState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'p1'
// Member 'p2'
// Member 'p_center'
#include "geometry_msgs/msg/detail/point__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__BeaconState __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__BeaconState __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BeaconState_
{
  using Type = BeaconState_<ContainerAllocator>;

  explicit BeaconState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    p1(_init),
    p2(_init),
    p_center(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor_active = 0;
      this->control_active = 0;
      this->rviz_marker = 0;
      this->data_n = 0;
      this->used_n = 0;
      this->cnt_b1 = 0;
      this->cnt_b2 = 0;
      this->cnt_mid = 0;
      this->status_b1 = 0;
      this->status_b2 = 0;
      this->status = 0;
      this->alpha = 0;
      this->delta_target = 0.0f;
    }
  }

  explicit BeaconState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    p1(_alloc, _init),
    p2(_alloc, _init),
    p_center(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor_active = 0;
      this->control_active = 0;
      this->rviz_marker = 0;
      this->data_n = 0;
      this->used_n = 0;
      this->cnt_b1 = 0;
      this->cnt_b2 = 0;
      this->cnt_mid = 0;
      this->status_b1 = 0;
      this->status_b2 = 0;
      this->status = 0;
      this->alpha = 0;
      this->delta_target = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _sensor_active_type =
    int16_t;
  _sensor_active_type sensor_active;
  using _control_active_type =
    int16_t;
  _control_active_type control_active;
  using _rviz_marker_type =
    int16_t;
  _rviz_marker_type rviz_marker;
  using _p1_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _p1_type p1;
  using _p2_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _p2_type p2;
  using _p_center_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _p_center_type p_center;
  using _data_n_type =
    int16_t;
  _data_n_type data_n;
  using _used_n_type =
    int16_t;
  _used_n_type used_n;
  using _cnt_b1_type =
    int16_t;
  _cnt_b1_type cnt_b1;
  using _cnt_b2_type =
    int16_t;
  _cnt_b2_type cnt_b2;
  using _cnt_mid_type =
    int16_t;
  _cnt_mid_type cnt_mid;
  using _status_b1_type =
    int16_t;
  _status_b1_type status_b1;
  using _status_b2_type =
    int16_t;
  _status_b2_type status_b2;
  using _status_type =
    int16_t;
  _status_type status;
  using _alpha_type =
    int16_t;
  _alpha_type alpha;
  using _delta_target_type =
    float;
  _delta_target_type delta_target;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__sensor_active(
    const int16_t & _arg)
  {
    this->sensor_active = _arg;
    return *this;
  }
  Type & set__control_active(
    const int16_t & _arg)
  {
    this->control_active = _arg;
    return *this;
  }
  Type & set__rviz_marker(
    const int16_t & _arg)
  {
    this->rviz_marker = _arg;
    return *this;
  }
  Type & set__p1(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->p1 = _arg;
    return *this;
  }
  Type & set__p2(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->p2 = _arg;
    return *this;
  }
  Type & set__p_center(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->p_center = _arg;
    return *this;
  }
  Type & set__data_n(
    const int16_t & _arg)
  {
    this->data_n = _arg;
    return *this;
  }
  Type & set__used_n(
    const int16_t & _arg)
  {
    this->used_n = _arg;
    return *this;
  }
  Type & set__cnt_b1(
    const int16_t & _arg)
  {
    this->cnt_b1 = _arg;
    return *this;
  }
  Type & set__cnt_b2(
    const int16_t & _arg)
  {
    this->cnt_b2 = _arg;
    return *this;
  }
  Type & set__cnt_mid(
    const int16_t & _arg)
  {
    this->cnt_mid = _arg;
    return *this;
  }
  Type & set__status_b1(
    const int16_t & _arg)
  {
    this->status_b1 = _arg;
    return *this;
  }
  Type & set__status_b2(
    const int16_t & _arg)
  {
    this->status_b2 = _arg;
    return *this;
  }
  Type & set__status(
    const int16_t & _arg)
  {
    this->status = _arg;
    return *this;
  }
  Type & set__alpha(
    const int16_t & _arg)
  {
    this->alpha = _arg;
    return *this;
  }
  Type & set__delta_target(
    const float & _arg)
  {
    this->delta_target = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::BeaconState_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::BeaconState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::BeaconState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::BeaconState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::BeaconState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::BeaconState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::BeaconState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::BeaconState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::BeaconState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::BeaconState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__BeaconState
    std::shared_ptr<truck_msgs::msg::BeaconState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__BeaconState
    std::shared_ptr<truck_msgs::msg::BeaconState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BeaconState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->sensor_active != other.sensor_active) {
      return false;
    }
    if (this->control_active != other.control_active) {
      return false;
    }
    if (this->rviz_marker != other.rviz_marker) {
      return false;
    }
    if (this->p1 != other.p1) {
      return false;
    }
    if (this->p2 != other.p2) {
      return false;
    }
    if (this->p_center != other.p_center) {
      return false;
    }
    if (this->data_n != other.data_n) {
      return false;
    }
    if (this->used_n != other.used_n) {
      return false;
    }
    if (this->cnt_b1 != other.cnt_b1) {
      return false;
    }
    if (this->cnt_b2 != other.cnt_b2) {
      return false;
    }
    if (this->cnt_mid != other.cnt_mid) {
      return false;
    }
    if (this->status_b1 != other.status_b1) {
      return false;
    }
    if (this->status_b2 != other.status_b2) {
      return false;
    }
    if (this->status != other.status) {
      return false;
    }
    if (this->alpha != other.alpha) {
      return false;
    }
    if (this->delta_target != other.delta_target) {
      return false;
    }
    return true;
  }
  bool operator!=(const BeaconState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BeaconState_

// alias to use template instance with default allocator
using BeaconState =
  truck_msgs::msg::BeaconState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__STRUCT_HPP_
