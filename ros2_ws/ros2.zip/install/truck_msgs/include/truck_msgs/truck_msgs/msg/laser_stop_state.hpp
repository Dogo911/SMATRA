// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__LASER_STOP_STATE_HPP_
#define TRUCK_MSGS__MSG__LASER_STOP_STATE_HPP_

#include "truck_msgs/msg/detail/laser_stop_state__struct.hpp"
#include "truck_msgs/msg/detail/laser_stop_state__builder.hpp"
#include "truck_msgs/msg/detail/laser_stop_state__traits.hpp"
#include "truck_msgs/msg/detail/laser_stop_state__type_support.hpp"

#endif  // TRUCK_MSGS__MSG__LASER_STOP_STATE_HPP_
