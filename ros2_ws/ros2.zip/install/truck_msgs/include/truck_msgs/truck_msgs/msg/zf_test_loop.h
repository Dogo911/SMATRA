// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:msg/ZfTestLoop.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__ZF_TEST_LOOP_H_
#define TRUCK_MSGS__MSG__ZF_TEST_LOOP_H_

#include "truck_msgs/msg/detail/zf_test_loop__struct.h"
#include "truck_msgs/msg/detail/zf_test_loop__functions.h"
#include "truck_msgs/msg/detail/zf_test_loop__type_support.h"

#endif  // TRUCK_MSGS__MSG__ZF_TEST_LOOP_H_
