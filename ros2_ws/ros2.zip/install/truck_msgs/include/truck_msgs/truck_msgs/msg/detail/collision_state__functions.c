// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/CollisionState.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/collision_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `p1`
// Member `p2`
#include "geometry_msgs/msg/detail/point__functions.h"

bool
truck_msgs__msg__CollisionState__init(truck_msgs__msg__CollisionState * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    truck_msgs__msg__CollisionState__fini(msg);
    return false;
  }
  // stop_active
  // stop_distance
  // sensor_active
  // control_active
  // target_distance
  // max_distance
  // p1
  if (!geometry_msgs__msg__Point__init(&msg->p1)) {
    truck_msgs__msg__CollisionState__fini(msg);
    return false;
  }
  // p2
  if (!geometry_msgs__msg__Point__init(&msg->p2)) {
    truck_msgs__msg__CollisionState__fini(msg);
    return false;
  }
  // width
  // dist_x
  // offset
  // dist
  // alpha
  // beta
  // delta_target
  // v_target
  // width_status
  // dist_status
  // status
  return true;
}

void
truck_msgs__msg__CollisionState__fini(truck_msgs__msg__CollisionState * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // stop_active
  // stop_distance
  // sensor_active
  // control_active
  // target_distance
  // max_distance
  // p1
  geometry_msgs__msg__Point__fini(&msg->p1);
  // p2
  geometry_msgs__msg__Point__fini(&msg->p2);
  // width
  // dist_x
  // offset
  // dist
  // alpha
  // beta
  // delta_target
  // v_target
  // width_status
  // dist_status
  // status
}

bool
truck_msgs__msg__CollisionState__are_equal(const truck_msgs__msg__CollisionState * lhs, const truck_msgs__msg__CollisionState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // stop_active
  if (lhs->stop_active != rhs->stop_active) {
    return false;
  }
  // stop_distance
  if (lhs->stop_distance != rhs->stop_distance) {
    return false;
  }
  // sensor_active
  if (lhs->sensor_active != rhs->sensor_active) {
    return false;
  }
  // control_active
  if (lhs->control_active != rhs->control_active) {
    return false;
  }
  // target_distance
  if (lhs->target_distance != rhs->target_distance) {
    return false;
  }
  // max_distance
  if (lhs->max_distance != rhs->max_distance) {
    return false;
  }
  // p1
  if (!geometry_msgs__msg__Point__are_equal(
      &(lhs->p1), &(rhs->p1)))
  {
    return false;
  }
  // p2
  if (!geometry_msgs__msg__Point__are_equal(
      &(lhs->p2), &(rhs->p2)))
  {
    return false;
  }
  // width
  if (lhs->width != rhs->width) {
    return false;
  }
  // dist_x
  if (lhs->dist_x != rhs->dist_x) {
    return false;
  }
  // offset
  if (lhs->offset != rhs->offset) {
    return false;
  }
  // dist
  if (lhs->dist != rhs->dist) {
    return false;
  }
  // alpha
  if (lhs->alpha != rhs->alpha) {
    return false;
  }
  // beta
  if (lhs->beta != rhs->beta) {
    return false;
  }
  // delta_target
  if (lhs->delta_target != rhs->delta_target) {
    return false;
  }
  // v_target
  if (lhs->v_target != rhs->v_target) {
    return false;
  }
  // width_status
  if (lhs->width_status != rhs->width_status) {
    return false;
  }
  // dist_status
  if (lhs->dist_status != rhs->dist_status) {
    return false;
  }
  // status
  if (lhs->status != rhs->status) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__CollisionState__copy(
  const truck_msgs__msg__CollisionState * input,
  truck_msgs__msg__CollisionState * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // stop_active
  output->stop_active = input->stop_active;
  // stop_distance
  output->stop_distance = input->stop_distance;
  // sensor_active
  output->sensor_active = input->sensor_active;
  // control_active
  output->control_active = input->control_active;
  // target_distance
  output->target_distance = input->target_distance;
  // max_distance
  output->max_distance = input->max_distance;
  // p1
  if (!geometry_msgs__msg__Point__copy(
      &(input->p1), &(output->p1)))
  {
    return false;
  }
  // p2
  if (!geometry_msgs__msg__Point__copy(
      &(input->p2), &(output->p2)))
  {
    return false;
  }
  // width
  output->width = input->width;
  // dist_x
  output->dist_x = input->dist_x;
  // offset
  output->offset = input->offset;
  // dist
  output->dist = input->dist;
  // alpha
  output->alpha = input->alpha;
  // beta
  output->beta = input->beta;
  // delta_target
  output->delta_target = input->delta_target;
  // v_target
  output->v_target = input->v_target;
  // width_status
  output->width_status = input->width_status;
  // dist_status
  output->dist_status = input->dist_status;
  // status
  output->status = input->status;
  return true;
}

truck_msgs__msg__CollisionState *
truck_msgs__msg__CollisionState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__CollisionState * msg = (truck_msgs__msg__CollisionState *)allocator.allocate(sizeof(truck_msgs__msg__CollisionState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__CollisionState));
  bool success = truck_msgs__msg__CollisionState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__CollisionState__destroy(truck_msgs__msg__CollisionState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__CollisionState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__CollisionState__Sequence__init(truck_msgs__msg__CollisionState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__CollisionState * data = NULL;

  if (size) {
    data = (truck_msgs__msg__CollisionState *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__CollisionState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__CollisionState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__CollisionState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__CollisionState__Sequence__fini(truck_msgs__msg__CollisionState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__CollisionState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__CollisionState__Sequence *
truck_msgs__msg__CollisionState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__CollisionState__Sequence * array = (truck_msgs__msg__CollisionState__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__CollisionState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__CollisionState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__CollisionState__Sequence__destroy(truck_msgs__msg__CollisionState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__CollisionState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__CollisionState__Sequence__are_equal(const truck_msgs__msg__CollisionState__Sequence * lhs, const truck_msgs__msg__CollisionState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__CollisionState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__CollisionState__Sequence__copy(
  const truck_msgs__msg__CollisionState__Sequence * input,
  truck_msgs__msg__CollisionState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__CollisionState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__CollisionState * data =
      (truck_msgs__msg__CollisionState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__CollisionState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__CollisionState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__CollisionState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
