// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/SafeRcState.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/safe_rc_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
truck_msgs__msg__SafeRcState__init(truck_msgs__msg__SafeRcState * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    truck_msgs__msg__SafeRcState__fini(msg);
    return false;
  }
  // sensor_active
  // control_active
  // rviz_lines
  // cycle
  // scenario
  // scenario_lower
  // scenario_upper
  // left_wall
  // middle_wall
  // right_wall
  // lower_corner
  // upper_corner
  // steering_min
  // steering_max
  // speed_min
  // speed_max
  // accel_min
  // accel_max
  return true;
}

void
truck_msgs__msg__SafeRcState__fini(truck_msgs__msg__SafeRcState * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // sensor_active
  // control_active
  // rviz_lines
  // cycle
  // scenario
  // scenario_lower
  // scenario_upper
  // left_wall
  // middle_wall
  // right_wall
  // lower_corner
  // upper_corner
  // steering_min
  // steering_max
  // speed_min
  // speed_max
  // accel_min
  // accel_max
}

bool
truck_msgs__msg__SafeRcState__are_equal(const truck_msgs__msg__SafeRcState * lhs, const truck_msgs__msg__SafeRcState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // sensor_active
  if (lhs->sensor_active != rhs->sensor_active) {
    return false;
  }
  // control_active
  if (lhs->control_active != rhs->control_active) {
    return false;
  }
  // rviz_lines
  if (lhs->rviz_lines != rhs->rviz_lines) {
    return false;
  }
  // cycle
  if (lhs->cycle != rhs->cycle) {
    return false;
  }
  // scenario
  if (lhs->scenario != rhs->scenario) {
    return false;
  }
  // scenario_lower
  if (lhs->scenario_lower != rhs->scenario_lower) {
    return false;
  }
  // scenario_upper
  if (lhs->scenario_upper != rhs->scenario_upper) {
    return false;
  }
  // left_wall
  if (lhs->left_wall != rhs->left_wall) {
    return false;
  }
  // middle_wall
  if (lhs->middle_wall != rhs->middle_wall) {
    return false;
  }
  // right_wall
  if (lhs->right_wall != rhs->right_wall) {
    return false;
  }
  // lower_corner
  if (lhs->lower_corner != rhs->lower_corner) {
    return false;
  }
  // upper_corner
  if (lhs->upper_corner != rhs->upper_corner) {
    return false;
  }
  // steering_min
  if (lhs->steering_min != rhs->steering_min) {
    return false;
  }
  // steering_max
  if (lhs->steering_max != rhs->steering_max) {
    return false;
  }
  // speed_min
  if (lhs->speed_min != rhs->speed_min) {
    return false;
  }
  // speed_max
  if (lhs->speed_max != rhs->speed_max) {
    return false;
  }
  // accel_min
  if (lhs->accel_min != rhs->accel_min) {
    return false;
  }
  // accel_max
  if (lhs->accel_max != rhs->accel_max) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__SafeRcState__copy(
  const truck_msgs__msg__SafeRcState * input,
  truck_msgs__msg__SafeRcState * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // sensor_active
  output->sensor_active = input->sensor_active;
  // control_active
  output->control_active = input->control_active;
  // rviz_lines
  output->rviz_lines = input->rviz_lines;
  // cycle
  output->cycle = input->cycle;
  // scenario
  output->scenario = input->scenario;
  // scenario_lower
  output->scenario_lower = input->scenario_lower;
  // scenario_upper
  output->scenario_upper = input->scenario_upper;
  // left_wall
  output->left_wall = input->left_wall;
  // middle_wall
  output->middle_wall = input->middle_wall;
  // right_wall
  output->right_wall = input->right_wall;
  // lower_corner
  output->lower_corner = input->lower_corner;
  // upper_corner
  output->upper_corner = input->upper_corner;
  // steering_min
  output->steering_min = input->steering_min;
  // steering_max
  output->steering_max = input->steering_max;
  // speed_min
  output->speed_min = input->speed_min;
  // speed_max
  output->speed_max = input->speed_max;
  // accel_min
  output->accel_min = input->accel_min;
  // accel_max
  output->accel_max = input->accel_max;
  return true;
}

truck_msgs__msg__SafeRcState *
truck_msgs__msg__SafeRcState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__SafeRcState * msg = (truck_msgs__msg__SafeRcState *)allocator.allocate(sizeof(truck_msgs__msg__SafeRcState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__SafeRcState));
  bool success = truck_msgs__msg__SafeRcState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__SafeRcState__destroy(truck_msgs__msg__SafeRcState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__SafeRcState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__SafeRcState__Sequence__init(truck_msgs__msg__SafeRcState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__SafeRcState * data = NULL;

  if (size) {
    data = (truck_msgs__msg__SafeRcState *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__SafeRcState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__SafeRcState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__SafeRcState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__SafeRcState__Sequence__fini(truck_msgs__msg__SafeRcState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__SafeRcState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__SafeRcState__Sequence *
truck_msgs__msg__SafeRcState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__SafeRcState__Sequence * array = (truck_msgs__msg__SafeRcState__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__SafeRcState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__SafeRcState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__SafeRcState__Sequence__destroy(truck_msgs__msg__SafeRcState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__SafeRcState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__SafeRcState__Sequence__are_equal(const truck_msgs__msg__SafeRcState__Sequence * lhs, const truck_msgs__msg__SafeRcState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__SafeRcState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__SafeRcState__Sequence__copy(
  const truck_msgs__msg__SafeRcState__Sequence * input,
  truck_msgs__msg__SafeRcState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__SafeRcState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__SafeRcState * data =
      (truck_msgs__msg__SafeRcState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__SafeRcState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__SafeRcState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__SafeRcState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
