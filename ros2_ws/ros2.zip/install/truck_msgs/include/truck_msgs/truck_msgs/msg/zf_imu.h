// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:msg/ZfImu.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__ZF_IMU_H_
#define TRUCK_MSGS__MSG__ZF_IMU_H_

#include "truck_msgs/msg/detail/zf_imu__struct.h"
#include "truck_msgs/msg/detail/zf_imu__functions.h"
#include "truck_msgs/msg/detail/zf_imu__type_support.h"

#endif  // TRUCK_MSGS__MSG__ZF_IMU_H_
