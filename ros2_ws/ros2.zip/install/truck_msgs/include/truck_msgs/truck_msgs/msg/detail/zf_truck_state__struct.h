﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfTruckState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ZfTruckState in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * zf_truck_state.msg
  *
  * Version 6.0
 */
typedef struct truck_msgs__msg__ZfTruckState
{
  std_msgs__msg__Header header;
  /// Modus Querführung (vgl. Truck_Interface.h)
  int8_t mode_lat;
  /// Modus Längsführung (vgl. Truck_Interface.h)
  int8_t mode_long;
  /// kommandierte Soll-Geschwindigkeit
  float control_v;
  /// kommandierte Soll-Beschleuningung
  float control_a;
  /// kommandierter Soll-Lenkwinkel
  float control_delta;
  /// kommandierter Soll-Lenkwinkelgeschwindigkeit
  float control_v_delta;
  /// Ist-Geschwindigkeit
  float v;
  /// Ist-Lenkwinkel
  float delta;
  /// servo command steer
  int8_t cmd_steer;
  /// servo command speed
  int8_t cmd_speed;
  /// Arduino-Zyklusnummer
  uint32_t cycle_ard0;
  /// Hub-Zyklusnummer
  uint32_t cycle_hub;
  /// TF-Zyklusnummer
  uint32_t cycle_tf;
  /// Zustand des Nothalt-Knopfes
  bool btn_emerg_stop;
  /// Nothalt
  bool emerg_stop;
  /// Ursache des Nothalts (bits, vgl. Truck_Interface.h)
  int16_t emerg_stop_rsn;
} truck_msgs__msg__ZfTruckState;

// Struct for a sequence of truck_msgs__msg__ZfTruckState.
typedef struct truck_msgs__msg__ZfTruckState__Sequence
{
  truck_msgs__msg__ZfTruckState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfTruckState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE__STRUCT_H_
