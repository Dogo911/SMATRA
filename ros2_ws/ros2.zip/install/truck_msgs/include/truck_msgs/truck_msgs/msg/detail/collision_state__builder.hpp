// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/CollisionState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/collision_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_CollisionState_status
{
public:
  explicit Init_CollisionState_status(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::CollisionState status(::truck_msgs::msg::CollisionState::_status_type arg)
  {
    msg_.status = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_dist_status
{
public:
  explicit Init_CollisionState_dist_status(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_status dist_status(::truck_msgs::msg::CollisionState::_dist_status_type arg)
  {
    msg_.dist_status = std::move(arg);
    return Init_CollisionState_status(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_width_status
{
public:
  explicit Init_CollisionState_width_status(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_dist_status width_status(::truck_msgs::msg::CollisionState::_width_status_type arg)
  {
    msg_.width_status = std::move(arg);
    return Init_CollisionState_dist_status(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_v_target
{
public:
  explicit Init_CollisionState_v_target(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_width_status v_target(::truck_msgs::msg::CollisionState::_v_target_type arg)
  {
    msg_.v_target = std::move(arg);
    return Init_CollisionState_width_status(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_delta_target
{
public:
  explicit Init_CollisionState_delta_target(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_v_target delta_target(::truck_msgs::msg::CollisionState::_delta_target_type arg)
  {
    msg_.delta_target = std::move(arg);
    return Init_CollisionState_v_target(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_beta
{
public:
  explicit Init_CollisionState_beta(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_delta_target beta(::truck_msgs::msg::CollisionState::_beta_type arg)
  {
    msg_.beta = std::move(arg);
    return Init_CollisionState_delta_target(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_alpha
{
public:
  explicit Init_CollisionState_alpha(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_beta alpha(::truck_msgs::msg::CollisionState::_alpha_type arg)
  {
    msg_.alpha = std::move(arg);
    return Init_CollisionState_beta(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_dist
{
public:
  explicit Init_CollisionState_dist(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_alpha dist(::truck_msgs::msg::CollisionState::_dist_type arg)
  {
    msg_.dist = std::move(arg);
    return Init_CollisionState_alpha(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_offset
{
public:
  explicit Init_CollisionState_offset(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_dist offset(::truck_msgs::msg::CollisionState::_offset_type arg)
  {
    msg_.offset = std::move(arg);
    return Init_CollisionState_dist(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_dist_x
{
public:
  explicit Init_CollisionState_dist_x(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_offset dist_x(::truck_msgs::msg::CollisionState::_dist_x_type arg)
  {
    msg_.dist_x = std::move(arg);
    return Init_CollisionState_offset(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_width
{
public:
  explicit Init_CollisionState_width(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_dist_x width(::truck_msgs::msg::CollisionState::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_CollisionState_dist_x(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_p2
{
public:
  explicit Init_CollisionState_p2(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_width p2(::truck_msgs::msg::CollisionState::_p2_type arg)
  {
    msg_.p2 = std::move(arg);
    return Init_CollisionState_width(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_p1
{
public:
  explicit Init_CollisionState_p1(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_p2 p1(::truck_msgs::msg::CollisionState::_p1_type arg)
  {
    msg_.p1 = std::move(arg);
    return Init_CollisionState_p2(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_max_distance
{
public:
  explicit Init_CollisionState_max_distance(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_p1 max_distance(::truck_msgs::msg::CollisionState::_max_distance_type arg)
  {
    msg_.max_distance = std::move(arg);
    return Init_CollisionState_p1(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_target_distance
{
public:
  explicit Init_CollisionState_target_distance(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_max_distance target_distance(::truck_msgs::msg::CollisionState::_target_distance_type arg)
  {
    msg_.target_distance = std::move(arg);
    return Init_CollisionState_max_distance(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_control_active
{
public:
  explicit Init_CollisionState_control_active(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_target_distance control_active(::truck_msgs::msg::CollisionState::_control_active_type arg)
  {
    msg_.control_active = std::move(arg);
    return Init_CollisionState_target_distance(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_sensor_active
{
public:
  explicit Init_CollisionState_sensor_active(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_control_active sensor_active(::truck_msgs::msg::CollisionState::_sensor_active_type arg)
  {
    msg_.sensor_active = std::move(arg);
    return Init_CollisionState_control_active(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_stop_distance
{
public:
  explicit Init_CollisionState_stop_distance(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_sensor_active stop_distance(::truck_msgs::msg::CollisionState::_stop_distance_type arg)
  {
    msg_.stop_distance = std::move(arg);
    return Init_CollisionState_sensor_active(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_stop_active
{
public:
  explicit Init_CollisionState_stop_active(::truck_msgs::msg::CollisionState & msg)
  : msg_(msg)
  {}
  Init_CollisionState_stop_distance stop_active(::truck_msgs::msg::CollisionState::_stop_active_type arg)
  {
    msg_.stop_active = std::move(arg);
    return Init_CollisionState_stop_distance(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

class Init_CollisionState_header
{
public:
  Init_CollisionState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CollisionState_stop_active header(::truck_msgs::msg::CollisionState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_CollisionState_stop_active(msg_);
  }

private:
  ::truck_msgs::msg::CollisionState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::CollisionState>()
{
  return truck_msgs::msg::builder::Init_CollisionState_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__BUILDER_HPP_
