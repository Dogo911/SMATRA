// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfTruckConfig.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_CONFIG__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_CONFIG__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_truck_config__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'controller_params'
#include "truck_msgs/msg/detail/zf_controller_params__traits.hpp"
// Member 'sensor_config'
#include "truck_msgs/msg/detail/zf_sensor_config__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfTruckConfig & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: controller_params
  {
    out << "controller_params: ";
    to_flow_style_yaml(msg.controller_params, out);
    out << ", ";
  }

  // member: sensor_config
  {
    out << "sensor_config: ";
    to_flow_style_yaml(msg.sensor_config, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfTruckConfig & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: controller_params
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "controller_params:\n";
    to_block_style_yaml(msg.controller_params, out, indentation + 2);
  }

  // member: sensor_config
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_config:\n";
    to_block_style_yaml(msg.sensor_config, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfTruckConfig & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfTruckConfig & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfTruckConfig & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfTruckConfig>()
{
  return "truck_msgs::msg::ZfTruckConfig";
}

template<>
inline const char * name<truck_msgs::msg::ZfTruckConfig>()
{
  return "truck_msgs/msg/ZfTruckConfig";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfTruckConfig>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value && has_fixed_size<truck_msgs::msg::ZfControllerParams>::value && has_fixed_size<truck_msgs::msg::ZfSensorConfig>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfTruckConfig>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value && has_bounded_size<truck_msgs::msg::ZfControllerParams>::value && has_bounded_size<truck_msgs::msg::ZfSensorConfig>::value> {};

template<>
struct is_message<truck_msgs::msg::ZfTruckConfig>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_CONFIG__TRAITS_HPP_
