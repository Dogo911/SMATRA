// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/ZfSensorConfig.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/zf_sensor_config__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `config`
#include "truck_msgs/msg/detail/zf_sensor_config_one__functions.h"

bool
truck_msgs__msg__ZfSensorConfig__init(truck_msgs__msg__ZfSensorConfig * msg)
{
  if (!msg) {
    return false;
  }
  // config
  for (size_t i = 0; i < 7; ++i) {
    if (!truck_msgs__msg__ZfSensorConfigOne__init(&msg->config[i])) {
      truck_msgs__msg__ZfSensorConfig__fini(msg);
      return false;
    }
  }
  // cnt
  return true;
}

void
truck_msgs__msg__ZfSensorConfig__fini(truck_msgs__msg__ZfSensorConfig * msg)
{
  if (!msg) {
    return;
  }
  // config
  for (size_t i = 0; i < 7; ++i) {
    truck_msgs__msg__ZfSensorConfigOne__fini(&msg->config[i]);
  }
  // cnt
}

bool
truck_msgs__msg__ZfSensorConfig__are_equal(const truck_msgs__msg__ZfSensorConfig * lhs, const truck_msgs__msg__ZfSensorConfig * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // config
  for (size_t i = 0; i < 7; ++i) {
    if (!truck_msgs__msg__ZfSensorConfigOne__are_equal(
        &(lhs->config[i]), &(rhs->config[i])))
    {
      return false;
    }
  }
  // cnt
  if (lhs->cnt != rhs->cnt) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__ZfSensorConfig__copy(
  const truck_msgs__msg__ZfSensorConfig * input,
  truck_msgs__msg__ZfSensorConfig * output)
{
  if (!input || !output) {
    return false;
  }
  // config
  for (size_t i = 0; i < 7; ++i) {
    if (!truck_msgs__msg__ZfSensorConfigOne__copy(
        &(input->config[i]), &(output->config[i])))
    {
      return false;
    }
  }
  // cnt
  output->cnt = input->cnt;
  return true;
}

truck_msgs__msg__ZfSensorConfig *
truck_msgs__msg__ZfSensorConfig__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfSensorConfig * msg = (truck_msgs__msg__ZfSensorConfig *)allocator.allocate(sizeof(truck_msgs__msg__ZfSensorConfig), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__ZfSensorConfig));
  bool success = truck_msgs__msg__ZfSensorConfig__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__ZfSensorConfig__destroy(truck_msgs__msg__ZfSensorConfig * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__ZfSensorConfig__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__ZfSensorConfig__Sequence__init(truck_msgs__msg__ZfSensorConfig__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfSensorConfig * data = NULL;

  if (size) {
    data = (truck_msgs__msg__ZfSensorConfig *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__ZfSensorConfig), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__ZfSensorConfig__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__ZfSensorConfig__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__ZfSensorConfig__Sequence__fini(truck_msgs__msg__ZfSensorConfig__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__ZfSensorConfig__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__ZfSensorConfig__Sequence *
truck_msgs__msg__ZfSensorConfig__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfSensorConfig__Sequence * array = (truck_msgs__msg__ZfSensorConfig__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__ZfSensorConfig__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__ZfSensorConfig__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__ZfSensorConfig__Sequence__destroy(truck_msgs__msg__ZfSensorConfig__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__ZfSensorConfig__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__ZfSensorConfig__Sequence__are_equal(const truck_msgs__msg__ZfSensorConfig__Sequence * lhs, const truck_msgs__msg__ZfSensorConfig__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__ZfSensorConfig__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__ZfSensorConfig__Sequence__copy(
  const truck_msgs__msg__ZfSensorConfig__Sequence * input,
  truck_msgs__msg__ZfSensorConfig__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__ZfSensorConfig);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__ZfSensorConfig * data =
      (truck_msgs__msg__ZfSensorConfig *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__ZfSensorConfig__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__ZfSensorConfig__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__ZfSensorConfig__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
