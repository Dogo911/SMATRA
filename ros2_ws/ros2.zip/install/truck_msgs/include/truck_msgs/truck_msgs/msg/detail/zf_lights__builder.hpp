// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfLights.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_lights__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfLights_cornering_right
{
public:
  explicit Init_ZfLights_cornering_right(::truck_msgs::msg::ZfLights & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfLights cornering_right(::truck_msgs::msg::ZfLights::_cornering_right_type arg)
  {
    msg_.cornering_right = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfLights msg_;
};

class Init_ZfLights_cornering_left
{
public:
  explicit Init_ZfLights_cornering_left(::truck_msgs::msg::ZfLights & msg)
  : msg_(msg)
  {}
  Init_ZfLights_cornering_right cornering_left(::truck_msgs::msg::ZfLights::_cornering_left_type arg)
  {
    msg_.cornering_left = std::move(arg);
    return Init_ZfLights_cornering_right(msg_);
  }

private:
  ::truck_msgs::msg::ZfLights msg_;
};

class Init_ZfLights_reversing
{
public:
  explicit Init_ZfLights_reversing(::truck_msgs::msg::ZfLights & msg)
  : msg_(msg)
  {}
  Init_ZfLights_cornering_left reversing(::truck_msgs::msg::ZfLights::_reversing_type arg)
  {
    msg_.reversing = std::move(arg);
    return Init_ZfLights_cornering_left(msg_);
  }

private:
  ::truck_msgs::msg::ZfLights msg_;
};

class Init_ZfLights_high_beam
{
public:
  explicit Init_ZfLights_high_beam(::truck_msgs::msg::ZfLights & msg)
  : msg_(msg)
  {}
  Init_ZfLights_reversing high_beam(::truck_msgs::msg::ZfLights::_high_beam_type arg)
  {
    msg_.high_beam = std::move(arg);
    return Init_ZfLights_reversing(msg_);
  }

private:
  ::truck_msgs::msg::ZfLights msg_;
};

class Init_ZfLights_indicator_right
{
public:
  explicit Init_ZfLights_indicator_right(::truck_msgs::msg::ZfLights & msg)
  : msg_(msg)
  {}
  Init_ZfLights_high_beam indicator_right(::truck_msgs::msg::ZfLights::_indicator_right_type arg)
  {
    msg_.indicator_right = std::move(arg);
    return Init_ZfLights_high_beam(msg_);
  }

private:
  ::truck_msgs::msg::ZfLights msg_;
};

class Init_ZfLights_indicator_left
{
public:
  explicit Init_ZfLights_indicator_left(::truck_msgs::msg::ZfLights & msg)
  : msg_(msg)
  {}
  Init_ZfLights_indicator_right indicator_left(::truck_msgs::msg::ZfLights::_indicator_left_type arg)
  {
    msg_.indicator_left = std::move(arg);
    return Init_ZfLights_indicator_right(msg_);
  }

private:
  ::truck_msgs::msg::ZfLights msg_;
};

class Init_ZfLights_braking
{
public:
  explicit Init_ZfLights_braking(::truck_msgs::msg::ZfLights & msg)
  : msg_(msg)
  {}
  Init_ZfLights_indicator_left braking(::truck_msgs::msg::ZfLights::_braking_type arg)
  {
    msg_.braking = std::move(arg);
    return Init_ZfLights_indicator_left(msg_);
  }

private:
  ::truck_msgs::msg::ZfLights msg_;
};

class Init_ZfLights_driving
{
public:
  explicit Init_ZfLights_driving(::truck_msgs::msg::ZfLights & msg)
  : msg_(msg)
  {}
  Init_ZfLights_braking driving(::truck_msgs::msg::ZfLights::_driving_type arg)
  {
    msg_.driving = std::move(arg);
    return Init_ZfLights_braking(msg_);
  }

private:
  ::truck_msgs::msg::ZfLights msg_;
};

class Init_ZfLights_header
{
public:
  Init_ZfLights_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfLights_driving header(::truck_msgs::msg::ZfLights::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfLights_driving(msg_);
  }

private:
  ::truck_msgs::msg::ZfLights msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfLights>()
{
  return truck_msgs::msg::builder::Init_ZfLights_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_LIGHTS__BUILDER_HPP_
