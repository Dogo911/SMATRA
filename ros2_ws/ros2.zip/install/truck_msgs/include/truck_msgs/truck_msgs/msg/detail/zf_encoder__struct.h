// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfEncoder.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ZfEncoder in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * zf_encoder.msg
  *
  * Encoder 12bit raw data
  *
  * Version 5.7
 */
typedef struct truck_msgs__msg__ZfEncoder
{
  std_msgs__msg__Header header;
  /// left front wheel
  int32_t left;
  /// right front wheel
  int32_t right;
  /// back axis
  int32_t back;
  /// steering
  int32_t steering;
  /// trailer
  int32_t trailer;
  /// slave arduino timestamp
  uint32_t timestamp_slave;
  /// master arduino timestamp
  uint32_t timestamp_master;
  /// ros_bridge timestamp
  uint32_t timestamp_bridge;
} truck_msgs__msg__ZfEncoder;

// Struct for a sequence of truck_msgs__msg__ZfEncoder.
typedef struct truck_msgs__msg__ZfEncoder__Sequence
{
  truck_msgs__msg__ZfEncoder * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfEncoder__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_ENCODER__STRUCT_H_
