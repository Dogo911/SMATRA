// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__SYSTEM_STATE_HPP_
#define TRUCK_MSGS__MSG__SYSTEM_STATE_HPP_

#include "truck_msgs/msg/detail/system_state__struct.hpp"
#include "truck_msgs/msg/detail/system_state__builder.hpp"
#include "truck_msgs/msg/detail/system_state__traits.hpp"
#include "truck_msgs/msg/detail/system_state__type_support.hpp"

#endif  // TRUCK_MSGS__MSG__SYSTEM_STATE_HPP_
