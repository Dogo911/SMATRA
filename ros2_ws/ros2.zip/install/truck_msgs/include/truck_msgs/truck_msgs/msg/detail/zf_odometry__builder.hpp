// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfOdometry.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_ODOMETRY__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_ODOMETRY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_odometry__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfOdometry_yaw_diff
{
public:
  explicit Init_ZfOdometry_yaw_diff(::truck_msgs::msg::ZfOdometry & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfOdometry yaw_diff(::truck_msgs::msg::ZfOdometry::_yaw_diff_type arg)
  {
    msg_.yaw_diff = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfOdometry msg_;
};

class Init_ZfOdometry_yaw
{
public:
  explicit Init_ZfOdometry_yaw(::truck_msgs::msg::ZfOdometry & msg)
  : msg_(msg)
  {}
  Init_ZfOdometry_yaw_diff yaw(::truck_msgs::msg::ZfOdometry::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_ZfOdometry_yaw_diff(msg_);
  }

private:
  ::truck_msgs::msg::ZfOdometry msg_;
};

class Init_ZfOdometry_delta_encoder
{
public:
  explicit Init_ZfOdometry_delta_encoder(::truck_msgs::msg::ZfOdometry & msg)
  : msg_(msg)
  {}
  Init_ZfOdometry_yaw delta_encoder(::truck_msgs::msg::ZfOdometry::_delta_encoder_type arg)
  {
    msg_.delta_encoder = std::move(arg);
    return Init_ZfOdometry_yaw(msg_);
  }

private:
  ::truck_msgs::msg::ZfOdometry msg_;
};

class Init_ZfOdometry_dist_back
{
public:
  explicit Init_ZfOdometry_dist_back(::truck_msgs::msg::ZfOdometry & msg)
  : msg_(msg)
  {}
  Init_ZfOdometry_delta_encoder dist_back(::truck_msgs::msg::ZfOdometry::_dist_back_type arg)
  {
    msg_.dist_back = std::move(arg);
    return Init_ZfOdometry_delta_encoder(msg_);
  }

private:
  ::truck_msgs::msg::ZfOdometry msg_;
};

class Init_ZfOdometry_dist_right
{
public:
  explicit Init_ZfOdometry_dist_right(::truck_msgs::msg::ZfOdometry & msg)
  : msg_(msg)
  {}
  Init_ZfOdometry_dist_back dist_right(::truck_msgs::msg::ZfOdometry::_dist_right_type arg)
  {
    msg_.dist_right = std::move(arg);
    return Init_ZfOdometry_dist_back(msg_);
  }

private:
  ::truck_msgs::msg::ZfOdometry msg_;
};

class Init_ZfOdometry_dist_left
{
public:
  explicit Init_ZfOdometry_dist_left(::truck_msgs::msg::ZfOdometry & msg)
  : msg_(msg)
  {}
  Init_ZfOdometry_dist_right dist_left(::truck_msgs::msg::ZfOdometry::_dist_left_type arg)
  {
    msg_.dist_left = std::move(arg);
    return Init_ZfOdometry_dist_right(msg_);
  }

private:
  ::truck_msgs::msg::ZfOdometry msg_;
};

class Init_ZfOdometry_header
{
public:
  Init_ZfOdometry_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfOdometry_dist_left header(::truck_msgs::msg::ZfOdometry::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfOdometry_dist_left(msg_);
  }

private:
  ::truck_msgs::msg::ZfOdometry msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfOdometry>()
{
  return truck_msgs::msg::builder::Init_ZfOdometry_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_ODOMETRY__BUILDER_HPP_
