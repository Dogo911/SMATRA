// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfOdometry.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_ODOMETRY__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_ODOMETRY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ZfOdometry in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * zf_odometry.msg
  *
  * Version 6.0.2
 */
typedef struct truck_msgs__msg__ZfOdometry
{
  std_msgs__msg__Header header;
  /// distance travelled left front wheel
  float dist_left;
  /// distance travelled right front wheel
  float dist_right;
  /// distance travelled back axis
  float dist_back;
  /// encoder difference (left - right) in one cycle
  int16_t delta_encoder;
  /// yaw angle
  float yaw;
  /// yaw angle
  float yaw_diff;
} truck_msgs__msg__ZfOdometry;

// Struct for a sequence of truck_msgs__msg__ZfOdometry.
typedef struct truck_msgs__msg__ZfOdometry__Sequence
{
  truck_msgs__msg__ZfOdometry * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfOdometry__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_ODOMETRY__STRUCT_H_
