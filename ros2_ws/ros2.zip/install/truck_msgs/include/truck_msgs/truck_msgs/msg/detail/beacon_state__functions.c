// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/BeaconState.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/beacon_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `p1`
// Member `p2`
// Member `p_center`
#include "geometry_msgs/msg/detail/point__functions.h"

bool
truck_msgs__msg__BeaconState__init(truck_msgs__msg__BeaconState * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    truck_msgs__msg__BeaconState__fini(msg);
    return false;
  }
  // sensor_active
  // control_active
  // rviz_marker
  // p1
  if (!geometry_msgs__msg__Point__init(&msg->p1)) {
    truck_msgs__msg__BeaconState__fini(msg);
    return false;
  }
  // p2
  if (!geometry_msgs__msg__Point__init(&msg->p2)) {
    truck_msgs__msg__BeaconState__fini(msg);
    return false;
  }
  // p_center
  if (!geometry_msgs__msg__Point__init(&msg->p_center)) {
    truck_msgs__msg__BeaconState__fini(msg);
    return false;
  }
  // data_n
  // used_n
  // cnt_b1
  // cnt_b2
  // cnt_mid
  // status_b1
  // status_b2
  // status
  // alpha
  // delta_target
  return true;
}

void
truck_msgs__msg__BeaconState__fini(truck_msgs__msg__BeaconState * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // sensor_active
  // control_active
  // rviz_marker
  // p1
  geometry_msgs__msg__Point__fini(&msg->p1);
  // p2
  geometry_msgs__msg__Point__fini(&msg->p2);
  // p_center
  geometry_msgs__msg__Point__fini(&msg->p_center);
  // data_n
  // used_n
  // cnt_b1
  // cnt_b2
  // cnt_mid
  // status_b1
  // status_b2
  // status
  // alpha
  // delta_target
}

bool
truck_msgs__msg__BeaconState__are_equal(const truck_msgs__msg__BeaconState * lhs, const truck_msgs__msg__BeaconState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // sensor_active
  if (lhs->sensor_active != rhs->sensor_active) {
    return false;
  }
  // control_active
  if (lhs->control_active != rhs->control_active) {
    return false;
  }
  // rviz_marker
  if (lhs->rviz_marker != rhs->rviz_marker) {
    return false;
  }
  // p1
  if (!geometry_msgs__msg__Point__are_equal(
      &(lhs->p1), &(rhs->p1)))
  {
    return false;
  }
  // p2
  if (!geometry_msgs__msg__Point__are_equal(
      &(lhs->p2), &(rhs->p2)))
  {
    return false;
  }
  // p_center
  if (!geometry_msgs__msg__Point__are_equal(
      &(lhs->p_center), &(rhs->p_center)))
  {
    return false;
  }
  // data_n
  if (lhs->data_n != rhs->data_n) {
    return false;
  }
  // used_n
  if (lhs->used_n != rhs->used_n) {
    return false;
  }
  // cnt_b1
  if (lhs->cnt_b1 != rhs->cnt_b1) {
    return false;
  }
  // cnt_b2
  if (lhs->cnt_b2 != rhs->cnt_b2) {
    return false;
  }
  // cnt_mid
  if (lhs->cnt_mid != rhs->cnt_mid) {
    return false;
  }
  // status_b1
  if (lhs->status_b1 != rhs->status_b1) {
    return false;
  }
  // status_b2
  if (lhs->status_b2 != rhs->status_b2) {
    return false;
  }
  // status
  if (lhs->status != rhs->status) {
    return false;
  }
  // alpha
  if (lhs->alpha != rhs->alpha) {
    return false;
  }
  // delta_target
  if (lhs->delta_target != rhs->delta_target) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__BeaconState__copy(
  const truck_msgs__msg__BeaconState * input,
  truck_msgs__msg__BeaconState * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // sensor_active
  output->sensor_active = input->sensor_active;
  // control_active
  output->control_active = input->control_active;
  // rviz_marker
  output->rviz_marker = input->rviz_marker;
  // p1
  if (!geometry_msgs__msg__Point__copy(
      &(input->p1), &(output->p1)))
  {
    return false;
  }
  // p2
  if (!geometry_msgs__msg__Point__copy(
      &(input->p2), &(output->p2)))
  {
    return false;
  }
  // p_center
  if (!geometry_msgs__msg__Point__copy(
      &(input->p_center), &(output->p_center)))
  {
    return false;
  }
  // data_n
  output->data_n = input->data_n;
  // used_n
  output->used_n = input->used_n;
  // cnt_b1
  output->cnt_b1 = input->cnt_b1;
  // cnt_b2
  output->cnt_b2 = input->cnt_b2;
  // cnt_mid
  output->cnt_mid = input->cnt_mid;
  // status_b1
  output->status_b1 = input->status_b1;
  // status_b2
  output->status_b2 = input->status_b2;
  // status
  output->status = input->status;
  // alpha
  output->alpha = input->alpha;
  // delta_target
  output->delta_target = input->delta_target;
  return true;
}

truck_msgs__msg__BeaconState *
truck_msgs__msg__BeaconState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__BeaconState * msg = (truck_msgs__msg__BeaconState *)allocator.allocate(sizeof(truck_msgs__msg__BeaconState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__BeaconState));
  bool success = truck_msgs__msg__BeaconState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__BeaconState__destroy(truck_msgs__msg__BeaconState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__BeaconState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__BeaconState__Sequence__init(truck_msgs__msg__BeaconState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__BeaconState * data = NULL;

  if (size) {
    data = (truck_msgs__msg__BeaconState *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__BeaconState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__BeaconState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__BeaconState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__BeaconState__Sequence__fini(truck_msgs__msg__BeaconState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__BeaconState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__BeaconState__Sequence *
truck_msgs__msg__BeaconState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__BeaconState__Sequence * array = (truck_msgs__msg__BeaconState__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__BeaconState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__BeaconState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__BeaconState__Sequence__destroy(truck_msgs__msg__BeaconState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__BeaconState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__BeaconState__Sequence__are_equal(const truck_msgs__msg__BeaconState__Sequence * lhs, const truck_msgs__msg__BeaconState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__BeaconState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__BeaconState__Sequence__copy(
  const truck_msgs__msg__BeaconState__Sequence * input,
  truck_msgs__msg__BeaconState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__BeaconState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__BeaconState * data =
      (truck_msgs__msg__BeaconState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__BeaconState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__BeaconState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__BeaconState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
