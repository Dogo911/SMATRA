// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/SafeRcState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/safe_rc_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_SafeRcState_accel_max
{
public:
  explicit Init_SafeRcState_accel_max(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::SafeRcState accel_max(::truck_msgs::msg::SafeRcState::_accel_max_type arg)
  {
    msg_.accel_max = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_accel_min
{
public:
  explicit Init_SafeRcState_accel_min(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_accel_max accel_min(::truck_msgs::msg::SafeRcState::_accel_min_type arg)
  {
    msg_.accel_min = std::move(arg);
    return Init_SafeRcState_accel_max(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_speed_max
{
public:
  explicit Init_SafeRcState_speed_max(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_accel_min speed_max(::truck_msgs::msg::SafeRcState::_speed_max_type arg)
  {
    msg_.speed_max = std::move(arg);
    return Init_SafeRcState_accel_min(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_speed_min
{
public:
  explicit Init_SafeRcState_speed_min(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_speed_max speed_min(::truck_msgs::msg::SafeRcState::_speed_min_type arg)
  {
    msg_.speed_min = std::move(arg);
    return Init_SafeRcState_speed_max(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_steering_max
{
public:
  explicit Init_SafeRcState_steering_max(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_speed_min steering_max(::truck_msgs::msg::SafeRcState::_steering_max_type arg)
  {
    msg_.steering_max = std::move(arg);
    return Init_SafeRcState_speed_min(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_steering_min
{
public:
  explicit Init_SafeRcState_steering_min(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_steering_max steering_min(::truck_msgs::msg::SafeRcState::_steering_min_type arg)
  {
    msg_.steering_min = std::move(arg);
    return Init_SafeRcState_steering_max(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_upper_corner
{
public:
  explicit Init_SafeRcState_upper_corner(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_steering_min upper_corner(::truck_msgs::msg::SafeRcState::_upper_corner_type arg)
  {
    msg_.upper_corner = std::move(arg);
    return Init_SafeRcState_steering_min(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_lower_corner
{
public:
  explicit Init_SafeRcState_lower_corner(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_upper_corner lower_corner(::truck_msgs::msg::SafeRcState::_lower_corner_type arg)
  {
    msg_.lower_corner = std::move(arg);
    return Init_SafeRcState_upper_corner(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_right_wall
{
public:
  explicit Init_SafeRcState_right_wall(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_lower_corner right_wall(::truck_msgs::msg::SafeRcState::_right_wall_type arg)
  {
    msg_.right_wall = std::move(arg);
    return Init_SafeRcState_lower_corner(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_middle_wall
{
public:
  explicit Init_SafeRcState_middle_wall(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_right_wall middle_wall(::truck_msgs::msg::SafeRcState::_middle_wall_type arg)
  {
    msg_.middle_wall = std::move(arg);
    return Init_SafeRcState_right_wall(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_left_wall
{
public:
  explicit Init_SafeRcState_left_wall(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_middle_wall left_wall(::truck_msgs::msg::SafeRcState::_left_wall_type arg)
  {
    msg_.left_wall = std::move(arg);
    return Init_SafeRcState_middle_wall(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_scenario_upper
{
public:
  explicit Init_SafeRcState_scenario_upper(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_left_wall scenario_upper(::truck_msgs::msg::SafeRcState::_scenario_upper_type arg)
  {
    msg_.scenario_upper = std::move(arg);
    return Init_SafeRcState_left_wall(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_scenario_lower
{
public:
  explicit Init_SafeRcState_scenario_lower(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_scenario_upper scenario_lower(::truck_msgs::msg::SafeRcState::_scenario_lower_type arg)
  {
    msg_.scenario_lower = std::move(arg);
    return Init_SafeRcState_scenario_upper(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_scenario
{
public:
  explicit Init_SafeRcState_scenario(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_scenario_lower scenario(::truck_msgs::msg::SafeRcState::_scenario_type arg)
  {
    msg_.scenario = std::move(arg);
    return Init_SafeRcState_scenario_lower(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_cycle
{
public:
  explicit Init_SafeRcState_cycle(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_scenario cycle(::truck_msgs::msg::SafeRcState::_cycle_type arg)
  {
    msg_.cycle = std::move(arg);
    return Init_SafeRcState_scenario(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_rviz_lines
{
public:
  explicit Init_SafeRcState_rviz_lines(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_cycle rviz_lines(::truck_msgs::msg::SafeRcState::_rviz_lines_type arg)
  {
    msg_.rviz_lines = std::move(arg);
    return Init_SafeRcState_cycle(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_control_active
{
public:
  explicit Init_SafeRcState_control_active(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_rviz_lines control_active(::truck_msgs::msg::SafeRcState::_control_active_type arg)
  {
    msg_.control_active = std::move(arg);
    return Init_SafeRcState_rviz_lines(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_sensor_active
{
public:
  explicit Init_SafeRcState_sensor_active(::truck_msgs::msg::SafeRcState & msg)
  : msg_(msg)
  {}
  Init_SafeRcState_control_active sensor_active(::truck_msgs::msg::SafeRcState::_sensor_active_type arg)
  {
    msg_.sensor_active = std::move(arg);
    return Init_SafeRcState_control_active(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

class Init_SafeRcState_header
{
public:
  Init_SafeRcState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SafeRcState_sensor_active header(::truck_msgs::msg::SafeRcState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SafeRcState_sensor_active(msg_);
  }

private:
  ::truck_msgs::msg::SafeRcState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::SafeRcState>()
{
  return truck_msgs::msg::builder::Init_SafeRcState_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__BUILDER_HPP_
