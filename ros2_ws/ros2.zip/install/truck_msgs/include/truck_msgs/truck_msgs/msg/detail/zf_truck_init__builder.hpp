// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfTruckInit.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_INIT__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_INIT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_truck_init__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfTruckInit_psi
{
public:
  explicit Init_ZfTruckInit_psi(::truck_msgs::msg::ZfTruckInit & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfTruckInit psi(::truck_msgs::msg::ZfTruckInit::_psi_type arg)
  {
    msg_.psi = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckInit msg_;
};

class Init_ZfTruckInit_y
{
public:
  explicit Init_ZfTruckInit_y(::truck_msgs::msg::ZfTruckInit & msg)
  : msg_(msg)
  {}
  Init_ZfTruckInit_psi y(::truck_msgs::msg::ZfTruckInit::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_ZfTruckInit_psi(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckInit msg_;
};

class Init_ZfTruckInit_x
{
public:
  Init_ZfTruckInit_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfTruckInit_y x(::truck_msgs::msg::ZfTruckInit::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_ZfTruckInit_y(msg_);
  }

private:
  ::truck_msgs::msg::ZfTruckInit msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfTruckInit>()
{
  return truck_msgs::msg::builder::Init_ZfTruckInit_x();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_INIT__BUILDER_HPP_
