// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/ZfTestLoop.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__ZfTestLoop __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__ZfTestLoop __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ZfTestLoop_
{
  using Type = ZfTestLoop_<ContainerAllocator>;

  explicit ZfTestLoop_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sender = 0;
      this->timestamp_ros_out = 0ul;
      this->timestamp_bridge_out = 0ul;
      this->timestamp_master_out = 0;
      this->timestamp_slave = 0;
      this->timestamp_master_in = 0;
      this->timestamp_bridge_in = 0ul;
      this->timestamp_ros_in = 0ul;
      this->master_to_master = 0;
      this->bridge_to_bridge = 0;
      this->ros_to_ros = 0;
    }
  }

  explicit ZfTestLoop_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sender = 0;
      this->timestamp_ros_out = 0ul;
      this->timestamp_bridge_out = 0ul;
      this->timestamp_master_out = 0;
      this->timestamp_slave = 0;
      this->timestamp_master_in = 0;
      this->timestamp_bridge_in = 0ul;
      this->timestamp_ros_in = 0ul;
      this->master_to_master = 0;
      this->bridge_to_bridge = 0;
      this->ros_to_ros = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _sender_type =
    uint16_t;
  _sender_type sender;
  using _timestamp_ros_out_type =
    uint32_t;
  _timestamp_ros_out_type timestamp_ros_out;
  using _timestamp_bridge_out_type =
    uint32_t;
  _timestamp_bridge_out_type timestamp_bridge_out;
  using _timestamp_master_out_type =
    uint16_t;
  _timestamp_master_out_type timestamp_master_out;
  using _timestamp_slave_type =
    uint16_t;
  _timestamp_slave_type timestamp_slave;
  using _timestamp_master_in_type =
    uint16_t;
  _timestamp_master_in_type timestamp_master_in;
  using _timestamp_bridge_in_type =
    uint32_t;
  _timestamp_bridge_in_type timestamp_bridge_in;
  using _timestamp_ros_in_type =
    uint32_t;
  _timestamp_ros_in_type timestamp_ros_in;
  using _master_to_master_type =
    uint16_t;
  _master_to_master_type master_to_master;
  using _bridge_to_bridge_type =
    uint16_t;
  _bridge_to_bridge_type bridge_to_bridge;
  using _ros_to_ros_type =
    uint16_t;
  _ros_to_ros_type ros_to_ros;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__sender(
    const uint16_t & _arg)
  {
    this->sender = _arg;
    return *this;
  }
  Type & set__timestamp_ros_out(
    const uint32_t & _arg)
  {
    this->timestamp_ros_out = _arg;
    return *this;
  }
  Type & set__timestamp_bridge_out(
    const uint32_t & _arg)
  {
    this->timestamp_bridge_out = _arg;
    return *this;
  }
  Type & set__timestamp_master_out(
    const uint16_t & _arg)
  {
    this->timestamp_master_out = _arg;
    return *this;
  }
  Type & set__timestamp_slave(
    const uint16_t & _arg)
  {
    this->timestamp_slave = _arg;
    return *this;
  }
  Type & set__timestamp_master_in(
    const uint16_t & _arg)
  {
    this->timestamp_master_in = _arg;
    return *this;
  }
  Type & set__timestamp_bridge_in(
    const uint32_t & _arg)
  {
    this->timestamp_bridge_in = _arg;
    return *this;
  }
  Type & set__timestamp_ros_in(
    const uint32_t & _arg)
  {
    this->timestamp_ros_in = _arg;
    return *this;
  }
  Type & set__master_to_master(
    const uint16_t & _arg)
  {
    this->master_to_master = _arg;
    return *this;
  }
  Type & set__bridge_to_bridge(
    const uint16_t & _arg)
  {
    this->bridge_to_bridge = _arg;
    return *this;
  }
  Type & set__ros_to_ros(
    const uint16_t & _arg)
  {
    this->ros_to_ros = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::ZfTestLoop_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::ZfTestLoop_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfTestLoop_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfTestLoop_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfTestLoop_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfTestLoop_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfTestLoop_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfTestLoop_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfTestLoop_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfTestLoop_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__ZfTestLoop
    std::shared_ptr<truck_msgs::msg::ZfTestLoop_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__ZfTestLoop
    std::shared_ptr<truck_msgs::msg::ZfTestLoop_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ZfTestLoop_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->sender != other.sender) {
      return false;
    }
    if (this->timestamp_ros_out != other.timestamp_ros_out) {
      return false;
    }
    if (this->timestamp_bridge_out != other.timestamp_bridge_out) {
      return false;
    }
    if (this->timestamp_master_out != other.timestamp_master_out) {
      return false;
    }
    if (this->timestamp_slave != other.timestamp_slave) {
      return false;
    }
    if (this->timestamp_master_in != other.timestamp_master_in) {
      return false;
    }
    if (this->timestamp_bridge_in != other.timestamp_bridge_in) {
      return false;
    }
    if (this->timestamp_ros_in != other.timestamp_ros_in) {
      return false;
    }
    if (this->master_to_master != other.master_to_master) {
      return false;
    }
    if (this->bridge_to_bridge != other.bridge_to_bridge) {
      return false;
    }
    if (this->ros_to_ros != other.ros_to_ros) {
      return false;
    }
    return true;
  }
  bool operator!=(const ZfTestLoop_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ZfTestLoop_

// alias to use template instance with default allocator
using ZfTestLoop =
  truck_msgs::msg::ZfTestLoop_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TEST_LOOP__STRUCT_HPP_
