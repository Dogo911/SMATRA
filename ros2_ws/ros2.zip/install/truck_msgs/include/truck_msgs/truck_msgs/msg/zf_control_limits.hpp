// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__ZF_CONTROL_LIMITS_HPP_
#define TRUCK_MSGS__MSG__ZF_CONTROL_LIMITS_HPP_

#include "truck_msgs/msg/detail/zf_control_limits__struct.hpp"
#include "truck_msgs/msg/detail/zf_control_limits__builder.hpp"
#include "truck_msgs/msg/detail/zf_control_limits__traits.hpp"
#include "truck_msgs/msg/detail/zf_control_limits__type_support.hpp"

#endif  // TRUCK_MSGS__MSG__ZF_CONTROL_LIMITS_HPP_
