﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfControlLimits.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_LIMITS__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_LIMITS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ZfControlLimits in the package truck_msgs.
/**
  * ZF InnoLab ROS message definition
  * zf_control_limits.msg
  *
  * Version 6.0
 */
typedef struct truck_msgs__msg__ZfControlLimits
{
  std_msgs__msg__Header header;
  /// kleinster erlaubter Lenkwinkel, minimal -50
  float steering_min;
  /// grösster erlaubter Lenkwinkel, maximal 50
  float steering_max;
  /// kleinste erlaubte Geschwindigkeit, minimal -1.000
  float speed_min;
  /// grösste erlaubte Geschwindigkeit, maximal 1.000
  float speed_max;
  /// kleinste erlaubte Beschleunigung, minimal 50 (?)
  float accel_min;
  /// grösste erlaubte Beschleunigung, maximal 500 (?)
  float accel_max;
} truck_msgs__msg__ZfControlLimits;

// Struct for a sequence of truck_msgs__msg__ZfControlLimits.
typedef struct truck_msgs__msg__ZfControlLimits__Sequence
{
  truck_msgs__msg__ZfControlLimits * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfControlLimits__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROL_LIMITS__STRUCT_H_
