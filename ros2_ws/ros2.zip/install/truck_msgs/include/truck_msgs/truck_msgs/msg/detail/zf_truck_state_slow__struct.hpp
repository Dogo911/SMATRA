// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/ZfTruckStateSlow.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE_SLOW__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE_SLOW__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__ZfTruckStateSlow __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__ZfTruckStateSlow __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ZfTruckStateSlow_
{
  using Type = ZfTruckStateSlow_<ContainerAllocator>;

  explicit ZfTruckStateSlow_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->u_12 = 0;
      this->u_5 = 0;
      this->i_total = 0;
      this->emerg_stop_auto_release = false;
    }
  }

  explicit ZfTruckStateSlow_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->u_12 = 0;
      this->u_5 = 0;
      this->i_total = 0;
      this->emerg_stop_auto_release = false;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _u_12_type =
    int16_t;
  _u_12_type u_12;
  using _u_5_type =
    int16_t;
  _u_5_type u_5;
  using _i_total_type =
    int16_t;
  _i_total_type i_total;
  using _emerg_stop_auto_release_type =
    bool;
  _emerg_stop_auto_release_type emerg_stop_auto_release;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__u_12(
    const int16_t & _arg)
  {
    this->u_12 = _arg;
    return *this;
  }
  Type & set__u_5(
    const int16_t & _arg)
  {
    this->u_5 = _arg;
    return *this;
  }
  Type & set__i_total(
    const int16_t & _arg)
  {
    this->i_total = _arg;
    return *this;
  }
  Type & set__emerg_stop_auto_release(
    const bool & _arg)
  {
    this->emerg_stop_auto_release = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__ZfTruckStateSlow
    std::shared_ptr<truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__ZfTruckStateSlow
    std::shared_ptr<truck_msgs::msg::ZfTruckStateSlow_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ZfTruckStateSlow_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->u_12 != other.u_12) {
      return false;
    }
    if (this->u_5 != other.u_5) {
      return false;
    }
    if (this->i_total != other.i_total) {
      return false;
    }
    if (this->emerg_stop_auto_release != other.emerg_stop_auto_release) {
      return false;
    }
    return true;
  }
  bool operator!=(const ZfTruckStateSlow_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ZfTruckStateSlow_

// alias to use template instance with default allocator
using ZfTruckStateSlow =
  truck_msgs::msg::ZfTruckStateSlow_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_STATE_SLOW__STRUCT_HPP_
