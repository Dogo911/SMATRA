// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/Debug.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__DEBUG__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__DEBUG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/debug__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_Debug_y_t
{
public:
  explicit Init_Debug_y_t(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::Debug y_t(::truck_msgs::msg::Debug::_y_t_type arg)
  {
    msg_.y_t = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_x_t
{
public:
  explicit Init_Debug_x_t(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_y_t x_t(::truck_msgs::msg::Debug::_x_t_type arg)
  {
    msg_.x_t = std::move(arg);
    return Init_Debug_y_t(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_yaw
{
public:
  explicit Init_Debug_yaw(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_x_t yaw(::truck_msgs::msg::Debug::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_Debug_x_t(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_y
{
public:
  explicit Init_Debug_y(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_yaw y(::truck_msgs::msg::Debug::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_Debug_yaw(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_x
{
public:
  explicit Init_Debug_x(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_y x(::truck_msgs::msg::Debug::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_Debug_y(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_delta_y
{
public:
  explicit Init_Debug_delta_y(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_x delta_y(::truck_msgs::msg::Debug::_delta_y_type arg)
  {
    msg_.delta_y = std::move(arg);
    return Init_Debug_x(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_delta_x
{
public:
  explicit Init_Debug_delta_x(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_delta_y delta_x(::truck_msgs::msg::Debug::_delta_x_type arg)
  {
    msg_.delta_x = std::move(arg);
    return Init_Debug_delta_y(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_dy
{
public:
  explicit Init_Debug_dy(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_delta_x dy(::truck_msgs::msg::Debug::_dy_type arg)
  {
    msg_.dy = std::move(arg);
    return Init_Debug_delta_x(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_dx
{
public:
  explicit Init_Debug_dx(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_dy dx(::truck_msgs::msg::Debug::_dx_type arg)
  {
    msg_.dx = std::move(arg);
    return Init_Debug_dy(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_wheelbase
{
public:
  explicit Init_Debug_wheelbase(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_dx wheelbase(::truck_msgs::msg::Debug::_wheelbase_type arg)
  {
    msg_.wheelbase = std::move(arg);
    return Init_Debug_dx(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_steering_angle
{
public:
  explicit Init_Debug_steering_angle(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_wheelbase steering_angle(::truck_msgs::msg::Debug::_steering_angle_type arg)
  {
    msg_.steering_angle = std::move(arg);
    return Init_Debug_wheelbase(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_dyaw
{
public:
  explicit Init_Debug_dyaw(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_steering_angle dyaw(::truck_msgs::msg::Debug::_dyaw_type arg)
  {
    msg_.dyaw = std::move(arg);
    return Init_Debug_steering_angle(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_wheel_diff_steer
{
public:
  explicit Init_Debug_wheel_diff_steer(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_dyaw wheel_diff_steer(::truck_msgs::msg::Debug::_wheel_diff_steer_type arg)
  {
    msg_.wheel_diff_steer = std::move(arg);
    return Init_Debug_dyaw(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_steering_diff
{
public:
  explicit Init_Debug_steering_diff(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_wheel_diff_steer steering_diff(::truck_msgs::msg::Debug::_steering_diff_type arg)
  {
    msg_.steering_diff = std::move(arg);
    return Init_Debug_wheel_diff_steer(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_wheel_diff_lr
{
public:
  explicit Init_Debug_wheel_diff_lr(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_steering_diff wheel_diff_lr(::truck_msgs::msg::Debug::_wheel_diff_lr_type arg)
  {
    msg_.wheel_diff_lr = std::move(arg);
    return Init_Debug_steering_diff(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_wheel_diff_back
{
public:
  explicit Init_Debug_wheel_diff_back(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_wheel_diff_lr wheel_diff_back(::truck_msgs::msg::Debug::_wheel_diff_back_type arg)
  {
    msg_.wheel_diff_back = std::move(arg);
    return Init_Debug_wheel_diff_lr(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_wheel_diff_right
{
public:
  explicit Init_Debug_wheel_diff_right(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_wheel_diff_back wheel_diff_right(::truck_msgs::msg::Debug::_wheel_diff_right_type arg)
  {
    msg_.wheel_diff_right = std::move(arg);
    return Init_Debug_wheel_diff_back(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_wheel_diff_left
{
public:
  explicit Init_Debug_wheel_diff_left(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_wheel_diff_right wheel_diff_left(::truck_msgs::msg::Debug::_wheel_diff_left_type arg)
  {
    msg_.wheel_diff_left = std::move(arg);
    return Init_Debug_wheel_diff_right(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_enc_diff_lr
{
public:
  explicit Init_Debug_enc_diff_lr(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_wheel_diff_left enc_diff_lr(::truck_msgs::msg::Debug::_enc_diff_lr_type arg)
  {
    msg_.enc_diff_lr = std::move(arg);
    return Init_Debug_wheel_diff_left(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_enc_diff_back
{
public:
  explicit Init_Debug_enc_diff_back(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_enc_diff_lr enc_diff_back(::truck_msgs::msg::Debug::_enc_diff_back_type arg)
  {
    msg_.enc_diff_back = std::move(arg);
    return Init_Debug_enc_diff_lr(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_enc_diff_right
{
public:
  explicit Init_Debug_enc_diff_right(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_enc_diff_back enc_diff_right(::truck_msgs::msg::Debug::_enc_diff_right_type arg)
  {
    msg_.enc_diff_right = std::move(arg);
    return Init_Debug_enc_diff_back(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_enc_diff_left
{
public:
  explicit Init_Debug_enc_diff_left(::truck_msgs::msg::Debug & msg)
  : msg_(msg)
  {}
  Init_Debug_enc_diff_right enc_diff_left(::truck_msgs::msg::Debug::_enc_diff_left_type arg)
  {
    msg_.enc_diff_left = std::move(arg);
    return Init_Debug_enc_diff_right(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

class Init_Debug_header
{
public:
  Init_Debug_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Debug_enc_diff_left header(::truck_msgs::msg::Debug::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Debug_enc_diff_left(msg_);
  }

private:
  ::truck_msgs::msg::Debug msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::Debug>()
{
  return truck_msgs::msg::builder::Init_Debug_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__DEBUG__BUILDER_HPP_
