// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfControllerParams.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_controller_params__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfControllerParams_speed_c
{
public:
  explicit Init_ZfControllerParams_speed_c(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfControllerParams speed_c(::truck_msgs::msg::ZfControllerParams::_speed_c_type arg)
  {
    msg_.speed_c = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_speed_b
{
public:
  explicit Init_ZfControllerParams_speed_b(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_speed_c speed_b(::truck_msgs::msg::ZfControllerParams::_speed_b_type arg)
  {
    msg_.speed_b = std::move(arg);
    return Init_ZfControllerParams_speed_c(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_speed_a
{
public:
  explicit Init_ZfControllerParams_speed_a(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_speed_b speed_a(::truck_msgs::msg::ZfControllerParams::_speed_a_type arg)
  {
    msg_.speed_a = std::move(arg);
    return Init_ZfControllerParams_speed_b(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_steer_c
{
public:
  explicit Init_ZfControllerParams_steer_c(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_speed_a steer_c(::truck_msgs::msg::ZfControllerParams::_steer_c_type arg)
  {
    msg_.steer_c = std::move(arg);
    return Init_ZfControllerParams_speed_a(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_steer_b
{
public:
  explicit Init_ZfControllerParams_steer_b(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_steer_c steer_b(::truck_msgs::msg::ZfControllerParams::_steer_b_type arg)
  {
    msg_.steer_b = std::move(arg);
    return Init_ZfControllerParams_steer_c(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_steer_a
{
public:
  explicit Init_ZfControllerParams_steer_a(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_steer_b steer_a(::truck_msgs::msg::ZfControllerParams::_steer_a_type arg)
  {
    msg_.steer_a = std::move(arg);
    return Init_ZfControllerParams_steer_b(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_speed_d
{
public:
  explicit Init_ZfControllerParams_speed_d(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_steer_a speed_d(::truck_msgs::msg::ZfControllerParams::_speed_d_type arg)
  {
    msg_.speed_d = std::move(arg);
    return Init_ZfControllerParams_steer_a(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_speed_i
{
public:
  explicit Init_ZfControllerParams_speed_i(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_speed_d speed_i(::truck_msgs::msg::ZfControllerParams::_speed_i_type arg)
  {
    msg_.speed_i = std::move(arg);
    return Init_ZfControllerParams_speed_d(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_speed_p
{
public:
  explicit Init_ZfControllerParams_speed_p(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_speed_i speed_p(::truck_msgs::msg::ZfControllerParams::_speed_p_type arg)
  {
    msg_.speed_p = std::move(arg);
    return Init_ZfControllerParams_speed_i(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_steer_d
{
public:
  explicit Init_ZfControllerParams_steer_d(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_speed_p steer_d(::truck_msgs::msg::ZfControllerParams::_steer_d_type arg)
  {
    msg_.steer_d = std::move(arg);
    return Init_ZfControllerParams_speed_p(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_steer_i
{
public:
  explicit Init_ZfControllerParams_steer_i(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_steer_d steer_i(::truck_msgs::msg::ZfControllerParams::_steer_i_type arg)
  {
    msg_.steer_i = std::move(arg);
    return Init_ZfControllerParams_steer_d(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_steer_p
{
public:
  explicit Init_ZfControllerParams_steer_p(::truck_msgs::msg::ZfControllerParams & msg)
  : msg_(msg)
  {}
  Init_ZfControllerParams_steer_i steer_p(::truck_msgs::msg::ZfControllerParams::_steer_p_type arg)
  {
    msg_.steer_p = std::move(arg);
    return Init_ZfControllerParams_steer_i(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

class Init_ZfControllerParams_header
{
public:
  Init_ZfControllerParams_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfControllerParams_steer_p header(::truck_msgs::msg::ZfControllerParams::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfControllerParams_steer_p(msg_);
  }

private:
  ::truck_msgs::msg::ZfControllerParams msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfControllerParams>()
{
  return truck_msgs::msg::builder::Init_ZfControllerParams_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__BUILDER_HPP_
