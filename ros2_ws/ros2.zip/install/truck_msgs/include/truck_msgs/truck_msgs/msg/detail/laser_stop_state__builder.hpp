// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/LaserStopState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/laser_stop_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_LaserStopState_accel_max
{
public:
  explicit Init_LaserStopState_accel_max(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::LaserStopState accel_max(::truck_msgs::msg::LaserStopState::_accel_max_type arg)
  {
    msg_.accel_max = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_accel_min
{
public:
  explicit Init_LaserStopState_accel_min(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_accel_max accel_min(::truck_msgs::msg::LaserStopState::_accel_min_type arg)
  {
    msg_.accel_min = std::move(arg);
    return Init_LaserStopState_accel_max(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_speed_max
{
public:
  explicit Init_LaserStopState_speed_max(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_accel_min speed_max(::truck_msgs::msg::LaserStopState::_speed_max_type arg)
  {
    msg_.speed_max = std::move(arg);
    return Init_LaserStopState_accel_min(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_speed_min
{
public:
  explicit Init_LaserStopState_speed_min(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_speed_max speed_min(::truck_msgs::msg::LaserStopState::_speed_min_type arg)
  {
    msg_.speed_min = std::move(arg);
    return Init_LaserStopState_speed_max(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_steering_max
{
public:
  explicit Init_LaserStopState_steering_max(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_speed_min steering_max(::truck_msgs::msg::LaserStopState::_steering_max_type arg)
  {
    msg_.steering_max = std::move(arg);
    return Init_LaserStopState_speed_min(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_steering_min
{
public:
  explicit Init_LaserStopState_steering_min(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_steering_max steering_min(::truck_msgs::msg::LaserStopState::_steering_min_type arg)
  {
    msg_.steering_min = std::move(arg);
    return Init_LaserStopState_steering_max(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_v_target
{
public:
  explicit Init_LaserStopState_v_target(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_steering_min v_target(::truck_msgs::msg::LaserStopState::_v_target_type arg)
  {
    msg_.v_target = std::move(arg);
    return Init_LaserStopState_steering_min(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_ttc
{
public:
  explicit Init_LaserStopState_ttc(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_v_target ttc(::truck_msgs::msg::LaserStopState::_ttc_type arg)
  {
    msg_.ttc = std::move(arg);
    return Init_LaserStopState_v_target(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_min_dist
{
public:
  explicit Init_LaserStopState_min_dist(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_ttc min_dist(::truck_msgs::msg::LaserStopState::_min_dist_type arg)
  {
    msg_.min_dist = std::move(arg);
    return Init_LaserStopState_ttc(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_tp
{
public:
  explicit Init_LaserStopState_tp(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_min_dist tp(::truck_msgs::msg::LaserStopState::_tp_type arg)
  {
    msg_.tp = std::move(arg);
    return Init_LaserStopState_min_dist(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_cycle
{
public:
  explicit Init_LaserStopState_cycle(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_tp cycle(::truck_msgs::msg::LaserStopState::_cycle_type arg)
  {
    msg_.cycle = std::move(arg);
    return Init_LaserStopState_tp(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_rviz_marker
{
public:
  explicit Init_LaserStopState_rviz_marker(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_cycle rviz_marker(::truck_msgs::msg::LaserStopState::_rviz_marker_type arg)
  {
    msg_.rviz_marker = std::move(arg);
    return Init_LaserStopState_cycle(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_control_active
{
public:
  explicit Init_LaserStopState_control_active(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_rviz_marker control_active(::truck_msgs::msg::LaserStopState::_control_active_type arg)
  {
    msg_.control_active = std::move(arg);
    return Init_LaserStopState_rviz_marker(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_sensor_active
{
public:
  explicit Init_LaserStopState_sensor_active(::truck_msgs::msg::LaserStopState & msg)
  : msg_(msg)
  {}
  Init_LaserStopState_control_active sensor_active(::truck_msgs::msg::LaserStopState::_sensor_active_type arg)
  {
    msg_.sensor_active = std::move(arg);
    return Init_LaserStopState_control_active(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

class Init_LaserStopState_header
{
public:
  Init_LaserStopState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LaserStopState_sensor_active header(::truck_msgs::msg::LaserStopState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_LaserStopState_sensor_active(msg_);
  }

private:
  ::truck_msgs::msg::LaserStopState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::LaserStopState>()
{
  return truck_msgs::msg::builder::Init_LaserStopState_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__LASER_STOP_STATE__BUILDER_HPP_
