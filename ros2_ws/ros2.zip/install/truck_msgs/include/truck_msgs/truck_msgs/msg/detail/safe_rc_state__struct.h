﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/SafeRcState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/SafeRcState in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * safe_rc_state.msg
  *
  * Version 6.0
 */
typedef struct truck_msgs__msg__SafeRcState
{
  std_msgs__msg__Header header;
  /// aus Service set_safe_rc_control:
  /// 0=nein, 1=ja
  int16_t sensor_active;
  /// 0=nein, 1=ja
  int16_t control_active;
  /// 0=nein, 1=ja
  int16_t rviz_lines;
  /// für System-Monitor:
  int64_t cycle;
  ///  Output Sensor:
  /// define SCENARIO_NULL   0 //nichts/unklar
  /// define SCENARIO_WALL   1 //Wand
  /// define SCENARIO_EDGE   2 //Kante
  /// define SCENARIO_CORNER 3 //Ecke
  ///  0...3
  int16_t scenario;
  int16_t scenario_lower;
  int16_t scenario_upper;
  int16_t left_wall;
  int16_t middle_wall;
  int16_t right_wall;
  int16_t lower_corner;
  int16_t upper_corner;
  /// kleinster erlaubter Lenkwinkel, minimal -50
  float steering_min;
  /// grösster erlaubter Lenkwinkel, maximal 50
  float steering_max;
  /// kleinste erlaubte Geschwindigkeit, minimal 0
  float speed_min;
  /// grösste erlaubte Geschwindigkeit, maximal 1.000
  float speed_max;
  /// kleinste erlaubte Beschleunigung, minimal 50 (?)
  float accel_min;
  /// grösste erlaubte Beschleunigung, maximal 500 (?)
  float accel_max;
} truck_msgs__msg__SafeRcState;

// Struct for a sequence of truck_msgs__msg__SafeRcState.
typedef struct truck_msgs__msg__SafeRcState__Sequence
{
  truck_msgs__msg__SafeRcState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__SafeRcState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__SAFE_RC_STATE__STRUCT_H_
