// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/ZfSensorConfigOne.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/zf_sensor_config_one__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ZfSensorConfigOne & msg,
  std::ostream & out)
{
  out << "{";
  // member: id
  {
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << ", ";
  }

  // member: sensor_active
  {
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << ", ";
  }

  // member: stop_active
  {
    out << "stop_active: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_active, out);
    out << ", ";
  }

  // member: stop_dist
  {
    out << "stop_dist: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_dist, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ZfSensorConfigOne & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << "\n";
  }

  // member: sensor_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << "\n";
  }

  // member: stop_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stop_active: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_active, out);
    out << "\n";
  }

  // member: stop_dist
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stop_dist: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_dist, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ZfSensorConfigOne & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::ZfSensorConfigOne & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::ZfSensorConfigOne & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::ZfSensorConfigOne>()
{
  return "truck_msgs::msg::ZfSensorConfigOne";
}

template<>
inline const char * name<truck_msgs::msg::ZfSensorConfigOne>()
{
  return "truck_msgs/msg/ZfSensorConfigOne";
}

template<>
struct has_fixed_size<truck_msgs::msg::ZfSensorConfigOne>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<truck_msgs::msg::ZfSensorConfigOne>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<truck_msgs::msg::ZfSensorConfigOne>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_SENSOR_CONFIG_ONE__TRAITS_HPP_
