// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/BeaconState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/beacon_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_BeaconState_delta_target
{
public:
  explicit Init_BeaconState_delta_target(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::BeaconState delta_target(::truck_msgs::msg::BeaconState::_delta_target_type arg)
  {
    msg_.delta_target = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_alpha
{
public:
  explicit Init_BeaconState_alpha(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_delta_target alpha(::truck_msgs::msg::BeaconState::_alpha_type arg)
  {
    msg_.alpha = std::move(arg);
    return Init_BeaconState_delta_target(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_status
{
public:
  explicit Init_BeaconState_status(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_alpha status(::truck_msgs::msg::BeaconState::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_BeaconState_alpha(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_status_b2
{
public:
  explicit Init_BeaconState_status_b2(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_status status_b2(::truck_msgs::msg::BeaconState::_status_b2_type arg)
  {
    msg_.status_b2 = std::move(arg);
    return Init_BeaconState_status(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_status_b1
{
public:
  explicit Init_BeaconState_status_b1(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_status_b2 status_b1(::truck_msgs::msg::BeaconState::_status_b1_type arg)
  {
    msg_.status_b1 = std::move(arg);
    return Init_BeaconState_status_b2(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_cnt_mid
{
public:
  explicit Init_BeaconState_cnt_mid(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_status_b1 cnt_mid(::truck_msgs::msg::BeaconState::_cnt_mid_type arg)
  {
    msg_.cnt_mid = std::move(arg);
    return Init_BeaconState_status_b1(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_cnt_b2
{
public:
  explicit Init_BeaconState_cnt_b2(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_cnt_mid cnt_b2(::truck_msgs::msg::BeaconState::_cnt_b2_type arg)
  {
    msg_.cnt_b2 = std::move(arg);
    return Init_BeaconState_cnt_mid(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_cnt_b1
{
public:
  explicit Init_BeaconState_cnt_b1(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_cnt_b2 cnt_b1(::truck_msgs::msg::BeaconState::_cnt_b1_type arg)
  {
    msg_.cnt_b1 = std::move(arg);
    return Init_BeaconState_cnt_b2(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_used_n
{
public:
  explicit Init_BeaconState_used_n(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_cnt_b1 used_n(::truck_msgs::msg::BeaconState::_used_n_type arg)
  {
    msg_.used_n = std::move(arg);
    return Init_BeaconState_cnt_b1(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_data_n
{
public:
  explicit Init_BeaconState_data_n(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_used_n data_n(::truck_msgs::msg::BeaconState::_data_n_type arg)
  {
    msg_.data_n = std::move(arg);
    return Init_BeaconState_used_n(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_p_center
{
public:
  explicit Init_BeaconState_p_center(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_data_n p_center(::truck_msgs::msg::BeaconState::_p_center_type arg)
  {
    msg_.p_center = std::move(arg);
    return Init_BeaconState_data_n(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_p2
{
public:
  explicit Init_BeaconState_p2(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_p_center p2(::truck_msgs::msg::BeaconState::_p2_type arg)
  {
    msg_.p2 = std::move(arg);
    return Init_BeaconState_p_center(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_p1
{
public:
  explicit Init_BeaconState_p1(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_p2 p1(::truck_msgs::msg::BeaconState::_p1_type arg)
  {
    msg_.p1 = std::move(arg);
    return Init_BeaconState_p2(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_rviz_marker
{
public:
  explicit Init_BeaconState_rviz_marker(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_p1 rviz_marker(::truck_msgs::msg::BeaconState::_rviz_marker_type arg)
  {
    msg_.rviz_marker = std::move(arg);
    return Init_BeaconState_p1(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_control_active
{
public:
  explicit Init_BeaconState_control_active(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_rviz_marker control_active(::truck_msgs::msg::BeaconState::_control_active_type arg)
  {
    msg_.control_active = std::move(arg);
    return Init_BeaconState_rviz_marker(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_sensor_active
{
public:
  explicit Init_BeaconState_sensor_active(::truck_msgs::msg::BeaconState & msg)
  : msg_(msg)
  {}
  Init_BeaconState_control_active sensor_active(::truck_msgs::msg::BeaconState::_sensor_active_type arg)
  {
    msg_.sensor_active = std::move(arg);
    return Init_BeaconState_control_active(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

class Init_BeaconState_header
{
public:
  Init_BeaconState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BeaconState_sensor_active header(::truck_msgs::msg::BeaconState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_BeaconState_sensor_active(msg_);
  }

private:
  ::truck_msgs::msg::BeaconState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::BeaconState>()
{
  return truck_msgs::msg::builder::Init_BeaconState_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__BEACON_STATE__BUILDER_HPP_
