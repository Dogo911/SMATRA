// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from truck_msgs:msg/CollisionState.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__TRAITS_HPP_
#define TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "truck_msgs/msg/detail/collision_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'p1'
// Member 'p2'
#include "geometry_msgs/msg/detail/point__traits.hpp"

namespace truck_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const CollisionState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: stop_active
  {
    out << "stop_active: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_active, out);
    out << ", ";
  }

  // member: stop_distance
  {
    out << "stop_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_distance, out);
    out << ", ";
  }

  // member: sensor_active
  {
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << ", ";
  }

  // member: control_active
  {
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << ", ";
  }

  // member: target_distance
  {
    out << "target_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.target_distance, out);
    out << ", ";
  }

  // member: max_distance
  {
    out << "max_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.max_distance, out);
    out << ", ";
  }

  // member: p1
  {
    out << "p1: ";
    to_flow_style_yaml(msg.p1, out);
    out << ", ";
  }

  // member: p2
  {
    out << "p2: ";
    to_flow_style_yaml(msg.p2, out);
    out << ", ";
  }

  // member: width
  {
    out << "width: ";
    rosidl_generator_traits::value_to_yaml(msg.width, out);
    out << ", ";
  }

  // member: dist_x
  {
    out << "dist_x: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_x, out);
    out << ", ";
  }

  // member: offset
  {
    out << "offset: ";
    rosidl_generator_traits::value_to_yaml(msg.offset, out);
    out << ", ";
  }

  // member: dist
  {
    out << "dist: ";
    rosidl_generator_traits::value_to_yaml(msg.dist, out);
    out << ", ";
  }

  // member: alpha
  {
    out << "alpha: ";
    rosidl_generator_traits::value_to_yaml(msg.alpha, out);
    out << ", ";
  }

  // member: beta
  {
    out << "beta: ";
    rosidl_generator_traits::value_to_yaml(msg.beta, out);
    out << ", ";
  }

  // member: delta_target
  {
    out << "delta_target: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_target, out);
    out << ", ";
  }

  // member: v_target
  {
    out << "v_target: ";
    rosidl_generator_traits::value_to_yaml(msg.v_target, out);
    out << ", ";
  }

  // member: width_status
  {
    out << "width_status: ";
    rosidl_generator_traits::value_to_yaml(msg.width_status, out);
    out << ", ";
  }

  // member: dist_status
  {
    out << "dist_status: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_status, out);
    out << ", ";
  }

  // member: status
  {
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CollisionState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: stop_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stop_active: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_active, out);
    out << "\n";
  }

  // member: stop_distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stop_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_distance, out);
    out << "\n";
  }

  // member: sensor_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_active: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_active, out);
    out << "\n";
  }

  // member: control_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_active: ";
    rosidl_generator_traits::value_to_yaml(msg.control_active, out);
    out << "\n";
  }

  // member: target_distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.target_distance, out);
    out << "\n";
  }

  // member: max_distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "max_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.max_distance, out);
    out << "\n";
  }

  // member: p1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p1:\n";
    to_block_style_yaml(msg.p1, out, indentation + 2);
  }

  // member: p2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p2:\n";
    to_block_style_yaml(msg.p2, out, indentation + 2);
  }

  // member: width
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "width: ";
    rosidl_generator_traits::value_to_yaml(msg.width, out);
    out << "\n";
  }

  // member: dist_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dist_x: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_x, out);
    out << "\n";
  }

  // member: offset
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "offset: ";
    rosidl_generator_traits::value_to_yaml(msg.offset, out);
    out << "\n";
  }

  // member: dist
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dist: ";
    rosidl_generator_traits::value_to_yaml(msg.dist, out);
    out << "\n";
  }

  // member: alpha
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alpha: ";
    rosidl_generator_traits::value_to_yaml(msg.alpha, out);
    out << "\n";
  }

  // member: beta
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "beta: ";
    rosidl_generator_traits::value_to_yaml(msg.beta, out);
    out << "\n";
  }

  // member: delta_target
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "delta_target: ";
    rosidl_generator_traits::value_to_yaml(msg.delta_target, out);
    out << "\n";
  }

  // member: v_target
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "v_target: ";
    rosidl_generator_traits::value_to_yaml(msg.v_target, out);
    out << "\n";
  }

  // member: width_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "width_status: ";
    rosidl_generator_traits::value_to_yaml(msg.width_status, out);
    out << "\n";
  }

  // member: dist_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dist_status: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_status, out);
    out << "\n";
  }

  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CollisionState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace truck_msgs

namespace rosidl_generator_traits
{

[[deprecated("use truck_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const truck_msgs::msg::CollisionState & msg,
  std::ostream & out, size_t indentation = 0)
{
  truck_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use truck_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const truck_msgs::msg::CollisionState & msg)
{
  return truck_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<truck_msgs::msg::CollisionState>()
{
  return "truck_msgs::msg::CollisionState";
}

template<>
inline const char * name<truck_msgs::msg::CollisionState>()
{
  return "truck_msgs/msg/CollisionState";
}

template<>
struct has_fixed_size<truck_msgs::msg::CollisionState>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::Point>::value && has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<truck_msgs::msg::CollisionState>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::Point>::value && has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<truck_msgs::msg::CollisionState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TRUCK_MSGS__MSG__DETAIL__COLLISION_STATE__TRAITS_HPP_
