// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfTruckConfig.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_CONFIG__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_CONFIG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'controller_params'
#include "truck_msgs/msg/detail/zf_controller_params__struct.h"
// Member 'sensor_config'
#include "truck_msgs/msg/detail/zf_sensor_config__struct.h"

/// Struct defined in msg/ZfTruckConfig in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
  * zf_truck_config.msg
  *
  * Version 6.0
 */
typedef struct truck_msgs__msg__ZfTruckConfig
{
  std_msgs__msg__Header header;
  truck_msgs__msg__ZfControllerParams controller_params;
  truck_msgs__msg__ZfSensorConfig sensor_config;
} truck_msgs__msg__ZfTruckConfig;

// Struct for a sequence of truck_msgs__msg__ZfTruckConfig.
typedef struct truck_msgs__msg__ZfTruckConfig__Sequence
{
  truck_msgs__msg__ZfTruckConfig * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfTruckConfig__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_CONFIG__STRUCT_H_
