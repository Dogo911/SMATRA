// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from truck_msgs:msg/ZfEncoder.idl
// generated code does not contain a copyright notice
#include "truck_msgs/msg/detail/zf_encoder__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
truck_msgs__msg__ZfEncoder__init(truck_msgs__msg__ZfEncoder * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    truck_msgs__msg__ZfEncoder__fini(msg);
    return false;
  }
  // left
  // right
  // back
  // steering
  // trailer
  // timestamp_slave
  // timestamp_master
  // timestamp_bridge
  return true;
}

void
truck_msgs__msg__ZfEncoder__fini(truck_msgs__msg__ZfEncoder * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // left
  // right
  // back
  // steering
  // trailer
  // timestamp_slave
  // timestamp_master
  // timestamp_bridge
}

bool
truck_msgs__msg__ZfEncoder__are_equal(const truck_msgs__msg__ZfEncoder * lhs, const truck_msgs__msg__ZfEncoder * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // left
  if (lhs->left != rhs->left) {
    return false;
  }
  // right
  if (lhs->right != rhs->right) {
    return false;
  }
  // back
  if (lhs->back != rhs->back) {
    return false;
  }
  // steering
  if (lhs->steering != rhs->steering) {
    return false;
  }
  // trailer
  if (lhs->trailer != rhs->trailer) {
    return false;
  }
  // timestamp_slave
  if (lhs->timestamp_slave != rhs->timestamp_slave) {
    return false;
  }
  // timestamp_master
  if (lhs->timestamp_master != rhs->timestamp_master) {
    return false;
  }
  // timestamp_bridge
  if (lhs->timestamp_bridge != rhs->timestamp_bridge) {
    return false;
  }
  return true;
}

bool
truck_msgs__msg__ZfEncoder__copy(
  const truck_msgs__msg__ZfEncoder * input,
  truck_msgs__msg__ZfEncoder * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // left
  output->left = input->left;
  // right
  output->right = input->right;
  // back
  output->back = input->back;
  // steering
  output->steering = input->steering;
  // trailer
  output->trailer = input->trailer;
  // timestamp_slave
  output->timestamp_slave = input->timestamp_slave;
  // timestamp_master
  output->timestamp_master = input->timestamp_master;
  // timestamp_bridge
  output->timestamp_bridge = input->timestamp_bridge;
  return true;
}

truck_msgs__msg__ZfEncoder *
truck_msgs__msg__ZfEncoder__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfEncoder * msg = (truck_msgs__msg__ZfEncoder *)allocator.allocate(sizeof(truck_msgs__msg__ZfEncoder), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(truck_msgs__msg__ZfEncoder));
  bool success = truck_msgs__msg__ZfEncoder__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
truck_msgs__msg__ZfEncoder__destroy(truck_msgs__msg__ZfEncoder * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    truck_msgs__msg__ZfEncoder__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
truck_msgs__msg__ZfEncoder__Sequence__init(truck_msgs__msg__ZfEncoder__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfEncoder * data = NULL;

  if (size) {
    data = (truck_msgs__msg__ZfEncoder *)allocator.zero_allocate(size, sizeof(truck_msgs__msg__ZfEncoder), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = truck_msgs__msg__ZfEncoder__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        truck_msgs__msg__ZfEncoder__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
truck_msgs__msg__ZfEncoder__Sequence__fini(truck_msgs__msg__ZfEncoder__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      truck_msgs__msg__ZfEncoder__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

truck_msgs__msg__ZfEncoder__Sequence *
truck_msgs__msg__ZfEncoder__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  truck_msgs__msg__ZfEncoder__Sequence * array = (truck_msgs__msg__ZfEncoder__Sequence *)allocator.allocate(sizeof(truck_msgs__msg__ZfEncoder__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = truck_msgs__msg__ZfEncoder__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
truck_msgs__msg__ZfEncoder__Sequence__destroy(truck_msgs__msg__ZfEncoder__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    truck_msgs__msg__ZfEncoder__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
truck_msgs__msg__ZfEncoder__Sequence__are_equal(const truck_msgs__msg__ZfEncoder__Sequence * lhs, const truck_msgs__msg__ZfEncoder__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!truck_msgs__msg__ZfEncoder__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
truck_msgs__msg__ZfEncoder__Sequence__copy(
  const truck_msgs__msg__ZfEncoder__Sequence * input,
  truck_msgs__msg__ZfEncoder__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(truck_msgs__msg__ZfEncoder);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    truck_msgs__msg__ZfEncoder * data =
      (truck_msgs__msg__ZfEncoder *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!truck_msgs__msg__ZfEncoder__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          truck_msgs__msg__ZfEncoder__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!truck_msgs__msg__ZfEncoder__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
