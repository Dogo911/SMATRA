// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from truck_msgs:msg/ZfTruckInit.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_INIT__STRUCT_H_
#define TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_INIT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/ZfTruckInit in the package truck_msgs.
/**
  * ZF DHBW InnoLab ROS message definition
 */
typedef struct truck_msgs__msg__ZfTruckInit
{
  /// Header  header
  /// time  t  # aktuelle Zeit
  ///  Start x-Position [m}
  float x;
  /// Start y-Position
  float y;
  /// Start Gierwinkel
  float psi;
} truck_msgs__msg__ZfTruckInit;

// Struct for a sequence of truck_msgs__msg__ZfTruckInit.
typedef struct truck_msgs__msg__ZfTruckInit__Sequence
{
  truck_msgs__msg__ZfTruckInit * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} truck_msgs__msg__ZfTruckInit__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_TRUCK_INIT__STRUCT_H_
