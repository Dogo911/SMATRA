// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/ZfImu.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_IMU__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_IMU__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/zf_imu__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_ZfImu_yaw
{
public:
  explicit Init_ZfImu_yaw(::truck_msgs::msg::ZfImu & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::ZfImu yaw(::truck_msgs::msg::ZfImu::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::ZfImu msg_;
};

class Init_ZfImu_pitch
{
public:
  explicit Init_ZfImu_pitch(::truck_msgs::msg::ZfImu & msg)
  : msg_(msg)
  {}
  Init_ZfImu_yaw pitch(::truck_msgs::msg::ZfImu::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_ZfImu_yaw(msg_);
  }

private:
  ::truck_msgs::msg::ZfImu msg_;
};

class Init_ZfImu_roll
{
public:
  explicit Init_ZfImu_roll(::truck_msgs::msg::ZfImu & msg)
  : msg_(msg)
  {}
  Init_ZfImu_pitch roll(::truck_msgs::msg::ZfImu::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_ZfImu_pitch(msg_);
  }

private:
  ::truck_msgs::msg::ZfImu msg_;
};

class Init_ZfImu_header
{
public:
  Init_ZfImu_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ZfImu_roll header(::truck_msgs::msg::ZfImu::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ZfImu_roll(msg_);
  }

private:
  ::truck_msgs::msg::ZfImu msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::ZfImu>()
{
  return truck_msgs::msg::builder::Init_ZfImu_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_IMU__BUILDER_HPP_
