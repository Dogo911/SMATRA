// generated from rosidl_generator_c/resource/idl.h.em
// with input from truck_msgs:msg/ZfControllerParams.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__ZF_CONTROLLER_PARAMS_H_
#define TRUCK_MSGS__MSG__ZF_CONTROLLER_PARAMS_H_

#include "truck_msgs/msg/detail/zf_controller_params__struct.h"
#include "truck_msgs/msg/detail/zf_controller_params__functions.h"
#include "truck_msgs/msg/detail/zf_controller_params__type_support.h"

#endif  // TRUCK_MSGS__MSG__ZF_CONTROLLER_PARAMS_H_
