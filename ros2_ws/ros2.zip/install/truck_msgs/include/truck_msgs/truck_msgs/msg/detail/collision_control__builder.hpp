// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from truck_msgs:msg/CollisionControl.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__COLLISION_CONTROL__BUILDER_HPP_
#define TRUCK_MSGS__MSG__DETAIL__COLLISION_CONTROL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "truck_msgs/msg/detail/collision_control__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace truck_msgs
{

namespace msg
{

namespace builder
{

class Init_CollisionControl_max_distance
{
public:
  explicit Init_CollisionControl_max_distance(::truck_msgs::msg::CollisionControl & msg)
  : msg_(msg)
  {}
  ::truck_msgs::msg::CollisionControl max_distance(::truck_msgs::msg::CollisionControl::_max_distance_type arg)
  {
    msg_.max_distance = std::move(arg);
    return std::move(msg_);
  }

private:
  ::truck_msgs::msg::CollisionControl msg_;
};

class Init_CollisionControl_target_distance
{
public:
  explicit Init_CollisionControl_target_distance(::truck_msgs::msg::CollisionControl & msg)
  : msg_(msg)
  {}
  Init_CollisionControl_max_distance target_distance(::truck_msgs::msg::CollisionControl::_target_distance_type arg)
  {
    msg_.target_distance = std::move(arg);
    return Init_CollisionControl_max_distance(msg_);
  }

private:
  ::truck_msgs::msg::CollisionControl msg_;
};

class Init_CollisionControl_control_active
{
public:
  explicit Init_CollisionControl_control_active(::truck_msgs::msg::CollisionControl & msg)
  : msg_(msg)
  {}
  Init_CollisionControl_target_distance control_active(::truck_msgs::msg::CollisionControl::_control_active_type arg)
  {
    msg_.control_active = std::move(arg);
    return Init_CollisionControl_target_distance(msg_);
  }

private:
  ::truck_msgs::msg::CollisionControl msg_;
};

class Init_CollisionControl_sensor_active
{
public:
  explicit Init_CollisionControl_sensor_active(::truck_msgs::msg::CollisionControl & msg)
  : msg_(msg)
  {}
  Init_CollisionControl_control_active sensor_active(::truck_msgs::msg::CollisionControl::_sensor_active_type arg)
  {
    msg_.sensor_active = std::move(arg);
    return Init_CollisionControl_control_active(msg_);
  }

private:
  ::truck_msgs::msg::CollisionControl msg_;
};

class Init_CollisionControl_header
{
public:
  Init_CollisionControl_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CollisionControl_sensor_active header(::truck_msgs::msg::CollisionControl::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_CollisionControl_sensor_active(msg_);
  }

private:
  ::truck_msgs::msg::CollisionControl msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::truck_msgs::msg::CollisionControl>()
{
  return truck_msgs::msg::builder::Init_CollisionControl_header();
}

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__COLLISION_CONTROL__BUILDER_HPP_
