// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from truck_msgs:msg/ZfControllerParams.idl
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__STRUCT_HPP_
#define TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__truck_msgs__msg__ZfControllerParams __attribute__((deprecated))
#else
# define DEPRECATED__truck_msgs__msg__ZfControllerParams __declspec(deprecated)
#endif

namespace truck_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ZfControllerParams_
{
  using Type = ZfControllerParams_<ContainerAllocator>;

  explicit ZfControllerParams_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->steer_p = 0;
      this->steer_i = 0;
      this->steer_d = 0;
      this->speed_p = 0;
      this->speed_i = 0;
      this->speed_d = 0;
      this->steer_a = 0;
      this->steer_b = 0;
      this->steer_c = 0;
      this->speed_a = 0;
      this->speed_b = 0;
      this->speed_c = 0;
    }
  }

  explicit ZfControllerParams_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->steer_p = 0;
      this->steer_i = 0;
      this->steer_d = 0;
      this->speed_p = 0;
      this->speed_i = 0;
      this->speed_d = 0;
      this->steer_a = 0;
      this->steer_b = 0;
      this->steer_c = 0;
      this->speed_a = 0;
      this->speed_b = 0;
      this->speed_c = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _steer_p_type =
    int16_t;
  _steer_p_type steer_p;
  using _steer_i_type =
    int16_t;
  _steer_i_type steer_i;
  using _steer_d_type =
    int16_t;
  _steer_d_type steer_d;
  using _speed_p_type =
    int16_t;
  _speed_p_type speed_p;
  using _speed_i_type =
    int16_t;
  _speed_i_type speed_i;
  using _speed_d_type =
    int16_t;
  _speed_d_type speed_d;
  using _steer_a_type =
    int16_t;
  _steer_a_type steer_a;
  using _steer_b_type =
    int16_t;
  _steer_b_type steer_b;
  using _steer_c_type =
    int16_t;
  _steer_c_type steer_c;
  using _speed_a_type =
    int16_t;
  _speed_a_type speed_a;
  using _speed_b_type =
    int16_t;
  _speed_b_type speed_b;
  using _speed_c_type =
    int16_t;
  _speed_c_type speed_c;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__steer_p(
    const int16_t & _arg)
  {
    this->steer_p = _arg;
    return *this;
  }
  Type & set__steer_i(
    const int16_t & _arg)
  {
    this->steer_i = _arg;
    return *this;
  }
  Type & set__steer_d(
    const int16_t & _arg)
  {
    this->steer_d = _arg;
    return *this;
  }
  Type & set__speed_p(
    const int16_t & _arg)
  {
    this->speed_p = _arg;
    return *this;
  }
  Type & set__speed_i(
    const int16_t & _arg)
  {
    this->speed_i = _arg;
    return *this;
  }
  Type & set__speed_d(
    const int16_t & _arg)
  {
    this->speed_d = _arg;
    return *this;
  }
  Type & set__steer_a(
    const int16_t & _arg)
  {
    this->steer_a = _arg;
    return *this;
  }
  Type & set__steer_b(
    const int16_t & _arg)
  {
    this->steer_b = _arg;
    return *this;
  }
  Type & set__steer_c(
    const int16_t & _arg)
  {
    this->steer_c = _arg;
    return *this;
  }
  Type & set__speed_a(
    const int16_t & _arg)
  {
    this->speed_a = _arg;
    return *this;
  }
  Type & set__speed_b(
    const int16_t & _arg)
  {
    this->speed_b = _arg;
    return *this;
  }
  Type & set__speed_c(
    const int16_t & _arg)
  {
    this->speed_c = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    truck_msgs::msg::ZfControllerParams_<ContainerAllocator> *;
  using ConstRawPtr =
    const truck_msgs::msg::ZfControllerParams_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfControllerParams_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<truck_msgs::msg::ZfControllerParams_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfControllerParams_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfControllerParams_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      truck_msgs::msg::ZfControllerParams_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<truck_msgs::msg::ZfControllerParams_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfControllerParams_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<truck_msgs::msg::ZfControllerParams_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__truck_msgs__msg__ZfControllerParams
    std::shared_ptr<truck_msgs::msg::ZfControllerParams_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__truck_msgs__msg__ZfControllerParams
    std::shared_ptr<truck_msgs::msg::ZfControllerParams_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ZfControllerParams_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->steer_p != other.steer_p) {
      return false;
    }
    if (this->steer_i != other.steer_i) {
      return false;
    }
    if (this->steer_d != other.steer_d) {
      return false;
    }
    if (this->speed_p != other.speed_p) {
      return false;
    }
    if (this->speed_i != other.speed_i) {
      return false;
    }
    if (this->speed_d != other.speed_d) {
      return false;
    }
    if (this->steer_a != other.steer_a) {
      return false;
    }
    if (this->steer_b != other.steer_b) {
      return false;
    }
    if (this->steer_c != other.steer_c) {
      return false;
    }
    if (this->speed_a != other.speed_a) {
      return false;
    }
    if (this->speed_b != other.speed_b) {
      return false;
    }
    if (this->speed_c != other.speed_c) {
      return false;
    }
    return true;
  }
  bool operator!=(const ZfControllerParams_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ZfControllerParams_

// alias to use template instance with default allocator
using ZfControllerParams =
  truck_msgs::msg::ZfControllerParams_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace truck_msgs

#endif  // TRUCK_MSGS__MSG__DETAIL__ZF_CONTROLLER_PARAMS__STRUCT_HPP_
