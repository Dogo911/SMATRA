// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TRUCK_MSGS__MSG__COLLISION_CONTROL_HPP_
#define TRUCK_MSGS__MSG__COLLISION_CONTROL_HPP_

#include "truck_msgs/msg/detail/collision_control__struct.hpp"
#include "truck_msgs/msg/detail/collision_control__builder.hpp"
#include "truck_msgs/msg/detail/collision_control__traits.hpp"
#include "truck_msgs/msg/detail/collision_control__type_support.hpp"

#endif  // TRUCK_MSGS__MSG__COLLISION_CONTROL_HPP_
